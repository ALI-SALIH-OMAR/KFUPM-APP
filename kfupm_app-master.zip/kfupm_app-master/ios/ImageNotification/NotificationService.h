//
//  NotificationService.h
//  ImageNotification
//
//  Created by Saud Elabdullah on 23/03/2022.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
