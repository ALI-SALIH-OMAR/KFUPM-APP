class College{
  String name;
  List<String> majors;

  College({
    required this.name,
    required this.majors,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is College && runtimeType == other.runtimeType && name == other.name && majors == other.majors);

  @override
  int get hashCode => name.hashCode ^ majors.hashCode;

  @override
  String toString() {
    return 'College{name: $name,majors: $majors}';
  }

  College copyWith({
    String? name,
    List<String>? majors,
  }) {
    return College(
      name: name ?? this.name,
      majors: majors ?? this.majors,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'majors': majors.toString(),
    };
  }

  factory College.fromMap(Map<String, dynamic> map) {
    List<dynamic> maj = map['majors'];
    List<String> majors = [];

    for (var element in maj) {
      majors.add(element as String);
    }
    return College(
      name: map['name'] as String,
      majors: majors,
    );
  }
}