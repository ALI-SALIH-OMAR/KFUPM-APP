import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/entities/event_personal.dart';

class Instructor {
  String firstName;
  String lastName;
  String email;
  String office;
  String officeHours;
  String status;
  List<Map<String, dynamic>> teachingCourses;
  List<EventPersonal> eventPersonal;
  List<Event> event;

  Instructor({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.office,
    required this.officeHours,
    required this.status,
    required this.teachingCourses,
    required this.eventPersonal,
    required this.event,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Instructor &&
          runtimeType == other.runtimeType &&
          firstName == other.firstName &&
          lastName == other.lastName &&
          email == other.email &&
          office == other.office &&
          officeHours == other.officeHours &&
          status == other.status &&
          teachingCourses == other.teachingCourses &&
          eventPersonal == other.eventPersonal &&
          event == other.event );

  @override
  int get hashCode =>
      firstName.hashCode ^
      lastName.hashCode ^
      email.hashCode ^
      office.hashCode ^
      officeHours.hashCode ^
      status.hashCode ^
      teachingCourses.hashCode ^
      eventPersonal.hashCode ^
      event.hashCode;

  @override
  String toString() {
    return 'Instructor{'
        ' firstName: $firstName,'
        ' lastName: $lastName,'
        ' email: $email,'
        ' office: $office,'
        ' officeHours: $officeHours,'
        ' status: $status,'
        ' teachingCourses: $teachingCourses,'
        ' eventsPersonal: $eventPersonal,'
        'event: $event'
        '}';
  }

  Instructor copyWith({
    String? firstName,
    String? lastName,
    String? email,
    String? office,
    String? officeHours,
    String? status,
    List<Map<String, String>>? teachingCourses,
    List<EventPersonal>? eventPersonal,
    List<Event>? event,
  }) {
    return Instructor(
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      email: email ?? this.email,
      office: office ?? this.office,
      officeHours: officeHours ?? this.officeHours,
      status: status ?? this.status,
      teachingCourses: teachingCourses ?? this.teachingCourses,
      eventPersonal: eventPersonal ?? this.eventPersonal,
      event: event ?? this.event,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'first_name': firstName,
      'last_name': lastName,
      'kfupm_email': email,
      'office': office,
      'office_hours': officeHours,
      'status': status,
      'courses_teaching': teachingCourses,
      'personal_event': eventPersonal,
      'event' : event,
    };
  }

  factory Instructor.fromMap(Map<String, dynamic> map) {
    List<dynamic> coursesTeachingAsMap = map['courses_teaching'];
    List<Map<String, dynamic>> coursesTeaching = [];
    for (var element in coursesTeachingAsMap) {
      coursesTeaching.add(element);
    }

    List<dynamic> personalEventsAsMap = map['personal_event'] ?? [map['first_name']];
    List<EventPersonal> personalEvents = [];
    if(personalEventsAsMap.first != map['first_name']){
      for (var element in personalEventsAsMap) {
        personalEvents.add(EventPersonal.fromMap(element));
      }
    }

    List<dynamic> eventsAsMap = map['followed_event'] ?? [map['first_name']];
    List<Event> events = [];
    if(eventsAsMap.first != map['first_name']){
      for (var element in personalEventsAsMap) {
        events.add(Event.fromMap(element));
      }
    }

    return Instructor(
      firstName: map['first_name'] as String,
      lastName: map['last_name'] as String,
      email: map['kfupm_email'] as String,
      office: map['office'] as String,
      officeHours: map['office_hours'] as String,
      status: map['status'] as String,
      teachingCourses: coursesTeaching,
      eventPersonal: personalEvents,
      event: events,

    );
  }
}
