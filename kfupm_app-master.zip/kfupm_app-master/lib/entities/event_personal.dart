import 'package:intl/intl.dart';

class EventPersonal{
  String crn;
  DateTime date;
  DateTime timeCreated;
  String creator;
  String location;
  String material;
  String note;
  String structure;
  String timeFrom;
  String timeTo;
  String title;

  EventPersonal({
    required this.crn,
    required this.date,
    required this.timeCreated,
    required this.creator,
    required this.location,
    required this.material,
    required this.note,
    required this.structure,
    required this.timeFrom,
    required this.timeTo,
    required this.title,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EventPersonal &&
          runtimeType == other.runtimeType &&
          crn == other.crn &&
          date == other.date &&
          timeCreated == other.timeCreated &&
          creator == other.creator &&
          location == other.location &&
          material == other.material &&
          note == other.note &&
          structure == other.structure &&
          timeFrom == other.timeFrom &&
          timeTo == other.timeTo &&
          title == other.title);

  @override
  int get hashCode =>
      crn.hashCode ^
      date.hashCode ^
      timeCreated.hashCode ^
      creator.hashCode ^
      location.hashCode ^
      material.hashCode ^
      note.hashCode ^
      structure.hashCode ^
      timeFrom.hashCode ^
      timeTo.hashCode ^
      title.hashCode;

  @override
  String toString() {
    return 'EventPersonal{'
        ' crn: $crn,'
        ' date: $date,'
        ' timeCreated: $timeCreated,'
        ' creator: $creator,'
        ' location: $location,'
        ' material: $material,'
        ' note: $note,'
        ' structure: $structure,'
        ' timeFrom: $timeFrom,'
        ' timeTo: $timeTo,'
        ' title: $title,'
        '}';
  }

  EventPersonal copyWith({
    String? crn,
    DateTime? date,
    DateTime? timeCreated,
    String? creator,
    String? location,
    String? material,
    String? note,
    String? structure,
    String? timeFrom,
    String? timeTo,
    String? title,
  }) {
    return EventPersonal(
      crn: crn ?? this.crn,
      date: date ?? this.date,
      timeCreated: timeCreated ?? this.timeCreated,
      creator: creator ?? this.creator,
      location: location ?? this.location,
      material: material ?? this.material,
      note: note ?? this.note,
      structure: structure ?? this.structure,
      timeFrom: timeFrom ?? this.timeFrom,
      timeTo: timeTo ?? this.timeTo,
      title: title ?? this.title,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'crn': crn,
      'date': DateFormat('EEEE, dd/MM/yyyy').format(date),
      'date_created': DateFormat('EEEE, dd/MM/yyyy').format(timeCreated),
      'creator': creator,
      'location': location,
      'material': material,
      'note': note,
      'structure': structure,
      'time_from': timeFrom,
      'time_to': timeTo,
      'title': title,
    };
  }

  factory EventPersonal.fromMap(Map<String, dynamic> map) {
    return EventPersonal(
      crn: map['crn'] as String,
      date: DateFormat('EEEE, dd/MM/yyyy').parse(map['date']),
      timeCreated: DateFormat('EEEE, dd/MM/yyyy').parse(map['date_created']),
      creator: map['creator'] as String,
      location: map['location'] as String,
      material: map['material'] as String,
      note: map['note'] as String,
      structure: map['structure'] as String,
      timeFrom: map['time_from'] as String,
      timeTo: map['time_to'] as String,
      title: map['title'] as String,
    );
  }
}