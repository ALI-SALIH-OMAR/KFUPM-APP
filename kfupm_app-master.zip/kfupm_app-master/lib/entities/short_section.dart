class ShortSection{
  String crn;
  String info;

  ShortSection({
    required this.crn,
    required this.info,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ShortSection && runtimeType == other.runtimeType && crn == other.crn && info == other.info);

  @override
  int get hashCode => crn.hashCode ^ info.hashCode;

  @override
  String toString() {
    return 'ShortSection{crn: $crn,info: $info,}';
  }

  ShortSection copyWith({
    String? crn,
    String? info,
  }) {
    return ShortSection(
      crn: crn ?? this.crn,
      info: info ?? this.info,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'crn': crn,
      'info': info,
    };
  }

  factory ShortSection.fromMap(Map<String, dynamic> map) {
    return ShortSection(
      crn: map['crn'] as String,
      info: map['info'] as String,
    );
  }
}