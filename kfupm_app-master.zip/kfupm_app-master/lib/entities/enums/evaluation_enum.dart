enum EvaluationEnum { zero, one, two, three, four, five }
