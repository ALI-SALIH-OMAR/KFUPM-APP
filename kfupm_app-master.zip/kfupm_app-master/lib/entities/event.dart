import 'package:intl/intl.dart';

class Event{
  DateTime date;
  String image;
  String location;
  String note;
  String time;
  String title;
  String organizer;

  Event({
    required this.date,
    required this.image,
    required this.location,
    required this.note,
    required this.time,
    required this.title,
    required this.organizer,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Event &&
          runtimeType == other.runtimeType &&
          date == other.date &&
          image == other.image &&
          location == other.location &&
          note == other.note &&
          time == other.time &&
          title == other.title &&
          organizer == other.organizer);

  @override
  int get hashCode =>
      date.hashCode ^
      image.hashCode ^
      location.hashCode ^
      note.hashCode ^
      time.hashCode ^
      title.hashCode ^
      organizer.hashCode;

  @override
  String toString() {
    return 'Event{'
        ' date: $date,'
        ' image: $image,'
        ' location: $location,'
        ' note: $note,'
        ' time: $time,'
        ' title: $title,'
        ' organizer: $organizer,'
        '}';
  }

  Event copyWith({
    DateTime? date,
    String? image,
    String? location,
    String? note,
    String? time,
    String? title,
    String? organizer,
  }) {
    return Event(
      date: date ?? this.date,
      image: image ?? this.image,
      location: location ?? this.location,
      note: note ?? this.note,
      time: time ?? this.time,
      title: title ?? this.title,
      organizer: organizer ?? this.organizer,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'date': DateFormat('EEEE, dd/MM/yyyy').format(date).toString(),
      'image': image,
      'location_event': location,
      'note': note,
      'time': time,
      'title': title,
      'organizer': organizer,
    };
  }

  factory Event.fromMap(Map<String, dynamic> map) {
    return Event(
      date: DateFormat('EEEE, dd/MM/yyyy').parse(map['date']),
      image: map['image'] as String,
      location: map['location_event'] as String,
      note: map['note'] as String,
      time: map['time'] as String,
      title: map['title'] as String,
      organizer: map['organizer'] as String,
    );
  }
}