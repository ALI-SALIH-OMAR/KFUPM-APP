import 'package:kfupm_app/entities/short_course.dart';

class Major {
  String code;
  String name;
  List<ShortCourse> shortCourses;

  Major({
    required this.code,
    required this.name,
    required this.shortCourses,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Major &&
          runtimeType == other.runtimeType &&
          code == other.code &&
          name == other.name &&
          shortCourses == other.shortCourses);

  @override
  int get hashCode => code.hashCode ^ name.hashCode ^ shortCourses.hashCode;

  @override
  String toString() {
    return 'Major{code: $code,name: $name,shortCourses: $shortCourses,}';
  }

  Major copyWith({
    String? code,
    String? name,
    List<ShortCourse>? shortCourses,
  }) {
    return Major(
      code: code ?? this.code,
      name: name ?? this.name,
      shortCourses: shortCourses ?? this.shortCourses,
    );
  }

  Map<String, dynamic> toMap() {
    List courses = [];
    for (var element in shortCourses) {
      courses.add(element.toMap());
    }

    return {
      'code': code,
      'name': name,
      'shortCourses': courses,
    };
  }

  factory Major.fromMap(Map<String, dynamic> map) {
    List<dynamic> courses = map['courses'];
    List<ShortCourse> shortCourses = [];

    for (var element in courses) {
      shortCourses.add(ShortCourse.fromMap(element));
    }

    return Major(
      code: map['code'] as String,
      name: map['name'] as String,
      shortCourses: shortCourses,
    );
  }
}
