import 'package:kfupm_app/entities/short_section.dart';

class Course {
  String code;
  String corequisites;
  String courseWebsite;
  String credit;
  String equivalent;
  bool haveLab;
  String major;
  String name;
  String prerequisites;
  List<ShortSection> shortCourses;

  Course({
    required this.code,
    required this.corequisites,
    required this.courseWebsite,
    required this.credit,
    required this.equivalent,
    required this.haveLab,
    required this.major,
    required this.name,
    required this.prerequisites,
    required this.shortCourses,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Course &&
          runtimeType == other.runtimeType &&
          code == other.code &&
          corequisites == other.corequisites &&
          courseWebsite == other.courseWebsite &&
          credit == other.credit &&
          equivalent == other.equivalent &&
          haveLab == other.haveLab &&
          major == other.major &&
          name == other.name &&
          prerequisites == other.prerequisites &&
          shortCourses == other.shortCourses);

  @override
  int get hashCode =>
      code.hashCode ^
      corequisites.hashCode ^
      courseWebsite.hashCode ^
      credit.hashCode ^
      equivalent.hashCode ^
      haveLab.hashCode ^
      major.hashCode ^
      name.hashCode ^
      prerequisites.hashCode ^
      shortCourses.hashCode;

  @override
  String toString() {
    return 'Course{code: $code,corequisites: '
        '$corequisites,courseWebsite: '
        '$courseWebsite,credit: '
        '$credit,equivalent: '
        '$equivalent,haveLab: '
        '$haveLab,major: '
        '$major,name: '
        '$name,prerequisites: '
        '$prerequisites,shortCourses: '
        '$shortCourses,}';
  }

  Course copyWith({
    String? code,
    String? corequisites,
    String? courseWebsite,
    String? credit,
    String? equivalent,
    bool? haveLab,
    String? major,
    String? name,
    String? prerequisites,
    List<ShortSection>? shortCourses,
  }) {
    return Course(
      code: code ?? this.code,
      corequisites: corequisites ?? this.corequisites,
      courseWebsite: courseWebsite ?? this.courseWebsite,
      credit: credit ?? this.credit,
      equivalent: equivalent ?? this.equivalent,
      haveLab: haveLab ?? this.haveLab,
      major: major ?? this.major,
      name: name ?? this.name,
      prerequisites: prerequisites ?? this.prerequisites,
      shortCourses: shortCourses ?? this.shortCourses,
    );
  }

  Map<String, dynamic> toMap() {
    List sections = [];
    for (var element in shortCourses) {
      sections.add(element.toMap());
    }
    return {
      'code': code,
      'corequisites': corequisites,
      'course_website': courseWebsite,
      'credit': credit,
      'equivalent': equivalent,
      'have_lab': haveLab,
      'major': major,
      'name': name,
      'prerequisites': prerequisites,
      'sections': sections,
    };
  }

  factory Course.fromMap(Map<String, dynamic> map) {
    List<dynamic> sec = map['sections'];
    List<ShortSection> sections = [];

    for (var element in sec) {
      sections.add(ShortSection.fromMap(element));
    }
    return Course(
      code: map['code'] as String,
      corequisites: map['corequisites'] as String,
      courseWebsite: map['course_website'] as String,
      credit: map['credit'] as String,
      equivalent: map['equivalent'] as String,
      haveLab: map['have_lab'] as bool,
      major: map['major'] as String,
      name: map['name'] as String,
      prerequisites: map['prerequisites'] as String,
      shortCourses: sections,
    );
  }
}
