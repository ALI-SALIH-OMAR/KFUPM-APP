class ShortCourse {
  String code;
  String credit;
  String name;

  ShortCourse({
    required this.code,
    required this.credit,
    required this.name,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ShortCourse &&
          runtimeType == other.runtimeType &&
          code == other.code &&
          credit == other.credit &&
          name == other.name);

  @override
  int get hashCode => code.hashCode ^ credit.hashCode ^ name.hashCode;

  @override
  String toString() {
    return 'ShortCourse{code: $code,credit: $credit,name: $name,}';
  }

  ShortCourse copyWith({
    String? code,
    String? credit,
    String? name,
  }) {
    return ShortCourse(
      code: code ?? this.code,
      credit: credit ?? this.credit,
      name: name ?? this.name,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'code': code,
      'credit': credit,
      'name': name,
    };
  }

  factory ShortCourse.fromMap(Map<String, dynamic> map) {
    return ShortCourse(
      code: map['code'] as String,
      credit: map['credit'] as String,
      name: map['name'] as String,
    );
  }
}
