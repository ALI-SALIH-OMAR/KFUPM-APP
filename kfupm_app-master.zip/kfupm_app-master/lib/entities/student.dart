import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/entities/event_personal.dart';

class Student{
  String firstName;
  String lastName;
  String major;
  String concentration;
  String advisorFirstName;
  String advisorLastName;
  String housing;
  List<String> courses;
  List<String> followedClubs;
  String email;
  List<String> sections;
  String status;
  String representative;
  List<Event> events;
  List<EventPersonal> eventPersonal;

  Student({
    required this.firstName,
    required this.lastName,
    required this.major,
    required this.concentration,
    required this.advisorFirstName,
    required this.advisorLastName,
    required this.housing,
    required this.courses,
    required this.followedClubs,
    required this.email,
    required this.sections,
    required this.status,
    required this.representative,
    required this.events,
    required this.eventPersonal,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Student &&
          runtimeType == other.runtimeType &&
          firstName == other.firstName &&
          lastName == other.lastName &&
          major == other.major &&
          concentration == other.concentration &&
          advisorFirstName == other.advisorFirstName &&
          advisorLastName == other.advisorLastName &&
          housing == other.housing &&
          courses == other.courses &&
          followedClubs == other.followedClubs &&
          email == other.email &&
          sections == other.sections &&
          status == other.status &&
          representative == other.representative &&
          events == other.events &&
          eventPersonal == other.eventPersonal);

  @override
  int get hashCode =>
      firstName.hashCode ^
      lastName.hashCode ^
      major.hashCode ^
      concentration.hashCode ^
      advisorFirstName.hashCode ^
      advisorLastName.hashCode ^
      housing.hashCode ^
      courses.hashCode ^
      followedClubs.hashCode ^
      email.hashCode ^
      sections.hashCode ^
      status.hashCode ^
      representative.hashCode ^
      events.hashCode ^
      eventPersonal.hashCode;

  @override
  String toString() {
    return 'Student{'
        ' firstName: $firstName,'
        ' lastName: $lastName,'
        ' major: $major,'
        ' concentration: $concentration,'
        ' advisorFirstName: $advisorFirstName,'
        ' advisorLastName: $advisorLastName,'
        ' housing: $housing,'
        ' courses: $courses,'
        ' followedClubs: $followedClubs,'
        ' email: $email,'
        ' sections: $sections,'
        ' status: $status,'
        ' representative: $representative,'
        ' events: $events,'
        ' eventsPersonal: $eventPersonal,'
        '}';
  }

  Student copyWith({
    String? firstName,
    String? lastName,
    String? major,
    String? concentration,
    String? advisorFirstName,
    String? advisorLastName,
    String? housing,
    List<String>? courses,
    List<String>? followedClubs,
    String? email,
    List<String>? sections,
    String? status,
    String? representative,
    List<Event>? events,
    List<EventPersonal>? eventPersonal,
  }) {
    return Student(
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      major: major ?? this.major,
      concentration: concentration ?? this.concentration,
      advisorFirstName: advisorFirstName ?? this.advisorFirstName,
      advisorLastName: advisorLastName ?? this.advisorLastName,
      housing: housing ?? this.housing,
      courses: courses ?? this.courses,
      followedClubs: followedClubs ?? this.followedClubs,
      email: email ?? this.email,
      sections: sections ?? this.sections,
      status: status ?? this.status,
      representative: representative ?? this.representative,
      events: events ?? this.events,
      eventPersonal: eventPersonal ?? this.eventPersonal,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'first_name': firstName,
      'last_name': lastName,
      'major': major,
      'concentration': concentration,
      'advisor_first_name': advisorFirstName,
      'advisor_last_name': advisorLastName,
      'Housing': housing,
      'courses': courses,
      'followed_clubs': followedClubs,
      'kfupm_email': email,
      'sections': sections,
      'status': status,
      'representative': representative,
      'followed_events': events,
      'personal_event': eventPersonal,
    };
  }

  factory Student.fromMap(Map<String, dynamic> map) {
    List<dynamic> coursesAsMap = map['courses'];
    List<String> courses = [];
    for (var element in coursesAsMap) {
      courses.add(element.toString());
    }

    List<dynamic> followedClubsAsMap = map['followed_clubs'];
    List<String> followedClubs = [];
    for (var element in followedClubsAsMap) {
      followedClubs.add(element.toString());
    }

    List<dynamic> sectionsAsMap = map['sections'];
    List<String> sections = [];
    for (var element in sectionsAsMap) {
      sections.add(element.toString());
    }

    List<dynamic> followedEventsAsMap = map['followed_events'];
    List<Event> followedEvents = [];
    for (var element in followedEventsAsMap) {
      followedEvents.add(Event.fromMap(element));
    }

    List<dynamic> personalEventsAsMap = map['personal_event'] ?? [map['first_name']];
    List<EventPersonal> personalEvents = [];
    if(personalEventsAsMap.first != map['first_name']){
      for (var element in personalEventsAsMap) {
        personalEvents.add(EventPersonal.fromMap(element));
      }
    }

    return Student(
      firstName: map['first_name'] as String,
      lastName: map['last_name'] as String,
      major: map['major'] as String,
      concentration: map['concentration'] as String,
      advisorFirstName: map['advisor_first_name'] as String,
      advisorLastName: map['advisor_last_name'] as String,
      housing: map['Housing'] as String,
      courses: courses,
      followedClubs: followedClubs,
      email: map['kfupm_email'] as String,
      sections: sections,
      status: map['status'] as String,
      representative: map['representative'] as String,
      events: followedEvents,
      eventPersonal: personalEvents,
    );
  }
}