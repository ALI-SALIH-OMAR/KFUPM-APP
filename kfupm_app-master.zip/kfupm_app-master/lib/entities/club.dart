import 'package:kfupm_app/entities/event.dart';

class ClubModel{
  String id;
  String name;
  String about;
  String icon;
  List<Event> events;
  String location;

  ClubModel({
    required this.id,
    required this.name,
    required this.about,
    required this.icon,
    required this.events,
    required this.location,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ClubModel &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          name == other.name &&
          about == other.about &&
          icon == other.icon &&
          events == other.events &&
          location == other.location);

  @override
  int get hashCode => id.hashCode ^ name.hashCode ^ about.hashCode ^ icon.hashCode ^ events.hashCode ^ location.hashCode;

  @override
  String toString() {
    return 'Club{'
        ' id: $id,'
        ' name: $name,'
        ' about: $about,'
        ' icon: $icon,'
        ' club_events: $events,'
        ' location: $location,'
        '}';
  }

  ClubModel copyWith({
    String? id,
    String? name,
    String? about,
    String? icon,
    List<Event>? events,
    String? location,
  }) {
    return ClubModel(
      id: id ?? this.id,
      name: name ?? this.name,
      about: about ?? this.about,
      icon: icon ?? this.icon,
      events: events ?? this.events,
      location: location ?? this.location,
    );
  }

  Map<String, dynamic> toMap() {
    List events = [];
    for (var element in this.events) {
      events.add(element.toMap());
    }

    return {
      'id': id,
      'name': name,
      'about': about,
      'icon': icon,
      'club_events': events,
      'location': location,
    };
  }

  factory ClubModel.fromMap(Map<String, dynamic> map) {
    List<dynamic> clubEvents = map['club_events'] ?? {};
    List<Event> event = [];

    for (var element in clubEvents) {
      event.add(Event.fromMap(element));
    }

    return ClubModel(
      id: map['id'] as String,
      name: map['name'] as String,
      about: map['about'] as String,
      icon: map['icon'] as String,
      events: event,
      location: map['location'] ?? '',
    );
  }
}