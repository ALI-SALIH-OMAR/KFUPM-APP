import 'event_personal.dart';

class Section {
  String code;
  String courseName;
  String crn;
  String days;
  String instructor;
  String location;
  String sectionNumber;
  String time;
  String groupChat;
  List<EventPersonal>? eventPersonal;
  Map<String, dynamic>? heatMap;
  List<String> studentIDs;

  Section({
    required this.code,
    required this.courseName,
    required this.crn,
    required this.days,
    required this.instructor,
    required this.location,
    required this.sectionNumber,
    required this.time,
    required this.groupChat,
    required this.eventPersonal,
    required this.heatMap,
    required this.studentIDs,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          (other is Section &&
              runtimeType == other.runtimeType &&
              code == other.code &&
              courseName == other.courseName &&
              crn == other.crn &&
              days == other.days &&
              instructor == other.instructor &&
              location == other.location &&
              sectionNumber == other.sectionNumber &&
              time == other.time &&
              groupChat == other.groupChat &&
              eventPersonal == other.eventPersonal &&
              heatMap == other.heatMap &&
              studentIDs == other.studentIDs);

  @override
  int get hashCode =>
      code.hashCode ^
      courseName.hashCode ^
      crn.hashCode ^
      days.hashCode ^
      instructor.hashCode ^
      location.hashCode ^
      sectionNumber.hashCode ^
      time.hashCode ^
      groupChat.hashCode ^
      eventPersonal.hashCode ^
      heatMap.hashCode ^
      studentIDs.hashCode;

  @override
  String toString() {
    return 'Section{code: '
        '$code,courseName: '
        '$courseName,crn: '
        '$crn,days: '
        '$days,instructor: '
        '$instructor,location: '
        '$location,sectionNumber: '
        '$sectionNumber,time: '
        '$time,groupChat: '
        '$groupChat,'
        ' eventsPersonal: $eventPersonal,'
        ' heatMap: $heatMap,'
        ' studentIDs: $studentIDs,'
        '}';
  }

  Section copyWith({
    String? code,
    String? courseName,
    String? crn,
    String? days,
    String? instructor,
    String? location,
    String? sectionNumber,
    String? time,
    String? groupChat,
    List<EventPersonal>? eventPersonal,
    Map<String, dynamic>? heatMap,
    List<String>? studentIDs,
  }) {
    return Section(
      code: code ?? this.code,
      courseName: courseName ?? this.courseName,
      crn: crn ?? this.crn,
      days: days ?? this.days,
      instructor: instructor ?? this.instructor,
      location: location ?? this.location,
      sectionNumber: sectionNumber ?? this.sectionNumber,
      time: time ?? this.time,
      groupChat: groupChat ?? this.groupChat,
      eventPersonal: eventPersonal ?? this.eventPersonal,
      heatMap: heatMap ?? this.heatMap,
      studentIDs: studentIDs ?? this.studentIDs,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'code': code,
      'course_name': courseName,
      'crn': crn,
      'days': days,
      'instructor': instructor,
      'location': location,
      'section': sectionNumber,
      'time': time,
      'whatsapp': groupChat,
      'personal_event': eventPersonal,
      'heat_map': heatMap,
      'students': studentIDs,
    };
  }

  factory Section.fromMap(Map<String, dynamic> map) {
    List<EventPersonal> personalEvents = [];
    try {
      List<dynamic> personalEventsAsMap = map['personal_event'] ?? [map['code']];
      if (personalEventsAsMap.first != map['code']) {
        for (var element in personalEventsAsMap) {
          personalEvents.add(EventPersonal.fromMap(element));
        }
      }
    } catch (e){
      print('1111 $e');
    }
    List<String> students = [];
    try{
      List<dynamic> studentsAsMap = map['students'] ?? [map['code']];
      if (studentsAsMap.first != map['code']) {
        for (var element in studentsAsMap) {
          students.add(element);
        }
      }
    } catch (e){
      print('2222 $e');
    }
    try {
      return Section(
        code: map['code'] as String,
        courseName: map['course_name'] as String,
        crn: map['crn'] as String,
        days: map['days'] as String,
        instructor: map['instructor'] as String,
        location: map['location'] as String,
        sectionNumber: map['section'] as String,
        time: map['time'] as String,
        groupChat: map['whatsapp'] as String,
        eventPersonal: personalEvents,
        heatMap: map['heat_map'] == null ? {} : map['heat_map'] as Map<String, dynamic>,
        studentIDs: students,
      );
    } catch (e){
      print('return $e');
    }
    return Section(
      code: map['code'] as String,
      courseName: map['course_name'] as String,
      crn: map['crn'] as String,
      days: map['days'] as String,
      instructor: map['instructor'] as String,
      location: map['location'] as String,
      sectionNumber: map['section'] as String,
      time: map['time'] as String,
      groupChat: map['whatsapp'] as String,
      eventPersonal: personalEvents,
      heatMap: map['heat_map'] == null ? {} : map['heat_map'] as Map<String, dynamic>,
      studentIDs: students,
    );
  }
}
