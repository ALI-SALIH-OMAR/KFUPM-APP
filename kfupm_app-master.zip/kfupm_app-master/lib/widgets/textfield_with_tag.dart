/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is a textfield with a tag as it is the type of the field.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';

class TextFieldWithTag extends StatelessWidget {
  const TextFieldWithTag({Key? key, this.textEditingController, this.input, this.obscureText}) : super(key: key);

  final TextEditingController? textEditingController;
  final String? input;
  final bool? obscureText;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.only(
            right: SizeConfig.widthMultiplier! * 5,
            left: SizeConfig.widthMultiplier! * 5,
            top: 15,
          ),
          padding: const EdgeInsets.only(left: 5),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              width: 3.0,
              color: Colors.grey.shade900,
            ),
          ),
          child: TextField(
            controller: textEditingController,
            obscureText: obscureText!,
            decoration: const InputDecoration(
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              contentPadding: EdgeInsets.only(top: 1.5, bottom: 1.5, right: 5, left: 5),
            ),
          ),
        ),
        Positioned(
          left: 35.0,
          child: Container(
            padding: const EdgeInsets.all(5.0),
            color: Colors.white,
            child: Row(
              children: [
                Text(
                  input!,
                  style: TextStyle(
                    color: Colors.grey.shade900,
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}
