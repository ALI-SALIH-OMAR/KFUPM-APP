import 'package:flutter/material.dart';
import 'package:kfupm_app/entities/college.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/cards/major_card.dart';

class CollegeCard extends StatelessWidget {
  const CollegeCard({
    Key? key,
    required this.college,
  }) : super(key: key);
  final College college;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: SizeConfig.heightMultiplier! * 1,
      ),
      padding: EdgeInsets.symmetric(
        vertical: SizeConfig.heightMultiplier! * 2,
        horizontal: SizeConfig.widthMultiplier! * 2,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFFFAF7F5),
        borderRadius: BorderRadius.circular(
          10,
        ),
      ),
      child: Column(
        children: [
          Text(
            college.name,
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: SizeConfig.textMultiplier! * 2,
            ),
          ),
          Divider(
            thickness: SizeConfig.widthMultiplier! * 0.3,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: List.generate(
              college.majors.length,
              (index) {
                return MajorCard(
                  major: college.majors[index],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
