import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/screens/flowchart.dart';
import 'package:kfupm_app/utils/size_config.dart';

class MajorCard extends StatelessWidget {
  const MajorCard({Key? key, required this.major}) : super(key: key);
  final String major;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          GlobalController.passedContext,
          MaterialPageRoute(
            builder: (context) => const Flowchart(),
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.symmetric(
          vertical: SizeConfig.heightMultiplier! * 1,
          horizontal: SizeConfig.widthMultiplier! * 1,
        ),
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.heightMultiplier! * 2,
          horizontal: SizeConfig.widthMultiplier! * 4.5,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFEAF4EB),
          borderRadius: BorderRadius.circular(
            50,
          ),
        ),
        child: Text(
          major,
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: SizeConfig.textMultiplier! * 2,
          ),
        ),
      ),
    );
  }
}
