/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is a club card.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/screens/club.dart';
import 'package:kfupm_app/utils/size_config.dart';

class ClubCard extends StatelessWidget {
  const ClubCard({Key? key, required this.club}) : super(key: key);
  final ClubModel club;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          GlobalController.passedContext,
          MaterialPageRoute(
            builder: (context) => Club(
              club: club,
              isFollowed: GlobalController.stu ? GlobalController.student!.followedClubs.contains(club.name) : false,
            ),
          ),
        );
      },
      child: Container(
        margin: EdgeInsets.symmetric(
          vertical: SizeConfig.heightMultiplier! * 1,
          horizontal: SizeConfig.widthMultiplier! * 6,
        ),
        width: SizeConfig.widthMultiplier! * 88,
        height: SizeConfig.heightMultiplier! * 18,
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.zero,
          border: Border.all(
            color: Colors.grey.shade400,
            width: SizeConfig.widthMultiplier! * 0.1,
          ),
        ),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(
                    10,
                  ),
                  bottomRight: Radius.circular(
                    10,
                  ),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: const Offset(0, 3), // changes position of shadow
                  ),
                ],
              ),
              child: Row(
                children: [
                  Image.network(
                    club.icon,
                    width: SizeConfig.widthMultiplier! * 13,
                    height: SizeConfig.widthMultiplier! * 13,
                  ),
                  Expanded(
                    child: Text(
                      club.name,
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.w700,
                        fontSize: SizeConfig.textMultiplier! * 2.1,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Container(
                color: Colors.grey.shade100,
                padding: EdgeInsets.symmetric(
                  vertical: SizeConfig.heightMultiplier! * 0.5,
                  horizontal: SizeConfig.widthMultiplier! * 2,
                ),
                child: Text(
                  club.about,
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w400,
                    fontSize: SizeConfig.textMultiplier! * 1.7,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
