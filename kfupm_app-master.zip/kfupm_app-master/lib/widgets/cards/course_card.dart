/*
Author: Saud Elabdullah.
Work: This class work as a widget to show a course card.
Note: Nothing.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/entities/short_course.dart';
import 'package:kfupm_app/screens/course.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/theme/app_theme.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/size_config.dart';

import '../../controllers/global_controller.dart';

class CourseCard extends StatefulWidget {
  const CourseCard({Key? key, required this.shortCourse}) : super(key: key);
  final ShortCourse shortCourse;

  @override
  State<CourseCard> createState() => _CourseCardState();
}

class _CourseCardState extends State<CourseCard> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          GlobalController.passedContext,
          MaterialPageRoute(
            builder: (context) => CourseScreen(
              code: widget.shortCourse.code,
            ),
          ),
        );
      },
      child: Container(
        height: SizeConfig.heightMultiplier! * 10,
        margin: symmetricInsets(
          horizontal: 3,
          vertical: 1,
        ),
        padding: symmetricInsets(
          horizontal: 2,
          vertical: 1,
        ),
        decoration: BoxDecoration(
          color: AppColors.secondaryColor,
          borderRadius: Constant.borderRadiusMedium,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  widget.shortCourse.code,
                  style: AppTheme.textStyleNine,
                ),
                Container(
                  height: SizeConfig.heightMultiplier! * 4,
                  width: SizeConfig.widthMultiplier! * 10,
                  decoration: BoxDecoration(
                    color: AppColors.thirdColor,
                    borderRadius: Constant.borderRadiusLarge,
                  ),
                  child: Center(
                    child: Text(
                      widget.shortCourse.credit,
                      style: AppTheme.textStyleNine,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: SizeConfig.heightMultiplier! * 1,
            ),
            Text(
              widget.shortCourse.name,
              style: AppTheme.textStyleTen,
            ),
          ],
        ),
      ),
    );
  }
}
