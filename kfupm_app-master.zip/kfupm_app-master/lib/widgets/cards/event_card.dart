/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is an event card.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/theme/app_theme.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/buttons/add_to_calendar_button.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/event_sheet.dart';

import '../buttons/add_to_calendar_button_ins.dart';

class EventCard extends StatefulWidget {
  const EventCard({
    Key? key,
    required this.event,
    required this.club,
  }) : super(key: key);
  final Event event;
  final ClubModel club;

  @override
  State<EventCard> createState() => _EventCardState();
}

class _EventCardState extends State<EventCard> {
  openSheet(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: EventSheet(
        event: widget.event,
        showAddToCalendarButton:
            (GlobalController.stu && !GlobalController.student!.events.contains(widget.event)) ? true : false,
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        await openSheet(context);
      },
      child: Container(
        margin: symmetricInsets(
          horizontal: 3,
          vertical: 1,
        ),
        padding: EdgeInsets.only(
          bottom: SizeConfig.heightMultiplier! * 2,
        ),
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: Constant.borderRadiusLarge,
          border: Constant.cardBorder,
        ),
        child: Column(
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.only(
                    topLeft: Constant.cornerRadius,
                    topRight: Constant.cornerRadius,
                  ),
                  child: Image.network(
                    widget.event.image,
                    width: SizeConfig.widthMultiplier! * 88,
                  ),
                ),
                if (GlobalController.stu)
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 1.5,
                    right: SizeConfig.widthMultiplier! * 2.5,
                    child: AddToCalendarButton(
                      event: widget.event,
                      added: GlobalController.student!.events.contains(widget.event),
                    ),
                  ),
                if (GlobalController.ins)
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 1.5,
                    right: SizeConfig.widthMultiplier! * 2.5,
                    child: AddToCalendarButtonIns(
                      event: widget.event,
                      added: GlobalController.instructor!.event.contains(widget.event),
                    ),
                  ),
              ],
            ),
            const SizedBox(
              height: 15,
            ),
            Stack(
              children: [
                Positioned(
                  left: SizeConfig.widthMultiplier! * 5,
                  child: Image.network(
                    widget.club.icon,
                    width: SizeConfig.widthMultiplier! * 9.5,
                    height: SizeConfig.widthMultiplier! * 9.5,
                  ),
                ),
                Positioned(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 18,
                      ),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: symmetricInsets(
                                    horizontal: 0,
                                    vertical: 0.5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.transparent,
                                    borderRadius: Constant.borderRadiusSmall,
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    'By ${widget.club.name}',
                                    style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier! * 1.8,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Text(
                              widget.event.title,
                              style: AppTheme.textStyleThree,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
