/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is to represent an event in a calendar page.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/entities/event_personal.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/edit_personal_event_sheet.dart';
import 'package:kfupm_app/widgets/sheets/event_sheet.dart';
import 'package:kfupm_app/widgets/sheets/personal_event_sheet.dart';

class EventCalendar extends StatelessWidget {
  const EventCalendar(
      {Key? key,
      required this.title,
      required this.isPersonal,
      required this.isCreator,
      this.event,
      this.eventPersonal})
      : super(key: key);
  final String title;
  final bool isPersonal;
  final bool isCreator;
  final Event? event;
  final EventPersonal? eventPersonal;

  openSheetOne(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: PersonalEventSheet(
        eventPersonal: eventPersonal,
        isCreator: eventPersonal!.creator.toLowerCase() ==
            (GlobalController.stu
                ? (GlobalController.student!.firstName.toLowerCase() +
                    ' ' +
                    GlobalController.student!.lastName.toLowerCase())
                : (GlobalController.instructor!.firstName.toLowerCase() +
                    ' ' +
                    GlobalController.instructor!.lastName.toLowerCase())),
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  openSheetTwo(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: EventSheet(
        event: event,
        showAddToCalendarButton: false,
        showDeleteButton: true,
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  openSheetTwoEdit(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: const EditPersonalEventSheet(
        title: 'Edit Task',
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        if (isPersonal) {
          if (isCreator) {
            await openSheetTwoEdit(context);
          } else {
            await openSheetOne(context);
          }
        } else {
          await openSheetTwo(context);
        }
      },
      child: Container(
        height: SizeConfig.heightMultiplier! * 2.0,
        width: SizeConfig.widthMultiplier! * 13,
        padding: const EdgeInsets.all(2),
        margin: EdgeInsets.symmetric(
          vertical: SizeConfig.heightMultiplier! * 0.2,
        ),
        decoration: BoxDecoration(
          color: Colors.amber.shade100,
          borderRadius: BorderRadius.circular(4),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              height: SizeConfig.heightMultiplier! * 1,
              width: SizeConfig.heightMultiplier! * 1,
              decoration: const BoxDecoration(
                color: Colors.amber,
                shape: BoxShape.circle,
              ),
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 0.5,
            ),
            Expanded(
              child: Text(
                title,
                overflow: TextOverflow.clip,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 1.1,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
