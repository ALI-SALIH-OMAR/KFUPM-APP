import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/calendar_controller.dart';
import 'package:kfupm_app/controllers/heat_map_controller.dart';
import 'package:kfupm_app/widgets/calendar/day.dart';

class Week extends StatelessWidget {

  const Week({
    Key? key,
    required this.week,
    required this.skipDays,
    required this.calendarController,
    required this.weekNumber,
    required this.heatMapController,
    this.isHeatMap = false,
  }) : super(key: key);
  final List<int> week;
  final int skipDays;
  final bool isHeatMap;
  final CalendarController calendarController;
  final HeatMapController heatMapController;
  final int weekNumber;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Day(
          dayNum: week[0],
          isWeekend: false,
          isSkip: skipDays >= 1 ? true : false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
        Day(
          dayNum: week[1],
          isWeekend: false,
          isSkip: skipDays >= 2 ? true : false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
        Day(
          dayNum: week[2],
          isWeekend: false,
          isSkip: skipDays >= 3 ? true : false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
        Day(
          dayNum: week[3],
          isWeekend: false,
          isSkip: skipDays >= 4 ? true : false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
        Day(
          dayNum: week[4],
          isWeekend: false,
          isSkip: skipDays >= 5 ? true : false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
        Day(
          dayNum: week[5],
          isWeekend: true,
          isSkip: skipDays >= 6 ? true : false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
        Day(
          dayNum: week[6],
          isWeekend: true,
          isSkip: false,
          isHeatMap: isHeatMap,
          calendarController: calendarController,
          heatMapController: heatMapController,
          weekNumber: weekNumber,
        ),
      ],
    );
  }
}
