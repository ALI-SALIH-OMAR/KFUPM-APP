import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/calendar_controller.dart';
import 'package:kfupm_app/controllers/heat_map_controller.dart';
import 'package:kfupm_app/entities/event_personal.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/calendar/event_calendar.dart';

import '../../entities/event.dart';

class Day extends StatefulWidget {
  const Day({
    Key? key,
    required this.dayNum,
    required this.isWeekend,
    required this.isSkip,
    required this.calendarController,
    required this.weekNumber,
    required this.heatMapController,
    this.isHeatMap = false,
  }) : super(key: key);
  final int dayNum;
  final bool isWeekend;
  final bool isSkip;
  final bool isHeatMap;
  final CalendarController calendarController;
  final HeatMapController heatMapController;
  final int weekNumber;

  @override
  State<Day> createState() => _DayState();
}

class _DayState extends State<Day> {
  late List<Event>? events;
  late List<EventPersonal>? eventsPersonal;
  late int heat;
  int numberOfEvents = 0;
  int numberOfEventsPersonal = 0;
  bool isSet = false;

  Color heatMapColor(int heat) {
    if (heat > 5) {
      return Colors.red.shade900;
    } else if (heat > 2) {
      return Colors.redAccent.shade400;
    } else if (heat > 0) {
      return Colors.redAccent.shade100;
    } else {
      return Colors.white;
    }
  }

  void setEvents() {
    if (widget.dayNum < 40) {
      events = widget.calendarController.getEventsForDay(widget.weekNumber, widget.dayNum);
      if (events != null) {
        numberOfEvents = events!.length;
      }
      eventsPersonal = widget.calendarController.getEventsPersonalForDay(widget.weekNumber, widget.dayNum);
      if (eventsPersonal != null) {
        numberOfEventsPersonal = eventsPersonal!.length;
      }
    } else {
      events = widget.calendarController.getEventsForDay(widget.weekNumber, widget.dayNum - 100);
      if (events != null) {
        numberOfEvents = events!.length;
      }
      eventsPersonal = widget.calendarController.getEventsPersonalForDay(widget.weekNumber, widget.dayNum - 100);
      if (eventsPersonal != null) {
        numberOfEventsPersonal = eventsPersonal!.length;
      }
    }
  }

  setCalendarPurpose() {
    if (widget.isHeatMap) {
      if (widget.dayNum > 100) {
        heat = widget.heatMapController.heatMap['${widget.weekNumber}/${widget.dayNum - 100}'] ?? 0;
      } else {
        heat = widget.heatMapController.heatMap['${widget.weekNumber}/${widget.dayNum}'] ?? 0;
      }
    } else {
      setEvents();
    }
  }

  @override
  void initState() {
    setCalendarPurpose();
    isSet = true;
    super.initState();
  }

  @override
  void didUpdateWidget(covariant Day oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!isSet) {
      setCalendarPurpose();
    }
    isSet = false;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: SizeConfig.heightMultiplier! * 11.7,
      width: SizeConfig.widthMultiplier! * 14.28,
      padding: const EdgeInsets.only(
        top: 3,
        right: 2,
        left: 2,
      ),
      decoration: widget.isSkip
          ? const BoxDecoration()
          : BoxDecoration(
              color:
                  widget.isHeatMap ? heatMapColor(heat) : (widget.isWeekend ? const Color(0xFFFAF7F5) : Colors.white),
              border: Border.all(
                color: Colors.black12,
                width: 0.2,
              ),
            ),
      child: widget.isSkip
          ? Container()
          : Column(
              children: [
                Center(
                  child: Container(
                    height: SizeConfig.heightMultiplier! * 2.3,
                    width: SizeConfig.widthMultiplier! * 5,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      color: widget.dayNum > 100 ? const Color(0xFF25794F) : Colors.transparent,
                    ),
                    child: Text(
                      widget.dayNum > 100 ? (widget.dayNum - 100).toString() : widget.dayNum.toString(),
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: widget.dayNum > 100 ? Colors.white : Colors.black,
                        fontWeight: FontWeight.w600,
                        fontSize: SizeConfig.textMultiplier! * 1.7,
                      ),
                    ),
                  ),
                ),
                widget.isHeatMap
                    ? Container()
                    : SingleChildScrollView(
                        child: Column(
                          children: List.generate(
                            numberOfEvents + numberOfEventsPersonal,
                            (index) {
                              if (numberOfEvents > index && numberOfEvents != 0 && events != null) {
                                return EventCalendar(
                                  title: events![index].title,
                                  isPersonal: false,
                                  isCreator: false,
                                  event: events![index],
                                );
                              } else if (eventsPersonal != null) {
                                return EventCalendar(
                                  title: eventsPersonal![index - numberOfEvents].title,
                                  isPersonal: true,
                                  isCreator: false,
                                  event: null,
                                  eventPersonal: eventsPersonal![index - numberOfEvents],
                                );
                              }
                              return const SizedBox();
                            },
                          ),
                        ),
                      ),
              ],
            ),
    );
  }
}
