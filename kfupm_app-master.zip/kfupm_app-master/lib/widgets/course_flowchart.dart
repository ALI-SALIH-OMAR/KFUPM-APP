import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';

class CourseFlowchart extends StatelessWidget {
  const CourseFlowchart({
    Key? key,
    required this.courseName,
    this.isLab = false,
    this.isCom = false,
  }) : super(key: key);
  final String courseName;
  final bool isLab;
  final bool isCom;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.widthMultiplier! * 29,
      height: SizeConfig.heightMultiplier! * 7,
      decoration: BoxDecoration(
        color: Colors.grey.shade400,
        borderRadius: BorderRadius.circular(
          15,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 5,
            blurRadius: 7,
            offset: const Offset(0, 3), // changes position of shadow
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Text(
              courseName,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: SizeConfig.textMultiplier! * 2.4,
              ),
            ),
          ),
          if (isLab)
            Icon(
              Icons.biotech_sharp,
              size: SizeConfig.imageSizeMultiplier! * 4,
              color: Colors.black,
            ),
          if (isCom)
            Icon(
              Icons.laptop,
              size: SizeConfig.imageSizeMultiplier! * 4,
              color: Colors.black,
            ),
          if (!isCom && !isLab)
            SizedBox(
              height: SizeConfig.heightMultiplier! * 2,
            ),
        ],
      ),
    );
  }
}
