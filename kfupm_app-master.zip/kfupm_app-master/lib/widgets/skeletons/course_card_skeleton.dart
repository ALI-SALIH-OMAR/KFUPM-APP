import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:shimmer_animation/shimmer_animation.dart';

class CourseCardSkeleton extends StatelessWidget {
  const CourseCardSkeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      duration: const Duration(seconds: 3),
      color: Colors.white,
      colorOpacity: 0.5,
      enabled: true,
      direction: const ShimmerDirection.fromLTRB(),
      child: Container(
        height: SizeConfig.heightMultiplier! * 10,
        margin: symmetricInsets(
          horizontal: 2,
          vertical: 1,
        ),
        padding: symmetricInsets(
          horizontal: 2,
          vertical: 1,
        ),
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: Constant.borderRadiusMedium,
        ),
      ),
    );
  }
}
