import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:shimmer_animation/shimmer_animation.dart';

class ClubCardSkeleton extends StatelessWidget {
  const ClubCardSkeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      duration: const Duration(seconds: 3),
      color: Colors.white,
      colorOpacity: 0.5,
      enabled: true,
      direction: const ShimmerDirection.fromLTRB(),
      child: Container(
        margin: EdgeInsets.symmetric(
          vertical: SizeConfig.heightMultiplier! * 1,
          horizontal: SizeConfig.widthMultiplier! * 6,
        ),
        width: SizeConfig.widthMultiplier! * 88,
        height: SizeConfig.heightMultiplier! * 14,
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: BorderRadius.zero,
          // borderRadius: Constant.borderRadiusMedium,
          border: Border.all(
            color: Colors.grey.shade400,
            width: SizeConfig.widthMultiplier! * 0.1,
          ),
        ),
      ),
    );
  }
}
