import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:shimmer_animation/shimmer_animation.dart';

class EventCardSkeleton extends StatelessWidget {
  const EventCardSkeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      duration: const Duration(seconds: 3),
      color: Colors.white,
      colorOpacity: 0.5,
      enabled: true,
      direction: const ShimmerDirection.fromLTRB(),
      child: Container(
        height: SizeConfig.heightMultiplier! * 30,
        margin: symmetricInsets(
          horizontal: 3,
          vertical: 1,
        ),
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: Constant.borderRadiusLarge,
          border: Constant.cardBorder,
        ),
      ),
    );
  }
}
