import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:shimmer_animation/shimmer_animation.dart';

class DropdownSkeleton extends StatelessWidget {
  const DropdownSkeleton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Shimmer(
      duration: const Duration(seconds: 3),
      color: Colors.white,
      colorOpacity: 0.5,
      enabled: true,
      direction: const ShimmerDirection.fromLTRB(),
      child: Container(
        width: SizeConfig.widthMultiplier! * 70,
        padding: EdgeInsets.only(
          left: SizeConfig.widthMultiplier! * 2,
          right: SizeConfig.widthMultiplier! * 2,
        ),
        decoration: BoxDecoration(
          color: Colors.grey.shade300,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            width: SizeConfig.widthMultiplier! * 0.2,
            color: Colors.grey.shade200,
          ),
        ),
      ),
    );
  }
}
