import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';

class Line extends StatelessWidget {
  const Line({Key? key, required this.width}) : super(key: key);
  final double width;

  @override
  Widget build(BuildContext context) {
    return Container(
        height: SizeConfig.heightMultiplier! * 0.4, width: SizeConfig.widthMultiplier! * width, color: Colors.black);
  }
}
