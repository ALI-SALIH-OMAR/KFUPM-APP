import 'package:flutter/material.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/image_picking.dart';
import 'package:kfupm_app/utils/size_config.dart';

import '../../services/firebase/club_services.dart';

class EditClubSheet extends StatefulWidget {
  const EditClubSheet({
    Key? key,
    required this.club,
    required this.state,
  }) : super(key: key);
  final ClubModel club;
  final State state;

  @override
  State<EditClubSheet> createState() => _EditClubSheetState();
}

class _EditClubSheetState extends State<EditClubSheet> {
  void changeImage() async {
    file = await imagePicking();
    imageChanged = true;
    setState(() {});
  }

  void editClub() async {
    widget.club.name = nameController.text;
    widget.club.location = locationController.text;
    widget.club.about = descriptionController.text;
    if (imageChanged) {
      widget.club.icon = await ClubServices.changeClubIcon(nameController.text, file);
      widget.state.setState(() {});
      Navigator.pop(context);
    } else {
      widget.state.setState(() {});
      Navigator.pop(context);
    }
    ClubServices.editClub(widget.club);
  }

  bool imageChanged = false;
  String file = '';
  late TextEditingController nameController;
  late TextEditingController locationController;
  late TextEditingController descriptionController;

  @override
  void initState() {
    nameController = TextEditingController(
      text: widget.club.name,
    );
    locationController = TextEditingController(
      text: widget.club.location,
    );
    descriptionController = TextEditingController(
      text: widget.club.about,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            Text(
              'Edit Club',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.5,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            GestureDetector(
              onTap: () {
                editClub();
              },
              child: Text(
                'Done',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Club logo',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(
                SizeConfig.widthMultiplier! * 0.3,
              ), // Border width
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(
                  10,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(
                  10,
                ),
                child: SizedBox.fromSize(
                  size: Size.fromRadius(
                    SizeConfig.widthMultiplier! * 15,
                  ),
                  child: file == ''
                      ? Image.network(
                          widget.club.icon,
                          fit: BoxFit.cover,
                        )
                      : Image.asset(
                          file,
                          fit: BoxFit.cover,
                        ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                changeImage();
              },
              child: Container(
                height: SizeConfig.heightMultiplier! * 4,
                width: SizeConfig.widthMultiplier! * 25,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.upload_rounded,
                      size: SizeConfig.imageSizeMultiplier! * 6,
                      color: Colors.grey.shade400,
                    ),
                    SizedBox(
                      width: SizeConfig.widthMultiplier! * 1,
                    ),
                    Text(
                      'Upload',
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2.3,
                        fontWeight: FontWeight.w400,
                        color: Colors.grey.shade400,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Name',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: nameController,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Location',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: locationController,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Description',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          height: SizeConfig.heightMultiplier! * 25,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: descriptionController,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
