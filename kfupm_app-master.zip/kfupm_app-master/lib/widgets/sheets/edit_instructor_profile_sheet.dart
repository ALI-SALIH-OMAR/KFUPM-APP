import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/edite_instructor_profile_controller.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/time_picker.dart';

class EditInstructorProfileSheet extends StatefulWidget {
  const EditInstructorProfileSheet({Key? key}) : super(key: key);

  @override
  _EditInstructorProfileSheetState createState() => _EditInstructorProfileSheetState();
}

class _EditInstructorProfileSheetState extends State<EditInstructorProfileSheet> {
  EditInstructorProfileController editInstructorProfileController = EditInstructorProfileController();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            Text(
              'Edit Profile',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.5,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            GestureDetector(
              onTap: () {
                editInstructorProfileController.changeProfile();
                Navigator.pop(context);
              },
              child: Text(
                'Done',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Email Address',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: editInstructorProfileController.email,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Office',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: editInstructorProfileController.office,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Office hours',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Text(
          'From',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        TimePicker(
          isFirst: true,
          isInstructorProfile: true,
          editInstructorProfileController: editInstructorProfileController,
          datePasses: editInstructorProfileController.timeTo,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Text(
          'To',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        TimePicker(
          isFirst: false,
          isInstructorProfile: true,
          editInstructorProfileController: editInstructorProfileController,
          datePasses: editInstructorProfileController.timeFrom,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Text(
          'Days',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Row(
          children: [
            GestureDetector(
              onTap: () {
                setState(() {
                  editInstructorProfileController.dOne = !editInstructorProfileController.dOne;
                });
              },
              child: Container(
                padding: EdgeInsets.all(
                  SizeConfig.widthMultiplier! * 4,
                ),
                decoration: BoxDecoration(
                  color: editInstructorProfileController.dOne ? AppColors.primaryColor : Colors.white,
                  border: Border.all(
                    width: SizeConfig.widthMultiplier! * 0.3,
                    color: Colors.grey.shade200,
                  ),
                ),
                child: Text(
                  'U',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  editInstructorProfileController.dTwo = !editInstructorProfileController.dTwo;
                });
              },
              child: Container(
                padding: EdgeInsets.all(
                  SizeConfig.widthMultiplier! * 4,
                ),
                decoration: BoxDecoration(
                  color: editInstructorProfileController.dTwo ? AppColors.primaryColor : Colors.white,
                  border: Border.all(
                    width: SizeConfig.widthMultiplier! * 0.3,
                    color: Colors.grey.shade200,
                  ),
                ),
                child: Text(
                  'M',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  editInstructorProfileController.dThree = !editInstructorProfileController.dThree;
                });
              },
              child: Container(
                padding: EdgeInsets.all(
                  SizeConfig.widthMultiplier! * 4,
                ),
                decoration: BoxDecoration(
                  color: editInstructorProfileController.dThree ? AppColors.primaryColor : Colors.white,
                  border: Border.all(
                    width: SizeConfig.widthMultiplier! * 0.3,
                    color: Colors.grey.shade200,
                  ),
                ),
                child: Text(
                  'T',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  editInstructorProfileController.dFour = !editInstructorProfileController.dFour;
                });
              },
              child: Container(
                padding: EdgeInsets.all(
                  SizeConfig.widthMultiplier! * 4,
                ),
                decoration: BoxDecoration(
                  color: editInstructorProfileController.dFour ? AppColors.primaryColor : Colors.white,
                  border: Border.all(
                    width: SizeConfig.widthMultiplier! * 0.3,
                    color: Colors.grey.shade200,
                  ),
                ),
                child: Text(
                  'W',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  editInstructorProfileController.dFive = !editInstructorProfileController.dFive;
                });
              },
              child: Container(
                padding: EdgeInsets.all(
                  SizeConfig.widthMultiplier! * 4,
                ),
                decoration: BoxDecoration(
                  color: editInstructorProfileController.dFive ? AppColors.primaryColor : Colors.white,
                  border: Border.all(
                    width: SizeConfig.widthMultiplier! * 0.3,
                    color: Colors.grey.shade200,
                  ),
                ),
                child: Text(
                  'R',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
