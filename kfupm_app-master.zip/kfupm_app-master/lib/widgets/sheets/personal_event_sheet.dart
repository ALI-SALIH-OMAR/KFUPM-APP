import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/controllers/personal_event_controller.dart';
import 'package:kfupm_app/entities/event_personal.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/services/firebase/section_services.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/edit_personal_event_sheet.dart';

class PersonalEventSheet extends StatelessWidget {
  const PersonalEventSheet({
    Key? key,
    required this.eventPersonal,
    this.isCreator = false,
  }) : super(key: key);
  final EventPersonal? eventPersonal;
  final bool isCreator;

  openSheetTwoEdit(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: EditPersonalEventSheet(
        title: 'Edit Task',
        eventPersonal: eventPersonal,
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  int calcDuration(){
    String timeFrom = eventPersonal!.timeFrom + 'E';
    String timeTo = eventPersonal!.timeTo + 'E';
    int h1 = 0;
    int m1 = 0;

    if(isNumeric(timeFrom.substring(0,2))){
      h1 = int.parse(timeFrom.substring(0,2));
    } else {
      h1 = int.parse(timeFrom.substring(0,1));
    }

    if (isNumeric(timeFrom.substring(2,4))){
      m1 = int.parse(timeFrom.substring(2,4));
    } else if(isNumeric(timeFrom.substring(2,3))){
      m1 = int.parse(timeFrom.substring(2,3));
    } else if (isNumeric(timeFrom.substring(3,5))){
      m1 = int.parse(timeFrom.substring(3,5));
    } else {
      m1 = int.parse(timeFrom.substring(3,4));
    }

    int h2 = 0;
    int m2 = 0;

    if(isNumeric(timeTo.substring(0,2))){
      h2 = int.parse(timeTo.substring(0,2));
    } else {
      h2 = int.parse(timeTo.substring(0,1));
    }

    if (isNumeric(timeTo.substring(2,4))){
      m2 = int.parse(timeTo.substring(2,4));
    } else if(isNumeric(timeTo.substring(2,3))){
      m2 = int.parse(timeTo.substring(2,3));
    } else if (isNumeric(timeTo.substring(3,5))){
      m2 = int.parse(timeTo.substring(3,5));
    } else {
      m2 = int.parse(timeTo.substring(3,4));
    }

    int total = ((h1 - h2) * 60) + (m1 - m2);

    return total;
  }

  bool isNumeric(String s) {
    if(s == null) {
      return false;
    }
    return double.tryParse(s) != null;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (isCreator) ...[
              GestureDetector(
                onTap: () async {
                  await openSheetTwoEdit(context);
                },
                child: Text(
                  'Edit',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.3,
                    fontWeight: FontWeight.w400,
                    color: AppColors.primaryColor,
                  ),
                ),
              ),
            ],
            if (!isCreator) ...[
              SizedBox(
                width: SizeConfig.widthMultiplier! * 10,
              ),
            ],
            Text(
              'View Task',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.5,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Text(
                'Done',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          eventPersonal!.title,
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Date',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        GestureDetector(
          onTap: () {},
          child: Row(
            children: [
              Text(
                '${eventPersonal!.date.day}/${eventPersonal!.date.month}/${eventPersonal!.date.year}',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.1,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
              SizedBox(
                width: SizeConfig.widthMultiplier! * 2,
              ),
              Icon(
                Icons.arrow_forward_ios,
                size: SizeConfig.imageSizeMultiplier! * 4,
              ),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Time',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        GestureDetector(
          onTap: () {},
          child: Row(
            children: [
              Text(
                '${eventPersonal!.timeFrom} - ${eventPersonal!.timeTo} (${calcDuration()} mins)',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.1,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Location',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Text(
          eventPersonal!.location,
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.1,
            fontWeight: FontWeight.w400,
            color: AppColors.primaryColor,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Material',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        GestureDetector(
          onTap: () {},
          child: Row(
            children: [
              Text(
                eventPersonal!.material,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.1,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Structure',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        GestureDetector(
          onTap: () {},
          child: Row(
            children: [
              Text(
                eventPersonal!.structure,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.1,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Notes',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        GestureDetector(
          onTap: () {},
          child: Row(
            children: [
              Expanded(
                child: Text(
                  eventPersonal!.note,
                  maxLines: null,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.1,
                    fontWeight: FontWeight.w400,
                    color: AppColors.primaryColor,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 5,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Posted by ',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2,
                fontWeight: FontWeight.w400,
                color: Colors.grey,
              ),
            ),
            Text(
              eventPersonal!.creator,
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2,
                fontWeight: FontWeight.w400,
                color: Colors.grey,
              ),
            ),
            Text(
              ' ${DateTime.now().difference(eventPersonal!.timeCreated).inDays + 1} days ago',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2,
                fontWeight: FontWeight.w400,
                color: Colors.grey,
              ),
            ),
          ],
        ),
        if (isCreator) ...[
          SizedBox(
            height: SizeConfig.heightMultiplier! * 3,
          ),
          Center(
            child: GestureDetector(
              onTap: () async {
                if (eventPersonal!.crn != 'null') {
                  Section section = await SectionServices.getSection(eventPersonal!.crn);
                  PersonalEventController.deleteEventForSection(
                      eventPersonal!, section.crn, section.studentIDs, GlobalController.instructor!.email);
                } else if (GlobalController.stu) {
                  PersonalEventController.deleteEvent(eventPersonal!);
                } else {
                  PersonalEventController.deleteEventToInstructor(eventPersonal!);
                }
                Navigator.pop(context);
              },
              child: Container(
                padding: EdgeInsets.symmetric(
                  vertical: SizeConfig.heightMultiplier! * 1,
                  horizontal: SizeConfig.widthMultiplier! * 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.red.shade100,
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                ),
                child: Text(
                  'Delete Event',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.1,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                  ),
                ),
              ),
            ),
          ),
        ],
      ],
    );
  }
}
