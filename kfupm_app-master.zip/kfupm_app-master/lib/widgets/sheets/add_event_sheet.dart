import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/add_event_controller.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/image_picking.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/date_picker.dart';
import 'package:kfupm_app/widgets/time_picker.dart';

class AddEventSheet extends StatefulWidget {
  const AddEventSheet({
    Key? key,
    required this.clubName,
    required this.state,
    required this.clubModel,
  }) : super(key: key);
  final String clubName;
  final State state;
  final ClubModel clubModel;

  @override
  State<AddEventSheet> createState() => _AddEventSheetState();
}

class _AddEventSheetState extends State<AddEventSheet> {
  bool imageChanged = false;
  String file = '';
  late AddEventController addEventController;

  void addImage() async {
    file = await imagePicking();
    imageChanged = true;
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    addEventController = AddEventController();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            Text(
              'Edit Club',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.5,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            GestureDetector(
              onTap: () {
                addEventController.addEvent(
                  file,
                  widget.clubName,
                  widget.state,
                  widget.clubModel,
                );
                Navigator.pop(context);
              },
              child: Text(
                'Done',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Event Poster',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Stack(
          alignment: Alignment.center,
          children: [
            GestureDetector(
              onTap: () {
                addImage();
              },
              child: Container(
                height: SizeConfig.heightMultiplier! * 4,
                width: SizeConfig.widthMultiplier! * 25,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.upload_rounded,
                      size: SizeConfig.imageSizeMultiplier! * 6,
                      color: Colors.grey.shade400,
                    ),
                    SizedBox(
                      width: SizeConfig.widthMultiplier! * 1,
                    ),
                    Text(
                      'Upload',
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2.3,
                        fontWeight: FontWeight.w400,
                        color: Colors.grey.shade400,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Title',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: addEventController.title,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Date',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        DatePicker(
          addEventController: addEventController,
          isEvent: true,
        ),
        Text(
          'Time',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Text(
          'From',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        TimePicker(
          addEventController: addEventController,
          isFirst: true,
          isEvent: true,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Text(
          'To',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        TimePicker(
          addEventController: addEventController,
          isFirst: false,
          isEvent: true,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Location',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: addEventController.location,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Note',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: addEventController.notes,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
      ],
    );
  }
}
