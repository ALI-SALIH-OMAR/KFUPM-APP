import 'package:flutter/material.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../constants/locations.dart';

class LocationSheet extends StatelessWidget {
  const LocationSheet({Key? key, required this.label}) : super(key: key);
 final String label;
  @override
  Widget build(BuildContext context, ) {
    Location? locationInfo = SavedLocation().locations[label];
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              padding: EdgeInsets.all(
                SizeConfig.widthMultiplier! * 1,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  color: Colors.grey.shade300,
                  width: 1,
                ),
                borderRadius: const BorderRadius.all(
                  Radius.circular(10),
                ),
              ),
              child: Text(
                locationInfo!.markerNum,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 3.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 3,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    locationInfo.building,
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    locationInfo.about,
                    maxLines: null,
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2.1,
                      fontWeight: FontWeight.w400,
                      color: Colors.black38,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Image.network(
          locationInfo.image,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Row(
          children: [
            Icon(
              Icons.info,
              color: Colors.black45,
              size: SizeConfig.imageSizeMultiplier! * 5,
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 5,
            ),
            Text(
              'Info',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.4,
                fontWeight: FontWeight.w400,
                color: Colors.black38,
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 1.5,
        ),
        Row(
          children: [
            SizedBox(
              width: SizeConfig.widthMultiplier! * 10,
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Lab: ${locationInfo.lab}',
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2.1,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 1,
                  ),
                  Text(
                    'Cafeteria: ${locationInfo.cafeteria}',
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2.1,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 1,
                  ),
                  Text(
                    'Parking Lot: ${locationInfo.parking}',
                    maxLines: null,
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2.1,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        const Divider(
          color: Colors.black26,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 1,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              PhosphorIcons.map_trifold_fill,
              color: AppColors.primaryColor,
              size: SizeConfig.imageSizeMultiplier! * 10,
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 5,
            ),
            TextButton(
              onPressed: () async {
                 var url = 'https://www.google.com/maps/search/?api=1&query=${locationInfo.lat},${locationInfo.lon}';
                if (await canLaunch(url)) {
                  await launch(url);
                } else {
                  throw 'Could not launch $url';
                }
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.transparent),
              ),
              child: Text(
                'Open in Map ',
                style: TextStyle(
                  fontWeight: FontWeight.w400,
                  fontSize: SizeConfig.textMultiplier! * 2.5,
                  color: Colors.black,
                ),
              ),
            )
          ],
        ),
      ],
    );
  }
}
