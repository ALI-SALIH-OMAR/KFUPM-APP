import 'package:flutter/material.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';

bottomSheet({
  required BuildContext context,
  required Widget child,
  required double bottomPadding,
  required bool showBottomButton,
  required Widget bottomButton,
  double height = 70,
}) async {
  return showModalBottomSheet(
    isScrollControlled: true,
    elevation: 0,
    backgroundColor: Colors.transparent,
    context: context,
    isDismissible: true,
    builder: (context) => AnimatedContainer(
      duration: const Duration(
        milliseconds: 200,
      ),
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(10),
        ),
        color: Colors.white,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: SizeConfig.widthMultiplier! * 6,
      ),
      child: SizedBox(
        height: SizeConfig.heightMultiplier! * height,
        child: Stack(
          children: [
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 3,
                  ),
                  child,
                  SizedBox(
                    height: bottomPadding,
                  )
                ],
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 1,
              left: SizeConfig.widthMultiplier! * 38,
              child: Container(
                height: 5,
                width: 40,
                decoration: BoxDecoration(
                  color: AppColors.primaryColor,
                  borderRadius: const BorderRadius.all(
                    Radius.circular(10),
                  ),
                ),
              ),
            ),
            if (showBottomButton)
              Positioned(
                bottom: SizeConfig.heightMultiplier! * 5,
                left: SizeConfig.widthMultiplier! * 0,
                right: SizeConfig.widthMultiplier! * 0,
                child: bottomButton,
              ),
          ],
        ),
      ),
    ),
  );
}
