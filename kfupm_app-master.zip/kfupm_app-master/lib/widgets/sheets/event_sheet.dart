import 'package:flutter/material.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/services/firebase/student_services.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/buttons/add_to_calendar.dart';

import '../../deep_links/dynamic_link_services.dart';
import '../../deep_links/sharing_screen.dart';
import '../../services/firebase/instructor_services.dart';

class EventSheet extends StatelessWidget {
  const EventSheet({
    Key? key,
    required this.event,
    this.showAddToCalendarButton = false,
    this.showDeleteButton = false,
  }) : super(key: key);
  final Event? event;
  final bool showAddToCalendarButton;
  final bool showDeleteButton;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: symmetricInsets(
                horizontal: 0.5,
                vertical: 0.5,
              ),
              decoration: BoxDecoration(
                color: Colors.transparent,
                borderRadius: Constant.borderRadiusSmall,
              ),
            ),
            Row(
              children: [
                GestureDetector(
                  onTap: () async {
                    //creating deep link for the event
                    String link = await FireBaseDynamicLink.creatingDynamicLink(true, event!.organizer, event!.title);
                    // sharing window
                    SharingScreenServices.share(event!.organizer, event!.title, link);
                    //print(link.toString());
                  },
                  child: Icon(
                    PhosphorIcons.export,
                    size: SizeConfig.imageSizeMultiplier! * 5,
                    color: AppColors.primaryColor,
                  ),
                ),
                SizedBox(
                  width: SizeConfig.widthMultiplier! * 5,
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Text(
                    'Done',
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2.3,
                      fontWeight: FontWeight.w400,
                      color: AppColors.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        SizedBox(
          child: Text(
            event!.title,
            maxLines: 2,
            overflow: TextOverflow.clip,
            style: TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: SizeConfig.textMultiplier! * 3,
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        ClipRRect(
          borderRadius: BorderRadius.circular(
            10,
          ),
          child: InteractiveViewer(
            clipBehavior: Clip.antiAlias,
            child: Image.network(
              event!.image,
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Organizer',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 1,
        ),
        Text(
          event!.organizer,
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.1,
            fontWeight: FontWeight.w400,
            color: Colors.black,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Date',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Text(
          '${event!.date.day}/${event!.date.month}/${event!.date.year}',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.1,
            fontWeight: FontWeight.w400,
            color: Colors.black,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Time',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Row(
          children: [
            Text(
              event!.time,
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.1,
                fontWeight: FontWeight.w400,
                color: Colors.black,
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Location',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Text(
          event!.location,
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.1,
            fontWeight: FontWeight.w400,
            color: Colors.black,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 2,
        ),
        Text(
          'Notes',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        GestureDetector(
          onTap: () {},
          child: Row(
            children: [
              Expanded(
                child: Text(
                  event!.note,
                  maxLines: null,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.1,
                    fontWeight: FontWeight.w400,
                    color: Colors.black,
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        if (showAddToCalendarButton)
          AddToCalendar(
            event: event!,
          ),
        if (showDeleteButton) ...[
          SizedBox(
            height: SizeConfig.heightMultiplier! * 3,
          ),
          Center(
            child: GestureDetector(
              onTap: () async {
                if(GlobalController.stu){
                StudentServices.deleteEventToCalendar(event!.toMap());
                GlobalController.student!.events.remove(event!);
                }
                else{
                  InstructorServices.deleteEventToCalendar(event!.toMap());
                  GlobalController.instructor!.event.remove(event!);
                }
                GlobalController.calendarController.setUp();
                GlobalController.calendarState.setState(() {});
                Navigator.pop(context);
              },
              child: Container(
                padding: EdgeInsets.symmetric(
                  vertical: SizeConfig.heightMultiplier! * 1,
                  horizontal: SizeConfig.widthMultiplier! * 5,
                ),
                decoration: BoxDecoration(
                  color: Colors.red.shade100,
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                ),
                child: Text(
                  'Delete Event',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.1,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                  ),
                ),
              ),
            ),
          ),
        ]
      ],
    );
  }
}
