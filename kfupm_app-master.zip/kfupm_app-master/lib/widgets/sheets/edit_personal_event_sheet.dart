import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/controllers/personal_event_controller.dart';
import 'package:kfupm_app/entities/event_personal.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/widgets/date_picker.dart';
import 'package:kfupm_app/widgets/time_picker.dart';

import '../../utils/size_config.dart';

class EditPersonalEventSheet extends StatefulWidget {
  const EditPersonalEventSheet({
    Key? key,
    required this.title,
    this.isSection = false,
    this.section,
    this.eventPersonal,
  }) : super(key: key);
  final String title;
  final bool isSection;
  final Section? section;
  final EventPersonal? eventPersonal;

  @override
  _EditPersonalEventSheetState createState() => _EditPersonalEventSheetState();
}

class _EditPersonalEventSheetState extends State<EditPersonalEventSheet> {
  late PersonalEventController personalEventController;

  @override
  void initState() {
    personalEventController = PersonalEventController();
    if(widget.eventPersonal != null){
      personalEventController.title.text = widget.eventPersonal!.title;
      personalEventController.date = widget.eventPersonal!.date;
      personalEventController.timeTo = widget.eventPersonal!.timeTo;
      personalEventController.timeFrom = widget.eventPersonal!.timeFrom;
      personalEventController.notes.text = widget.eventPersonal!.note;
      personalEventController.structure.text = widget.eventPersonal!.structure;
      personalEventController.material.text = widget.eventPersonal!.material;
      personalEventController.location.text = widget.eventPersonal!.location;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
            Text(
              widget.title,
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.5,
                fontWeight: FontWeight.w600,
                color: Colors.black,
              ),
            ),
            GestureDetector(
              onTap: () {
                if (widget.isSection) {
                  personalEventController.addEventForSection(
                      widget.section!.crn, widget.section!.studentIDs, GlobalController.instructor!.email);
                } else if (GlobalController.stu) {
                  personalEventController.addEvent();
                } else {
                  personalEventController.addEventToInstructor();
                }
                Navigator.pop(context);
              },
              child: Text(
                'Done',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2.3,
                  fontWeight: FontWeight.w400,
                  color: AppColors.primaryColor,
                ),
              ),
            ),
          ],
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Title',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: personalEventController.title,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Date',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        DatePicker(
          personalEventController: personalEventController,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Time',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        Text(
          'From',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        TimePicker(
          personalEventController: personalEventController,
          isFirst: true,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Text(
          'To',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        TimePicker(
          personalEventController: personalEventController,
          isFirst: false,
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Location',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: personalEventController.location,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Material',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: personalEventController.material,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Structure',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: personalEventController.structure,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 3,
        ),
        Text(
          'Notes',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2,
            fontWeight: FontWeight.w400,
            color: Colors.grey,
          ),
        ),
        SizedBox(
          height: SizeConfig.heightMultiplier! * 0.5,
        ),
        Container(
          height: SizeConfig.heightMultiplier! * 25,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
              color: Colors.grey.shade400,
            ),
          ),
          child: TextFormField(
            controller: personalEventController.notes,
            textAlignVertical: TextAlignVertical.top,
            keyboardType: TextInputType.multiline,
            maxLines: null,
            style: TextStyle(
              color: Colors.black,
              fontSize: SizeConfig.textMultiplier! * 2.2,
              fontWeight: FontWeight.w400,
              height: 1.1,
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 2,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
