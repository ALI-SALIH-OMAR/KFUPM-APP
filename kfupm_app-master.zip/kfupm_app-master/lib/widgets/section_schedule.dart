import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/screens/section.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';

class SectionSchedule extends StatelessWidget {
  const SectionSchedule({
    Key? key,
    required this.positionX,
    required this.positionY,
    required this.name,
    required this.number,
    required this.crn,
    required this.height,
  }) : super(key: key);
  final int positionX;
  final int positionY;
  final String name;
  final int number;
  final String crn;
  final int height;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: SizeConfig.heightMultiplier! * positionY,
      left: SizeConfig.widthMultiplier! * positionX,
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            GlobalController.passedContext,
            MaterialPageRoute(
              builder: (context) => SectionScreen(
                returnPage: 'Schedule',
                crn: crn,
              ),
            ),
          );
        },
        child: Container(
          height: SizeConfig.heightMultiplier! * height,
          width: SizeConfig.widthMultiplier! * 17,
          color: Colors.redAccent,
          padding: EdgeInsets.symmetric(
            horizontal: SizeConfig.widthMultiplier! * 1,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: SizeConfig.heightMultiplier! * 0.5,
              ),
              Text(
                name,
                maxLines: 3,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 1.5,
                  fontWeight: FontWeight.w700,
                  color: AppColors.white,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              SizedBox(
                height: SizeConfig.heightMultiplier! * 1,
              ),
              Text(
                'Sec $number',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 1.5,
                  fontWeight: FontWeight.w500,
                  color: AppColors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
