import 'package:flutter/material.dart';

import 'package:kfupm_app/utils/size_config.dart';

///This is the search bar widget that has been used in all types.
class SearchTextField extends StatelessWidget {
  const SearchTextField(
      {Key? key,
      required this.textEditingController,
      this.passedFunction,
      this.searchFunction})
      : super(key: key);
  final TextEditingController textEditingController;
  final dynamic passedFunction;
  final dynamic searchFunction;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: SizeConfig.widthMultiplier! * 2,
        vertical: SizeConfig.heightMultiplier! * 0.5,
      ),
      height: SizeConfig.heightMultiplier! * 5,
      width: SizeConfig.widthMultiplier! * 88,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(
          color: Colors.grey.shade300,
          width: SizeConfig.widthMultiplier! * 0.2,
        ),
      ),
      child: TextFormField(
        onChanged: (value) {
          searchFunction(value);
        },
        onTap: passedFunction,
        controller: textEditingController,
        textAlignVertical: TextAlignVertical.top,
        style: TextStyle(
          color: Colors.black,
          fontSize: SizeConfig.textMultiplier! * 2.5,
        ),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: 'Search',
          hintStyle: TextStyle(
            color: Colors.grey.shade500,
            fontSize: SizeConfig.textMultiplier! * 2.5,
          ),
          contentPadding: EdgeInsets.symmetric(
            vertical: SizeConfig.heightMultiplier! * 1,
          ),
          icon: Icon(
            Icons.search,
            size: SizeConfig.imageSizeMultiplier! * 8,
            color: Colors.grey.shade500,
          ),
          suffixIcon: GestureDetector(
            onTap: () {
              textEditingController.clear();
              searchFunction("freeUPTheSearchBar");
            },
            child: Icon(
              Icons.cancel,
              color: Colors.grey.shade500,
              size: SizeConfig.imageSizeMultiplier! * 8,
            ),
          ),
        ),
      ),
    );
  }
}
