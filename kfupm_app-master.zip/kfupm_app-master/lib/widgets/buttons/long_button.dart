/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is a long button which is used to login.
Note: Noting.
 */
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:rounded_loading_button/rounded_loading_button.dart';

import '../../services/firebase/auth_services.dart';

class LongButton extends StatefulWidget {
  const LongButton({Key? key, required this.textEditingControllerOne, required this.textEditingControllerTwo})
      : super(key: key);

  final TextEditingController textEditingControllerOne;
  final TextEditingController textEditingControllerTwo;

  @override
  State<LongButton> createState() => _LongButtonState();
}

class _LongButtonState extends State<LongButton> {
  late final RoundedLoadingButtonController _roundedLoadingButtonController;
  FirebaseAuth? auth;

  @override
  void initState() {
    auth = FirebaseAuth.instance;
    _roundedLoadingButtonController = RoundedLoadingButtonController();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RoundedLoadingButton(
      height: SizeConfig.heightMultiplier! * 5.5,
      width: SizeConfig.widthMultiplier! * 88,
      onPressed: () async {
        try {
          await AuthServices.userAuth(
            widget.textEditingControllerOne.text,
            widget.textEditingControllerTwo.text,
          );
        } on FirebaseAuthException catch (e) {
          if (e.code == 'user-not-found') {
          } else if (e.code == 'wrong-password') {}
          _roundedLoadingButtonController.error();
          await Future.delayed(const Duration(seconds: 2), () {});
          _roundedLoadingButtonController.reset();
        }
      },
      controller: _roundedLoadingButtonController,
      borderRadius: 10,
      color: const Color(0xFF25794F),
      valueColor: Colors.white,
      elevation: 0,
      successColor: const Color(0xFF25794F),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          'Sign in',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: SizeConfig.textMultiplier! * 2.5,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
