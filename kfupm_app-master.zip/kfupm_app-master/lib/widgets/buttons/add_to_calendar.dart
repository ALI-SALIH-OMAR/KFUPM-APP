import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/services/firebase/student_services.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';

import '../../entities/event.dart';

List<Map<String, dynamic>> getMap() {
  return List<Map<String, dynamic>>.generate(
      GlobalController.student!.events.length, (int index) => GlobalController.student!.events[index].toMap());
}

class AddToCalendar extends StatelessWidget {
  const AddToCalendar({
    Key? key,
    required this.event,
  }) : super(key: key);
  final Event event;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        GlobalController.student!.events.add(event);
        GlobalController.calendarController.setUp();
        GlobalController.calendarState.setState(() {});
        StudentServices.addEventToCalendar(getMap());
        Navigator.pop(context);
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.heightMultiplier! * 1,
          horizontal: SizeConfig.widthMultiplier! * 2,
        ),
        decoration: BoxDecoration(
          color: AppColors.primaryColor,
          borderRadius: BorderRadius.circular(
            10,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.add,
              color: AppColors.white,
              size: SizeConfig.imageSizeMultiplier! * 8,
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 2,
            ),
            Text(
              'Add to Calendar',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 2.3,
                fontWeight: FontWeight.w600,
                color: AppColors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
