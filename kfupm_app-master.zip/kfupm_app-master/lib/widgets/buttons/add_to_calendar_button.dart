import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/event_controllers.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/services/firebase/student_services.dart';
import 'package:kfupm_app/utils/size_config.dart';

import '../../theme/app_colors.dart';

class AddToCalendarButton extends StatefulWidget {
  AddToCalendarButton({
    Key? key,
    required this.event,
    required this.added,
  }) : super(key: key);
  final Event event;
  bool added;

  @override
  State<AddToCalendarButton> createState() => _AddToCalendarButtonState();
}

class _AddToCalendarButtonState extends State<AddToCalendarButton> {

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          widget.added = true;
        });
        if (!widget.added ||
            !EventController.isAddedEvent(
              widget.event,
            )) {
          EventController.addEventToCalendar(widget.event);
        } else {
          setState(() {
            widget.added = false;
          });
          StudentServices.deleteEventToCalendar(widget.event.toMap());
          GlobalController.student!.events.remove(widget.event);
          GlobalController.calendarController.setUp();
          GlobalController.calendarState.setState(() {});
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.widthMultiplier! * 1,
          vertical: SizeConfig.heightMultiplier! * 0.2,
        ),
        decoration: BoxDecoration(
          color: widget.added ||
                  EventController.isAddedEvent(
                    widget.event,
                  )
              ? Colors.white30
              : Colors.white,
          borderRadius: BorderRadius.circular(
            5,
          ),
          border: Border.all(
            width: widget.added ||
                    EventController.isAddedEvent(
                      widget.event,
                    )
                ? SizeConfig.widthMultiplier! * 0.5
                : 0,
            color: Colors.grey.shade500,
          ),
        ),
        child: Row(
          children: [
            Icon(
              widget.added ||
                      EventController.isAddedEvent(
                        widget.event,
                      )
                  ? Icons.check
                  : Icons.add,
              color: widget.added ? Colors.white : AppColors.primaryColor,
              size: SizeConfig.imageSizeMultiplier! * 5,
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 1,
            ),
            Text(
              widget.added ||
                      EventController.isAddedEvent(
                        widget.event,
                      )
                  ? 'ADDED'
                  : 'ADD TO CALENDAR',
              style: TextStyle(
                color: widget.added ? Colors.white : AppColors.primaryColor,
                fontSize: SizeConfig.textMultiplier! * 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
