import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/event_controllers.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/utils/size_config.dart';

import '../../services/firebase/instructor_services.dart';
import '../../theme/app_colors.dart';

class AddToCalendarButtonIns extends StatefulWidget {
  AddToCalendarButtonIns({
    Key? key,
    required this.event,
    required this.added,
  }) : super(key: key);
  final Event event;
  bool added;

  @override
  State<AddToCalendarButtonIns> createState() => _AddToCalendarButtonInsState();
}

class _AddToCalendarButtonInsState extends State<AddToCalendarButtonIns> {

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          widget.added = true;
        });
        if (!widget.added ||
            !EventController.isAddedEventIns(
              widget.event,
            )) {
          EventController.addEventToCalendarIns(widget.event);
        } else {
          setState(() {
            widget.added = false;
          });
          InstructorServices.deleteEventToCalendar(widget.event.toMap());
          GlobalController.instructor!.event.remove(widget.event);
          GlobalController.calendarController.setUp();
          GlobalController.calendarState.setState(() {});
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: SizeConfig.widthMultiplier! * 1,
          vertical: SizeConfig.heightMultiplier! * 0.2,
        ),
        decoration: BoxDecoration(
          color: widget.added ||
              EventController.isAddedEventIns(
                widget.event,
              )
              ? Colors.white30
              : Colors.white,
          borderRadius: BorderRadius.circular(
            5,
          ),
          border: Border.all(
            width: widget.added ||
                EventController.isAddedEventIns(
                  widget.event,
                )
                ? SizeConfig.widthMultiplier! * 0.5
                : 0,
            color: Colors.grey.shade500,
          ),
        ),
        child: Row(
          children: [
            Icon(
              widget.added ||
                  EventController.isAddedEventIns(
                    widget.event,
                  )
                  ? Icons.check
                  : Icons.add,
              color: widget.added ? Colors.white : AppColors.primaryColor,
              size: SizeConfig.imageSizeMultiplier! * 5,
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 1,
            ),
            Text(
              widget.added ||
                  EventController.isAddedEventIns(
                    widget.event,
                  )
                  ? 'ADDED'
                  : 'ADD TO CALENDAR',
              style: TextStyle(
                color: widget.added ? Colors.white : AppColors.primaryColor,
                fontSize: SizeConfig.textMultiplier! * 1.5,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
