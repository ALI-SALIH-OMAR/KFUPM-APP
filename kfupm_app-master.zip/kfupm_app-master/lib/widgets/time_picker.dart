import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/add_event_controller.dart';
import 'package:kfupm_app/controllers/edite_instructor_profile_controller.dart';
import 'package:kfupm_app/controllers/personal_event_controller.dart';
import 'package:kfupm_app/utils/size_config.dart';

class TimePicker extends StatefulWidget {
  TimePicker({
    Key? key,
    required this.isFirst,
    this.personalEventController,
    this.isInstructorProfile = false,
    this.editInstructorProfileController,
    this.addEventController,
    this.isEvent = false,
    this.datePasses = '',
  }) : super(key: key);
  final bool isFirst;
  final PersonalEventController? personalEventController;
  final bool isInstructorProfile;
  final EditInstructorProfileController? editInstructorProfileController;
  final AddEventController? addEventController;
  final bool isEvent;
  String datePasses;

  @override
  State<TimePicker> createState() => _TimePickerState();
}

class _TimePickerState extends State<TimePicker> {
  TimeOfDay chosenDate = TimeOfDay.now();

  Future timePicker() {
    return showTimePicker(
      context: context,
      initialTime: chosenDate,
      initialEntryMode: TimePickerEntryMode.input,
      confirmText: "Confirm",
      cancelText: "Cancel",
      helpText: "Event Time",
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        TimeOfDay temp = await timePicker();
        setState(() {
          chosenDate = temp;
          if(widget.datePasses != ''){
            widget.datePasses = chosenDate.format(context).toString();
          }
        });
        if(widget.isInstructorProfile){
          if(widget.isFirst){
            widget.editInstructorProfileController!.setTimeFrom(chosenDate);
          } else {
            widget.editInstructorProfileController!.setTimeTo(chosenDate);
          }
        } else if(widget.isEvent){
          if(widget.isFirst){
            widget.addEventController!.setTimeFrom(chosenDate);
          } else {
            widget.addEventController!.setTimeTo(chosenDate);
          }
        } else {
          if(widget.isFirst){
            widget.personalEventController!.setTimeFrom(chosenDate);
          } else {
            widget.personalEventController!.setTimeTo(chosenDate);
          }
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.widthMultiplier! * 4,
          horizontal: SizeConfig.heightMultiplier! * 1,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
          border: Border.all(
            color: Colors.grey.shade400,
          ),
        ),
        child: Row(
          children: [
            Text(
              widget.datePasses == '' ? chosenDate.format(context).toString() : widget.datePasses,
              style: TextStyle(
                color: Colors.black,
                fontSize: SizeConfig.textMultiplier! * 2.2,
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 2,
            ),
            Icon(
              Icons.arrow_forward_ios,
              size: SizeConfig.imageSizeMultiplier! * 4,
              color: Colors.black,
            ),
          ],
        ),
      ),
    );
  }
}
