import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kfupm_app/controllers/add_event_controller.dart';
import 'package:kfupm_app/controllers/personal_event_controller.dart';
import 'package:kfupm_app/utils/size_config.dart';

class DatePicker extends StatefulWidget {
  const DatePicker({
    Key? key,
    this.personalEventController,
    this.addEventController,
    this.isEvent = false,
  }) : super(key: key);
  final PersonalEventController? personalEventController;
  final AddEventController? addEventController;
  final bool isEvent;

  @override
  _DatePickerState createState() => _DatePickerState();
}

class _DatePickerState extends State<DatePicker> {
  DateTime chosenDate = DateTime.now();

  Future datePicker() {
    return showDatePicker(
      context: context,
      initialDate: chosenDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(
        const Duration(
          days: 100,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        DateTime temp = await datePicker();
        setState(() {
          chosenDate = temp;
        });
        if(widget.isEvent){
          widget.addEventController!.setDate(chosenDate);
        } else {
          widget.personalEventController!.setDate(chosenDate);
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.widthMultiplier! * 2,
          horizontal: SizeConfig.heightMultiplier! * 1,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
          border: Border.all(
            color: Colors.grey.shade400,
          ),
        ),
        child: Row(
          children: [
            Text(
              DateFormat('EEEE, d/M/yyyy').format(
                chosenDate,
              ),
              style: TextStyle(
                color: Colors.black,
                fontSize: SizeConfig.textMultiplier! * 2.2,
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(
              width: SizeConfig.widthMultiplier! * 2,
            ),
            Icon(
              Icons.arrow_forward_ios,
              size: SizeConfig.imageSizeMultiplier! * 4,
              color: Colors.black,
            ),
          ],
        ),
      ),
    );
  }
}
