/*
Author: Saud Elabdullah.
Work: This class work as a widget to show the list of
department as a dropdownMenu.
Note: Nothing.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/courses_controller.dart';
import 'package:kfupm_app/utils/size_config.dart';

class DropdownMenu extends StatefulWidget {
  const DropdownMenu({
    Key? key,
    required this.departments,
    required this.coursesController,
    required this.state,
  }) : super(key: key);
  final List<String>? departments;
  final CoursesController? coursesController;
  final State state;

  @override
  _DropdownMenuState createState() => _DropdownMenuState();
}

class _DropdownMenuState extends State<DropdownMenu> {
  String? dropdownValue;

  @override
  void initState() {
    widget.departments!.insert(0, 'All Majors');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: SizeConfig.widthMultiplier! * 70,
      padding: EdgeInsets.only(
        left: SizeConfig.widthMultiplier! * 2,
        right: SizeConfig.widthMultiplier! * 2,
      ),
      decoration: BoxDecoration(
        // color: Colors.black,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          width: SizeConfig.widthMultiplier! * 0.2,
          color: Colors.grey.shade200,
        ),
      ),
      child: DropdownButton<String>(
        value: dropdownValue,
        onChanged: (value) {
          setState(() {
            widget.coursesController!.getShortCoursesFiltered(value!);
            dropdownValue = value;
            setState(() {});
          });
        },
        isExpanded: true,
        disabledHint: Text(
          'Choose a department',
          style: TextStyle(
            fontSize: SizeConfig.widthMultiplier! * 5,
            overflow: TextOverflow.ellipsis,
            color: Colors.black,
          ),
        ),
        hint: Text(
          'Choose a department',
          style: TextStyle(
            fontSize: SizeConfig.widthMultiplier! * 5,
            overflow: TextOverflow.ellipsis,
            color: Colors.grey,
          ),
        ),
        icon: const Icon(Icons.keyboard_arrow_down),
        elevation: 0,
        underline: Container(),
        style: TextStyle(
          fontSize: SizeConfig.widthMultiplier! * 5,
          overflow: TextOverflow.ellipsis,
          color: Colors.black,
        ),
        items: widget.departments?.map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }
}
