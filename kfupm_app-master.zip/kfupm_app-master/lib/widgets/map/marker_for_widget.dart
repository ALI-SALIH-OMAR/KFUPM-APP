import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';

class MarkerForWidget extends StatelessWidget {
  const MarkerForWidget({
    Key? key,
    required this.text,
  }) : super(key: key);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: SizeConfig.heightMultiplier! * 4,
      width: SizeConfig.widthMultiplier! * 6,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.grey.shade300,
          width: SizeConfig.widthMultiplier! * 0.3,
        ),
        color: Colors.white,
      ),
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 1.5,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
