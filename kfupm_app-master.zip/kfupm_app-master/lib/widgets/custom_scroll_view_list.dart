/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is a scrollView to list some widgets.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';

class CustomScrollViewList extends StatelessWidget {
  const CustomScrollViewList({
    Key? key,
    required this.widget,
    required this.scrollController,
  }) : super(key: key);

  final Widget widget;
  final ScrollController scrollController;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: SizeConfig.heightMultiplier! * 73,
      width: SizeConfig.widthMultiplier! * 100,
      child: ListView.builder(
        scrollDirection: Axis.vertical,
        controller: scrollController,
        physics: const ScrollPhysics(),
        shrinkWrap: true,
        itemCount: 10,
        itemBuilder: (BuildContext context, int index) {
          return widget;
        },
      ),
    );
  }
}
