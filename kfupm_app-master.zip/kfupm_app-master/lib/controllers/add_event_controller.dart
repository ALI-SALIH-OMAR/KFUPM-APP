import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/entities/event.dart';

class AddEventController {
  late TextEditingController title;
  late TextEditingController location;
  late TextEditingController notes;
  late DateTime date;
  late String timeFrom;
  late String timeTo;

  AddEventController() {
    title = TextEditingController();
    location = TextEditingController();
    notes = TextEditingController();
  }

  void setTimeFrom(TimeOfDay from) {
    if (from.hour > 12) {
      timeTo = '${from.hour}:${from.minute}AM';
    } else {
      timeTo = '${from.hour}:${from.minute}PM';
    }
  }

  void setTimeTo(TimeOfDay to) {
    if (to.hour > 12) {
      timeFrom = '${to.hour}:${to.minute}AM';
    } else {
      timeFrom = '${to.hour}:${to.minute}PM';
    }
  }

  void setDate(DateTime dateTime) {
    date = dateTime;
  }

  void addEvent(String image, String clubName, State state, ClubModel clubModel) async {
    Event event = Event(
      date: date,
      image: 'https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/club_icon%2FImprove.jpg?alt=media&token=99d736e6-f982-4dec-99e4-c8b36c23e0b7',
      location: location.text,
      title: title.text,
      note: notes.text,
      organizer: clubName,
      time: '$timeFrom - $timeTo',
    );
    clubModel.events.add(event);
    state.setState(() {});
    addEventToClub(event.toMap(), clubName);
  }

  static Future<void> addEventToClub(Map<String, dynamic> event, String clubName) async {
    String studentDocId = (await FirebaseCollections.club.where('name', isEqualTo: clubName).get()).docs.first.id;
    await FirebaseCollections.club.doc(studentDocId).update({
      'club_events': FieldValue.arrayUnion([event])
    });
  }

  static Future<String> addImage(String title, String image) async {
    String link = '';
    await FirebaseCollections.imagesStorage
        .child('$title.jpg')
        .putFile(
          File(image),
        );
    return 'Improve';
  }
}
