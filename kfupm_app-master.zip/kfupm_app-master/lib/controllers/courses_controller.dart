import 'package:kfupm_app/entities/major.dart';
import 'package:kfupm_app/entities/short_course.dart';

class CoursesController{
  List<ShortCourse>? courses = [];
  List<ShortCourse>? coursesOriginal = [];
  List<Major>? majors = [];
  bool isSet = false;

  List<String> getMajors(List<Major>? majors){
    this.majors = majors;
    List<String> major = [];
    for (var element in majors!) {
      major.add(element.code);
    }
    return major;
  }

  getShortCourses(){
    if(!isSet){
      List<ShortCourse> temp = [];
      for (var elements in majors!) {
        for(var element in elements.shortCourses){
          temp.add(element);
        }
      }
      courses = temp;
      coursesOriginal = temp;
      isSet = true;
    }
  }

  getShortCoursesFiltered(String code){
    if(code == 'All Majors'){
      courses = coursesOriginal;
    } else {
      Major? elements = majors?.where((element) => element.code == code).first;
      courses = elements?.shortCourses;
    }
  }
}