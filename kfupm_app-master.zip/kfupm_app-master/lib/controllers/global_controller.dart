import 'package:flutter/cupertino.dart';
import 'package:geolocator/geolocator.dart';
import 'package:kfupm_app/controllers/calendar_controller.dart';
import 'package:kfupm_app/entities/instructor.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/entities/student.dart';

class GlobalController {
  GlobalController._();

  static final GlobalController _instance = GlobalController._();

  static GlobalController get instance => _instance;

  static late State calendarState;
  static late State instructorProfileState;
  static late Section section;
  static bool ins = false;
  static bool stu = false;
  static bool club = false;
  static late BuildContext passedContext;
  static Student? student;
  static Instructor? instructor;
  static Instructor? passedInstructor;
  static int selectedIndex = 0;
  static bool isMounted = false;
  static late CalendarController calendarController;
  static late Position position;
  static late List<Section> sections;

  static void deleteInfo(){
    selectedIndex = 0;
    ins = false;
    stu = false;
    club = false;
    student;
    instructor;
  }

}
