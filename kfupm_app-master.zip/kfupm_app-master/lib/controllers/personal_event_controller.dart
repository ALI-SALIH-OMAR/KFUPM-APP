import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event_personal.dart';
import 'package:kfupm_app/services/firebase/personal_event_services.dart';

class PersonalEventController {
  late TextEditingController title;
  late TextEditingController location;
  late TextEditingController material;
  late TextEditingController structure;
  late TextEditingController notes;
  late DateTime date;
  late String timeFrom;
  late String timeTo;

  PersonalEventController() {
    title = TextEditingController();
    location = TextEditingController();
    material = TextEditingController();
    structure = TextEditingController();
    notes = TextEditingController();
  }

  void setDate(DateTime dateTime) {
    date = dateTime;
  }

  void setTimeFrom(TimeOfDay from) {
    if (from.hour > 12) {
      timeTo = '${from.hour}:${from.minute}AM';
    } else {
      timeTo = '${from.hour}:${from.minute}PM';
    }
  }

  void setTimeTo(TimeOfDay to) {
    if (to.hour > 12) {
      timeFrom = '${to.hour}:${to.minute}AM';
    } else {
      timeFrom = '${to.hour}:${to.minute}PM';
    }
  }

  void addEvent() {
    EventPersonal eventPersonal = EventPersonal(
      crn: 'null',
      date: date,
      timeCreated: DateTime.now(),
      creator: GlobalController.student!.firstName + ' ' + GlobalController.student!.lastName,
      location: location.text,
      material: material.text,
      note: notes.text,
      structure: structure.text,
      timeFrom: timeFrom,
      timeTo: timeTo,
      title: title.text,
    );
    GlobalController.student!.eventPersonal.add(eventPersonal);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    PersonalEventServices.addPersonalEventToStudent(eventPersonal.toMap(), GlobalController.student!.email);
  }

  void addEventForSection(String crn, List<String> students, String instructorEmail) {
    EventPersonal eventPersonal = EventPersonal(
      crn: crn,
      date: date,
      timeCreated: DateTime.now(),
      creator: GlobalController.instructor!.firstName + ' ' + GlobalController.instructor!.lastName,
      location: location.text,
      material: material.text,
      note: notes.text,
      structure: structure.text,
      timeFrom: timeFrom,
      timeTo: timeTo,
      title: title.text,
    );
    GlobalController.instructor!.eventPersonal.add(eventPersonal);
    GlobalController.section.heatMap!['${date.year}/${date.month}/${date.day}'] = students;
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    PersonalEventServices.addPersonalEventToSection(eventPersonal.toMap(), crn, students, instructorEmail, date);
  }

  void addEventToInstructor() {
    EventPersonal eventPersonal = EventPersonal(
      crn: 'null',
      date: date,
      timeCreated: DateTime.now(),
      creator: GlobalController.instructor!.firstName + ' ' + GlobalController.instructor!.lastName,
      location: location.text,
      material: material.text,
      note: notes.text,
      structure: structure.text,
      timeFrom: timeFrom,
      timeTo: timeTo,
      title: title.text,
    );
    GlobalController.instructor!.eventPersonal.add(eventPersonal);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    PersonalEventServices.addPersonalEventToInstructor(eventPersonal.toMap(), GlobalController.instructor!.email);
  }

  static void deleteEvent(EventPersonal eventPersonal) {
    GlobalController.student!.eventPersonal.remove(eventPersonal);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    PersonalEventServices.deletePersonalEventForStudent(eventPersonal.toMap(), GlobalController.student!.email);
  }

  static void deleteEventForSection(EventPersonal eventPersonal,String crn, List<String> students, String instructorEmail) {
    GlobalController.instructor!.eventPersonal.remove(eventPersonal);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    PersonalEventServices.deletePersonalEventForSection(eventPersonal.toMap(), crn, students, instructorEmail, eventPersonal.date);
  }

  static void deleteEventToInstructor(EventPersonal eventPersonal) {
    GlobalController.instructor!.eventPersonal.remove(eventPersonal);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    PersonalEventServices.deletePersonalEventForInstructor(eventPersonal.toMap(), GlobalController.instructor!.email);
  }
}
