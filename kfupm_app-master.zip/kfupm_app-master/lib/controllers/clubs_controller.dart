import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/services/firebase/club_services.dart';

class ClubsController {
  static List<ClubModel> clubs = [];
  static Future<List<Event>> getEvents() async {
    clubs = await ClubServices.getClubsWithEvents();
    List<Event> events = [];
    for (ClubModel club in clubs) {
      events.addAll(club.events);
    }
    return events;
  }

  static ClubModel getEventClub(String organizer){
    return clubs.firstWhere((element) => element.name == organizer);
  }
}
