import 'package:intl/intl.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/utils/time.dart';

class HeatMapController {
  late Section section;
  late int skipDays;
  late List<List<int>> daysList;
  late String currentMonth;
  late int currentWeek;
  late List<String> months;
  late List<int> weeks;
  Map<String, int> heatMap = {};

  setUp({int month = 0, int year = 0}) {
    currentWeek = Time.currentWeek();
    skipDays = Time.skipDays();
    daysList = Time.daysList();
    months = Time.getMonths();
    // weeks = Time.getMonthsWeeks();
    weeks = [4,9,14,18,23,28];
    currentMonth = months[3];
    setHeatMap();
  }

  void changeMonth(int position) {
    if (position < 300) {
      currentMonth = months[0];
    } else if (position > (100 * weeks[5]) - 50) {
      currentMonth = months[6];
    } else if (position > (100 * weeks[4])) {
      currentMonth = months[5];
    } else if (position > 100 * (weeks[3])) {
      currentMonth = months[4];
    } else if (position > (100 * weeks[2])) {
      currentMonth = months[3];
    } else if (position > (100 * weeks[1])) {
      currentMonth = months[2];
    } else if (position > (100 * weeks[0])) {
      currentMonth = months[1];
    }
  }

  void setHeatMap() {
    for (int x = -2; x < 5; x++) {
      DateTime now = DateTime.now();
      DateTime lastDayOfMonth = DateTime(now.year, now.month + x, 0);
      for (int x = 1; x <= lastDayOfMonth.day; x++) {
        if (section.heatMap!['${lastDayOfMonth.year}/${lastDayOfMonth.month}/$x'] != null ||
            section.heatMap!['${lastDayOfMonth.year}/0${lastDayOfMonth.month}/0$x'] != null ||
            section.heatMap!['${lastDayOfMonth.year}/0${lastDayOfMonth.month}/$x'] != null ||
            section.heatMap!['${lastDayOfMonth.year}/${lastDayOfMonth.month}/0$x'] != null) {
          if (lastDayOfMonth.month < 10 && x < 10) {
            DateTime day = DateFormat('yyyy/MM/dd').parse(
                '${lastDayOfMonth.year}/0${lastDayOfMonth.month}/0$x');
            int weekNumInMap = Time.weekNumber(day);
            heatMap['$weekNumInMap/$x'] = section.heatMap!['${lastDayOfMonth.year}/0${lastDayOfMonth.month}/0$x'] ?? 0;
          } else if (x < 10) {
            DateTime day = DateFormat('yyyy/MM/dd').parse(
                '${lastDayOfMonth.year}/${lastDayOfMonth.month}/0$x');
            int weekNumInMap = Time.weekNumber(day);
            heatMap['$weekNumInMap/$x'] = section.heatMap!['${lastDayOfMonth.year}/${lastDayOfMonth.month}/0$x'] ?? 0;
          } else if (lastDayOfMonth.month < 10) {
            DateTime day = DateFormat('yyyy/MM/dd').parse(
                '${lastDayOfMonth.year}/0${lastDayOfMonth.month}/$x');
            int weekNumInMap = Time.weekNumber(day);
            heatMap['$weekNumInMap/$x'] =
                section.heatMap!['${lastDayOfMonth.year}/0${lastDayOfMonth.month}/$x'] ?? 0;
          } else {
            DateTime day = DateFormat('yyyy/MM/dd').parse(
                '${lastDayOfMonth.year}/${lastDayOfMonth.month}/$x');
            int weekNumInMap = Time.weekNumber(day);
            heatMap['$weekNumInMap/$x'] = section.heatMap!['${lastDayOfMonth.year}/${lastDayOfMonth.month}/$x'] ?? 0;
          }
        }
      }
    }
  }
}
