import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/services/firebase/student_services.dart';

import '../services/firebase/instructor_services.dart';

class EventController {
  static bool isAddedEvent(Event passedEvent) {
    for (Event event in GlobalController.student!.events) {
      if (event.title == passedEvent.title) {
        return true;
      }
    }
    return false;
  }

  static void addEventToCalendar(Event event) {
    GlobalController.student!.events.add(event);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    StudentServices.addEventToCalendar(getMap());
  }

  static List<Map<String, dynamic>> getMap() {
    return List<Map<String, dynamic>>.generate(GlobalController.student!.events.length,
            (int index) => GlobalController.student!.events[index].toMap());
  }

  static bool isAddedEventIns(Event passedEvent) {
    for (Event event in GlobalController.instructor!.event) {
      if (event.title == passedEvent.title) {
        return true;
      }
    }
    return false;
  }

  static void addEventToCalendarIns(Event event) {
    GlobalController.instructor!.event.add(event);
    GlobalController.calendarController.setUp();
    GlobalController.calendarState.setState(() {});
    InstructorServices.addEventToCalendar(getMapIns());
  }

  static List<Map<String, dynamic>> getMapIns() {
    return List<Map<String, dynamic>>.generate(GlobalController.instructor!.event.length,
            (int index) => GlobalController.instructor!.event[index].toMap());
  }
}
