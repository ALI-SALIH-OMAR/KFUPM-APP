import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/services/firebase/instructor_services.dart';

class EditInstructorProfileController {
  final splitted = GlobalController.instructor!.officeHours.split(' - ');
  late String timeTo;
  late String timeFrom;

  EditInstructorProfileController(){
    timeTo = splitted[1];
    timeFrom = splitted[2];
  }

  bool dOne = GlobalController.instructor!.officeHours.contains('U');
  bool dTwo = GlobalController.instructor!.officeHours.contains('M');
  bool dThree = GlobalController.instructor!.officeHours.contains('T');
  bool dFour = GlobalController.instructor!.officeHours.contains('W');
  bool dFive = GlobalController.instructor!.officeHours.contains('R');

  TextEditingController email = TextEditingController(
    text: GlobalController.instructor!.email,
  );
  TextEditingController office = TextEditingController(
    text: GlobalController.instructor!.office,
  );

  void setTimeFrom(TimeOfDay from) {
    if (from.hour > 12) {
      timeTo = '${from.hour}:${from.minute}AM';
    } else {
      timeTo = '${from.hour}:${from.minute}PM';
    }
  }

  void setTimeTo(TimeOfDay to) {
    if (to.hour > 12) {
      timeFrom = '${to.hour}:${to.minute}AM';
    } else {
      timeFrom = '${to.hour}:${to.minute}PM';
    }
  }

  Future<void> changeProfile() async {
    String days = '';
    if (dOne) {
      days = days + 'U';
    }
    if (dTwo) {
      days = days + 'M';
    }
    if (dThree) {
      days = days + 'T';
    }
    if (dFour) {
      days = days + 'W';
    }
    if (dFive) {
      days = days + 'R';
    }

    InstructorServices.updateProfile(
        GlobalController.instructor!.email, email.text, office.text, '$days - $timeTo - $timeFrom');

    GlobalController.instructor!.email = email.text;
    GlobalController.instructor!.office = office.text;
    GlobalController.instructor!.officeHours = '$days - $timeTo - $timeFrom';
    GlobalController.instructorProfileState.setState(() {});
  }
}
