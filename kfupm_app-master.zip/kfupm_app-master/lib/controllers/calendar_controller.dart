import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/entities/event_personal.dart';
import 'package:kfupm_app/utils/time.dart';

class CalendarController {
  late int skipDays;
  late List<List<int>> daysList;
  late String currentMonth;
  late int currentWeek;
  late List<String> months;
  late List<int> weeks;
  late int currentMonthAsNumber;
  int indicator = 0;
  bool once = true;
  bool stop = false;
  Map<String, List<Event>> events = {};
  Map<String, List<EventPersonal>> eventsPersonal = {};

  CalendarController() {
    setUp();
    currentMonth = months[4];
  }

  setUp({int month = 0, int year = 0}) {
    currentWeek = Time.currentWeek();
    skipDays = Time.skipDays();
    daysList = Time.daysList();
    months = Time.getMonths();
    // weeks = Time.getMonthsWeeks();
    weeks = [4,9,14,18,23,28];
    //only remove if statement that makes setEvents(); applied for student account only
    setEvents();
    setEventsPersonal();
  }

  void setEvents() {
    events = {};
    List<Event>? allEvents;
    if(GlobalController.stu){
     allEvents = GlobalController.student?.events;}
    else{ allEvents = GlobalController.instructor?.event;}
    for (Event event in allEvents!) {
      if (events['${Time.weekNumber(event.date)}${event.date.day}'] != null) {
        events['${Time.weekNumber(event.date)}${event.date.day}']!.add(event);
      } else {
        events['${Time.weekNumber(event.date)}${event.date.day}'] = [event];
      }
    }
  }

  List<Event>? getEventsForDay(int weekNumber, int day) {
    return events['$weekNumber$day'];
  }

  void setEventsPersonal() {
    eventsPersonal = {};
    if(GlobalController.stu){
      List<EventPersonal>? allEvents = GlobalController.student?.eventPersonal;
      for (EventPersonal event in allEvents!) {
        if (eventsPersonal['${Time.weekNumber(event.date)}${event.date.day}'] != null) {
          eventsPersonal['${Time.weekNumber(event.date)}${event.date.day}']!.add(event);
        } else {
          eventsPersonal['${Time.weekNumber(event.date)}${event.date.day}'] = [event];
        }
      }
    } else {
      List<EventPersonal>? allEvents = GlobalController.instructor?.eventPersonal;
      for (EventPersonal event in allEvents!) {
        if (eventsPersonal['${Time.weekNumber(event.date)}${event.date.day}'] != null) {
          eventsPersonal['${Time.weekNumber(event.date)}${event.date.day}']!.add(event);
        } else {
          eventsPersonal['${Time.weekNumber(event.date)}${event.date.day}'] = [event];
        }
      }
    }
  }

  List<EventPersonal>? getEventsPersonalForDay(int weekNumber, int day) {
    return eventsPersonal['$weekNumber$day'];
  }

  void changeMonth(int position) {
    if (position < 300) {
      currentMonth = months[0];
    } else if (position > (100 * weeks[5]) - 50) {
      currentMonth = months[6];
    } else if (position > (100 * weeks[4])) {
      currentMonth = months[5];
    } else if (position > 100 * (weeks[3])) {
      currentMonth = months[4];
    } else if (position > (100 * weeks[2])) {
      currentMonth = months[3];
    } else if (position > (100 * weeks[1])) {
      currentMonth = months[2];
    } else if (position > (100 * weeks[0])) {
      currentMonth = months[1];
    }
  }
}
