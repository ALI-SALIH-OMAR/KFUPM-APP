import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/services/firebase/section_services.dart';

class SectionController {
  static Future<List<Section>> getStudentSections() async {
    List<Section> sections = [];
    for (String crn in GlobalController.student!.sections) {
      sections.add(await SectionServices.getSection(crn));
    }
    return sections;
  }

  static List<List<int>> sectionPosition(String days, String time) {
    List<List<int>> positions = [];
    int h1 = int.parse(time.substring(0, 2));
    int positionY = (h1 - 7) * 7;
    for (var day in days.runes) {
      String character = String.fromCharCode(day);
      if (character == 'U') {
        positions.add([15, positionY]);
      } else if (character == 'M') {
        positions.add([32, positionY]);
      } else if (character == 'T') {
        positions.add([49, positionY]);
      } else if (character == 'W') {
        positions.add([66, positionY]);
      } else if (character == 'R') {
        positions.add([83, positionY]);
      }
    }
    return positions;
  }

  static int sectionHeight(String time) {
    int h = int.parse(time.substring(10, 12)) - int.parse(time.substring(0, 2));
    int m = int.parse(time.substring(3, 5)) + int.parse(time.substring(13, 15));
    int totalMs = (h * 60) + m;
    return (totalMs * (6 / 50)).toInt();
  }

  static String timeString(int index) {
    if (index < 6) {
      if (index + 7 > 9) {
        return '${index + 7}AM';
      } else {
        return '${index + 7}AM';
      }
    } else {
      if (index + 7 > 9) {
        return '${index - 5}PM';
      } else {
        return '${index - 5}PM';
      }
    }
  }
}
