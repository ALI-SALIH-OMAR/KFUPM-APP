class Location{
  late String markerNum;
  late String building;
  late String about;
  late String image;
  late String lab;
  late String cafeteria;
  late String parking;
  late double lat;
  late double lon;
  
  Location(this.markerNum, this.building, this.about,
            this.image, this.lab, this.cafeteria, 
              this.parking, this.lat, this.lon,);

}

class Markers{
  late String label;
  late double lat;
  late double lon;
  Markers(this.label, this.lat, this.lon);
}

class SavedLocation{
  //for location sheet
   var locations ={
    "22": Location("22", "Building 22", "College of Computing and Mathematics",
        "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F22.jpg?alt=media&token=7973b521-da67-432c-8be1-6fe2a8e26a57",
        "yes", "no", "yes, first two floors for instructors, and last two floors for non-resident students (note: from 5PM to 6AM, the parking open for all)",
        26.3057898, 50.1465087),

    "23": Location("23", "Building 23", "under building 22",
        "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F23.jpg?alt=media&token=2140cedd-073e-43bc-8681-8fadb8767fd3",
        "yes", "no", "yes, first two floors for instructors, and last two floors for non-resident students (note: from 5PM to 6AM, the parking open for all)",
        26.3057365, 50.1463480),

    "24": Location("24", "Building 24", "College of Business",
        "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F24.jpg?alt=media&token=7f20f9f6-8a7d-415c-aea4-91a301c19c60",
        "yes", "yes", "yes, for instructors, and non-resident students (note: from 5PM to 6AM, the parking open for all)",
        26.3049196, 50.1466695),

    "59": Location("59", "Building 59", "College of Electric engineering",
        "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F59.jpg?alt=media&token=d18a2f65-f7e9-414e-91f8-bba7d03d8d4e",
        "yes", "yes, floor 1", "yes, for instructors, and non-resident students (note: from 5PM to 6AM, the parking open for all)",
        26.3082366, 50.1447796),

     "21": Location("21", "Building 21", "Building of Administration",
         "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F21.jpg?alt=media&token=9ed05e82-ad1f-4f8e-aa13-8d8f45b9e772",
         "no", "no", "yes",
         26.3063507, 50.1451377),

     "11": Location("11", "Building 11", "Gymnasium",
         "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F11.jfif?alt=media&token=4ef50993-8e66-4613-94de-44b80335dfeb",
         "no", "no", "yes",
         26.3052326, 50.1453959),

     "76": Location("76", "Building 76", "College of Petroleum Engineering & Geosciences",
         "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F76.jpg?alt=media&token=0de727c2-cd6e-4acf-9493-f98e4939b1fc",
         "yes", "yes", "yes",
         26.3054610, 50.1476717),

     "8": Location("8", "Building 8", "Main Library",
         "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F8.jpg?alt=media&token=88ad8b16-db80-4d8f-bc57-d915915fbc33",
         "no", "no", "yes",
         26.3072199, 50.1443901),

     "9": Location("9", "Building 9", "Arabic & English Departments",
         "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F9.jpg?alt=media&token=2dbb93d4-78a8-4a27-9247-958e083f9a99",
         "no", "no", "no",
         26.3065403, 50.1446201),

     "10": Location("10", "Building 10", "Prince Nayef Center for Culture & Science",
         "https://firebasestorage.googleapis.com/v0/b/kfupm-app-568e2.appspot.com/o/map_images%2F10.jpg?alt=media&token=32f78541-99e2-4869-b6d0-ac3c9d75fed2",
         "no", "no", "yes",
         26.3061415, 50.1446405),

  };

   //for k_map.dart
   var markers = {Markers("22",26.3057898, 50.1465087), Markers("23",26.3057365, 50.1463480),
     Markers("24",26.3049196, 50.1466695), Markers("59",26.3082366, 50.1447796),
     Markers("21",26.3063507, 50.1451377), Markers("11",26.3052326, 50.1453959),
     Markers("76",26.3054610, 50.1476717), Markers("8",26.3072199, 50.1443901),
     Markers("9",26.3065403, 50.1446201), Markers("10",26.3061415, 50.1446405)};
}

