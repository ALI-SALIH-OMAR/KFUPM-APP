/*
Author: Saud Elabdullah.
Work: This class work as a constants class to get facilitate
getting and changing all constants.
Note: Noting.
 */

import 'package:flutter/material.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';

class Constant {
  Constant._();

  //Constant values
  static double leftAndRight = SizeConfig.widthMultiplier! * 6;
  static double topContent = SizeConfig.heightMultiplier! * 2;
  static double topIcon = SizeConfig.heightMultiplier! * 3;

  //Icons
  static Icon backArrow = const Icon(
    Icons.arrow_back_ios,
    size: 20,
    color: Colors.black,
  );

  //Container decoration
  static Border cardBorder = Border.all(
    width: 0.5,
    color: AppColors.grey,
  );

  static BorderRadius borderRadiusLarge = BorderRadius.circular(15);

  static BorderRadius borderRadiusMedium = BorderRadius.circular(5);

  static BorderRadius borderRadiusSmall = BorderRadius.circular(5);

  static Radius cornerRadius = const Radius.circular(15);
}
