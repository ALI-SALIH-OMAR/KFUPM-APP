import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FirebaseCollections {
  static final _reference = FirebaseFirestore.instance;

  static final CollectionReference majors = _reference.collection('Majors');
  static final CollectionReference courses = _reference.collection('Courses');
  static final CollectionReference sections = _reference.collection('Sections');
  static final CollectionReference colleges = _reference.collection('Colleges');
  static final CollectionReference clubs = _reference.collection('Clubs');
  static final CollectionReference club = _reference.collection('Club');
  static final CollectionReference student = _reference.collection('Student');
  static final CollectionReference instructor = _reference.collection('Instructor');
  static final CollectionReference evaluation = _reference.collection('Evaluation');

  static final _storageRef = FirebaseStorage.instance.ref();
  static final imagesStorage = _storageRef.child('club_icon/');
}
