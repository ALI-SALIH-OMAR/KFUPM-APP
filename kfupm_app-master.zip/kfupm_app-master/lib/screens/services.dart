import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/screens/clubs.dart';
import 'package:kfupm_app/screens/courses.dart';
import 'package:kfupm_app/screens/instructor_profile.dart';
import 'package:kfupm_app/screens/login.dart';
import 'package:kfupm_app/screens/major_flowcharts.dart';
import 'package:kfupm_app/screens/schedule.dart';
import 'package:kfupm_app/screens/student_profile.dart';
import 'package:kfupm_app/services/get_pkpass.dart';
import 'package:kfupm_app/utils/size_config.dart';

class Services extends StatefulWidget {
  const Services({Key? key}) : super(key: key);

  @override
  State<Services> createState() => _ServicesState();
}

class _ServicesState extends State<Services> {
  late ApplePass applePass;
  late String name;
  late String fieldOne;
  late String fieldTwo;
  late String fieldThree;
  late String fieldFour;
  late String fieldFive;

  @override
  void initState() {
    applePass = ApplePass.instance;
    if (GlobalController.ins) {
      name = GlobalController.instructor!.firstName + ' ' + GlobalController.instructor!.lastName;
      fieldOne = GlobalController.instructor!.status;
      fieldTwo = GlobalController.instructor!.office;
      fieldThree = GlobalController.instructor!.status;
      fieldFour = GlobalController.instructor!.officeHours;
      fieldFive = GlobalController.instructor!.email;
    } else if(GlobalController.stu) {
      name = GlobalController.student!.firstName + ' ' + GlobalController.student!.lastName;
      fieldOne = GlobalController.student!.major;
      fieldTwo = GlobalController.student!.status;
      if(GlobalController.student!.followedClubs.isNotEmpty){
        fieldThree = GlobalController.student!.followedClubs.first;
      } else {
        fieldThree = 'No followed clubs';
      }
      fieldFour = GlobalController.student!.concentration;
      fieldFive = GlobalController.student!.email;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            Text(
              'Services',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 3,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: SizeConfig.heightMultiplier! * 3,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              child: Container(
                padding: EdgeInsets.all(
                  SizeConfig.widthMultiplier! * 6,
                ),
                decoration: const BoxDecoration(
                  color: Color(0xFFFAF7F5),
                  borderRadius: BorderRadius.all(
                    Radius.circular(5),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          PhosphorIcons.identification_card,
                          size: SizeConfig.imageSizeMultiplier! * 5,
                        ),
                        SizedBox(
                          width: SizeConfig.widthMultiplier! * 2,
                        ),
                        Text(
                          'MY INFO',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 1.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 1,
                    ),
                    Container(
                      color: Colors.black,
                      height: SizeConfig.heightMultiplier! * 0.02,
                      width: SizeConfig.widthMultiplier! * 88,
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            name,
                            style: TextStyle(
                              fontSize: SizeConfig.textMultiplier! * 3.3,
                              fontWeight: FontWeight.bold,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: SizeConfig.widthMultiplier! * 3,
                        ),
                        if(GlobalController.stu)...[
                          Container(
                            height: SizeConfig.heightMultiplier! * 2.5,
                            width: SizeConfig.widthMultiplier! * 10,
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFBF1B),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Center(
                              child: Text(
                                fieldOne,
                                style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier! * 1.5,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ]
                      ],
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 1,
                    ),
                    Text(
                      fieldTwo,
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 1.9,
                        fontWeight: FontWeight.w400,
                        color: Colors.black54,
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Row(
                      children: [
                        Icon(
                          PhosphorIcons.users,
                          size: SizeConfig.imageSizeMultiplier! * 5,
                        ),
                        SizedBox(
                          width: SizeConfig.widthMultiplier! * 2,
                        ),
                        Expanded(
                          child: Text(
                            fieldThree,
                            style: TextStyle(
                              fontSize: SizeConfig.textMultiplier! * 1.9,
                              fontWeight: FontWeight.w400,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Row(
                      children: [
                        Icon(
                          PhosphorIcons.crosshair_simple,
                          size: SizeConfig.imageSizeMultiplier! * 5,
                        ),
                        SizedBox(
                          width: SizeConfig.widthMultiplier! * 2,
                        ),
                        Expanded(
                          child: Text(
                            fieldFour,
                            style: TextStyle(
                              fontSize: SizeConfig.textMultiplier! * 1.9,
                              fontWeight: FontWeight.w400,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Row(
                      children: [
                        Icon(
                          PhosphorIcons.envelope_simple,
                          size: SizeConfig.imageSizeMultiplier! * 5,
                        ),
                        SizedBox(
                          width: SizeConfig.widthMultiplier! * 2,
                        ),
                        Expanded(
                          child: Text(
                            fieldFive,
                            style: TextStyle(
                              fontSize: SizeConfig.textMultiplier! * 1.9,
                              fontWeight: FontWeight.w400,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 3,
                    ),
                    Container(
                      color: Colors.black,
                      height: SizeConfig.heightMultiplier! * 0.02,
                      width: SizeConfig.widthMultiplier! * 88,
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 2,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            GestureDetector(
                              onTap: () {
                                if (GlobalController.ins) {
                                  Navigator.push(
                                    GlobalController.passedContext,
                                    MaterialPageRoute(
                                      builder: (context) => const InstructorProfile(),
                                    ),
                                  );
                                } else {
                                  Navigator.push(
                                    GlobalController.passedContext,
                                    MaterialPageRoute(
                                      builder: (context) => const StudentProfile(),
                                    ),
                                  );
                                }
                              },
                              child: Text(
                                'OPEN PROFILE',
                                style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier! * 1.5,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.black54,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: SizeConfig.widthMultiplier! * 1,
                            ),
                            Icon(
                              Icons.arrow_forward_ios,
                              size: SizeConfig.imageSizeMultiplier! * 3,
                              color: Colors.black54,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 43,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Services',
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 1.9,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 1,
                  ),
                  Container(
                    color: Colors.black,
                    height: SizeConfig.heightMultiplier! * 0.02,
                    width: SizeConfig.widthMultiplier! * 88,
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 1,
                  ),
                  Row(
                    children: [
                      Icon(
                        Icons.calendar_today_outlined,
                        size: SizeConfig.imageSizeMultiplier! * 5,
                      ),
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 1,
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            GlobalController.passedContext,
                            MaterialPageRoute(
                              builder: (context) => const Schedule(),
                            ),
                          );
                        },
                        child: Text(
                          'My Schedule',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 1.9,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Icon(
                        PhosphorIcons.tree_structure,
                        size: SizeConfig.imageSizeMultiplier! * 5,
                      ),
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 1,
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            GlobalController.passedContext,
                            MaterialPageRoute(
                              builder: (context) => const MajorFlowcharts(),
                            ),
                          );
                        },
                        child: Text(
                          'Major Flowchart',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 1.9,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Icon(
                        PhosphorIcons.books,
                        size: SizeConfig.imageSizeMultiplier! * 5,
                      ),
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 1,
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            GlobalController.passedContext,
                            MaterialPageRoute(
                              builder: (context) => const Courses(),
                            ),
                          );
                        },
                        child: Text(
                          'Courses',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 1.9,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Icon(
                        PhosphorIcons.users,
                        size: SizeConfig.imageSizeMultiplier! * 5,
                      ),
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 1,
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            GlobalController.passedContext,
                            MaterialPageRoute(
                              builder: (context) => const Clubs(),
                            ),
                          );
                        },
                        child: Text(
                          'Clubs',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 1.9,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Center(
                    child: TextButton(
                      onPressed: () {
                        GlobalController.deleteInfo();
                        FirebaseAuth.instance.signOut();
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                              pageBuilder: (context, animation, secondaryAnimation) {
                                return const Login();
                              },
                              transitionDuration: const Duration(milliseconds: 500),
                              transitionsBuilder: (context, animation, secondaryAnimation, child) {
                                return FadeTransition(
                                  opacity: animation,
                                  child: child,
                                );
                              }),
                        );
                      },
                      child: Text(
                        'Logout',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 3,
                          fontWeight: FontWeight.w400,
                          color: Colors.red.shade700,
                        ),
                      ),
                    ),
                  ),
                  // Row(
                  //   children: [
                      // Icon(
                      //   PhosphorIcons.gear_six,
                      //   size: SizeConfig.imageSizeMultiplier! * 5,
                      // ),
                      // SizedBox(
                      //   width: SizeConfig.widthMultiplier! * 1,
                      // ),
                      // TextButton(
                      //   onPressed: () {
                      //     Navigator.push(
                      //       GlobalController.passedContext,
                      //       MaterialPageRoute(
                      //         builder: (context) => const Setting(),
                      //       ),
                      //     );
                      //   },
                      //   child: Text(
                      //     'Settings',
                      //     style: TextStyle(
                      //       fontSize: SizeConfig.textMultiplier! * 1.9,
                      //       fontWeight: FontWeight.w400,
                      //       color: Colors.black,
                      //     ),
                      //   ),
                      // ),
                  //   ],
                  // ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
