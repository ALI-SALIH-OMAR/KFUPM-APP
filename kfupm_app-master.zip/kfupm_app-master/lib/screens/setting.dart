import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/screens/login.dart';
import 'package:kfupm_app/utils/size_config.dart';

class Setting extends StatefulWidget {
  const Setting({Key? key}) : super(key: key);

  @override
  _SettingState createState() => _SettingState();
}

class _SettingState extends State<Setting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Setting',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: SizeConfig.heightMultiplier! * 3,
              left: SizeConfig.widthMultiplier! * 6,
              child: Row(
                children: [
                  Icon(
                    Icons.remove_red_eye_outlined,
                    size: SizeConfig.imageSizeMultiplier! * 6,
                  ),
                  SizedBox(
                    width: SizeConfig.widthMultiplier! * 2,
                  ),
                  Text(
                    'Appearance',
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 7,
              left: SizeConfig.widthMultiplier! * 6,
              child: Container(
                color: Colors.black,
                height: SizeConfig.heightMultiplier! * 0.02,
                width: SizeConfig.widthMultiplier! * 88,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 9,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Theme',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          showModalBottomSheet<void>(
                            context: context,
                            backgroundColor: Colors.transparent,
                            builder: (BuildContext context) {
                              return Container(
                                height: SizeConfig.heightMultiplier! * 50,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15),
                                  ),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier! * 6),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 4,
                                      ),
                                      Text(
                                        'Theme',
                                        style: TextStyle(
                                          fontSize: SizeConfig.textMultiplier! * 2,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 3,
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 5,
                                        width: SizeConfig.widthMultiplier! * 88,
                                        child: ElevatedButton(
                                          style: TextButton.styleFrom(
                                            backgroundColor: const Color(0xFF25794F),
                                            elevation: 5,
                                          ),
                                          onPressed: () {
                                            Navigator.pop(context, 'Dark Theme');
                                          },
                                          child: Text(
                                            'Dark Theme',
                                            style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier! * 2,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 2,
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 5,
                                        width: SizeConfig.widthMultiplier! * 88,
                                        child: ElevatedButton(
                                          style: TextButton.styleFrom(
                                            backgroundColor: const Color(0xFF25794F),
                                            elevation: 5,
                                          ),
                                          onPressed: () {
                                            Navigator.pop(context, 'Light Theme');
                                          },
                                          child: Text(
                                            'Light Theme',
                                            style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier! * 2,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        },
                        child: Text(
                          'System Default',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 2,
                            fontWeight: FontWeight.w400,
                            color: Colors.black54,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Language',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          showModalBottomSheet<void>(
                            context: context,
                            backgroundColor: Colors.transparent,
                            builder: (BuildContext context) {
                              return Container(
                                height: SizeConfig.heightMultiplier! * 50,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15),
                                  ),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.symmetric(horizontal: SizeConfig.widthMultiplier! * 6),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 4,
                                      ),
                                      Text(
                                        'Language',
                                        style: TextStyle(
                                          fontSize: SizeConfig.textMultiplier! * 2,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 3,
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 5,
                                        width: SizeConfig.widthMultiplier! * 88,
                                        child: ElevatedButton(
                                          style: TextButton.styleFrom(
                                            backgroundColor: const Color(0xFF25794F),
                                            elevation: 5,
                                          ),
                                          onPressed: () {
                                            Navigator.pop(context, 'English');
                                          },
                                          child: Text(
                                            'English',
                                            style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier! * 2,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 2,
                                      ),
                                      SizedBox(
                                        height: SizeConfig.heightMultiplier! * 5,
                                        width: SizeConfig.widthMultiplier! * 88,
                                        child: ElevatedButton(
                                          style: TextButton.styleFrom(
                                            backgroundColor: const Color(0xFF25794F),
                                            elevation: 5,
                                          ),
                                          onPressed: () {
                                            Navigator.pop(context, 'Arabic');
                                          },
                                          child: Text(
                                            'Arabic',
                                            style: TextStyle(
                                              fontSize: SizeConfig.textMultiplier! * 2,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );
                        },
                        child: Text(
                          'English',
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 2,
                            fontWeight: FontWeight.w400,
                            color: Colors.black54,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'High contrast',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Switch.adaptive(
                        value: true,
                        activeColor: const Color(0xFF25794F),
                        inactiveThumbColor: Colors.grey.shade50,
                        onChanged: (value) {},
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Bolder font',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Switch.adaptive(
                        value: true,
                        activeColor: const Color(0xFF25794F),
                        inactiveThumbColor: Colors.grey.shade50,
                        onChanged: (value) {},
                      )
                    ],
                  ),
                ],
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 6,
              child: Row(
                children: [
                  Icon(
                    Icons.calendar_today_outlined,
                    size: SizeConfig.imageSizeMultiplier! * 6,
                  ),
                  SizedBox(
                    width: SizeConfig.widthMultiplier! * 2,
                  ),
                  Text(
                    'Calendar',
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 39,
              left: SizeConfig.widthMultiplier! * 6,
              child: Container(
                color: Colors.black,
                height: SizeConfig.heightMultiplier! * 0.02,
                width: SizeConfig.widthMultiplier! * 88,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 42,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Daily summary',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Switch.adaptive(
                        value: true,
                        activeColor: const Color(0xFF25794F),
                        inactiveThumbColor: Colors.grey.shade50,
                        onChanged: (value) {},
                      )
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Events reminders',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                      Switch.adaptive(
                        value: true,
                        activeColor: const Color(0xFF25794F),
                        inactiveThumbColor: Colors.grey.shade50,
                        onChanged: (value) {},
                      ),
                    ],
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 2,
                  ),
                  TextButton(
                    onPressed: () {
                      GlobalController.deleteInfo();
                      FirebaseAuth.instance.signOut();
                      Navigator.push(
                        context,
                        PageRouteBuilder(
                            pageBuilder: (context, animation, secondaryAnimation) {
                              return const Login();
                            },
                            transitionDuration: const Duration(milliseconds: 500),
                            transitionsBuilder: (context, animation, secondaryAnimation, child) {
                              return FadeTransition(
                                opacity: animation,
                                child: child,
                              );
                            }),
                      );
                    },
                    child: Text(
                      'Logout',
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 3,
                        fontWeight: FontWeight.w400,
                        color: Colors.red.shade700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
