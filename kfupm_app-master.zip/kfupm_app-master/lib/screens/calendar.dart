import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/calendar_controller.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/controllers/heat_map_controller.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/utils/time.dart';
import 'package:kfupm_app/widgets/calendar/week.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/edit_personal_event_sheet.dart';

class Calendar extends StatefulWidget {
  const Calendar({Key? key}) : super(key: key);

  @override
  _CalendarState createState() => _CalendarState();
}

class _CalendarState extends State<Calendar> {
  CalendarController? calendarController;

  openSheet(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: const EditPersonalEventSheet(
        title: 'Add Event',
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  @override
  void initState() {
    calendarController = CalendarController();
    GlobalController.calendarState = this;
    GlobalController.calendarController = calendarController!;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            SizedBox(
              width: SizeConfig.widthMultiplier! * 2,
            ),
            Text(
              'Calendar',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 3,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: SizeConfig.heightMultiplier! * 0,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 2,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    calendarController!.currentMonth + ' ' + DateTime.now().year.toString(),
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 3,
                      fontWeight: FontWeight.w700,
                      color: Colors.black,
                    ),
                  ),
                  IconButton(
                    onPressed: () async {
                      await openSheet(context);
                    },
                    icon: Icon(
                      Icons.add_circle_outline_rounded,
                      size: SizeConfig.imageSizeMultiplier! * 7,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 5,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(
                  Time.days.length,
                  (index) {
                    return Text(
                      Time.days[index],
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2,
                        fontWeight: FontWeight.w400,
                        color: Colors.black54,
                      ),
                    );
                  },
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 7.5,
              left: SizeConfig.widthMultiplier! * 0,
              right: SizeConfig.widthMultiplier! * 0,
              bottom: SizeConfig.heightMultiplier! * 0,
              child: SizedBox(
                height: SizeConfig.heightMultiplier! * 70,
                child: NotificationListener<ScrollNotification>(
                  onNotification: (notification) {
                    setState(() {});
                    calendarController!.changeMonth(notification.metrics.pixels.toInt() + 100);
                    return true;
                  },
                  child: ListView.builder(
                    controller: ScrollController(
                      initialScrollOffset: (calendarController!.currentWeek + 3) * SizeConfig.heightMultiplier! * 11.7,
                    ),
                    itemCount: calendarController!.daysList.length,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return Week(
                          week: calendarController!.daysList[index],
                          skipDays: calendarController!.skipDays,
                          calendarController: calendarController!,
                          heatMapController: HeatMapController(),
                          weekNumber: index,
                        );
                      } else {
                        return Week(
                          week: calendarController!.daysList[index],
                          skipDays: 0,
                          calendarController: calendarController!,
                          heatMapController: HeatMapController(),
                          weekNumber: index,
                        );
                      }
                    },
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
