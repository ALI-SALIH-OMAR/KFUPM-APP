/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is a clubs screen.
Note: Noting.
 */
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/services/firebase/club_services.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/cards/club_card.dart';
import 'package:kfupm_app/widgets/custom_scroll_view_list.dart';
import 'package:kfupm_app/widgets/search_text_field.dart';
import 'package:kfupm_app/widgets/skeletons/club_card_skeleton.dart';

class Clubs extends StatefulWidget {
  const Clubs({Key? key}) : super(key: key);

  @override
  State<Clubs> createState() => _ClubsState();
}

class _ClubsState extends State<Clubs> {
  ScrollController scrollController = ScrollController();
  late double dy;
  late double searchPosition;
  List<ClubModel> clubs = [];
  List<ClubModel> spareClubs = [];
  bool once = true;

  getData() async {
    if (once) {
      once = false;
      clubs = await ClubServices.getClubsWithEvents();
    }
    spareClubs = await ClubServices.getClubsWithEvents();
  }

  Widget searchBar = Container(
    color: Colors.transparent,
    height: 10,
    width: 10,
  );

  void _start(DragDownDetails details) {
    setState(() {
      dy = details.globalPosition.dy.floorToDouble();
    });
  }

  void _onVerticalDragStartHandler() {
    setState(() {
      if (dy - scrollController.offset > 0) {
        searchBar = SearchTextField(
          textEditingController: TextEditingController(),
          passedFunction: () {
            changePosition();
          },
          searchFunction: (String value) {
            filterSearchResults(value);
          },
        );
      } else if (dy - scrollController.offset < 0) {
        searchBar = Container();
      }
    });
  }

  Widget _animation() => AnimatedSwitcher(
        duration: const Duration(milliseconds: 100),
        transitionBuilder: (Widget child, Animation<double> animation) =>
            SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.0, 1.0),
            end: const Offset(0, 0),
          ).animate(animation),
          child: child,
        ),
        child: searchBar,
      );

  void changePosition() {
    setState(() {
      searchPosition = SizeConfig.heightMultiplier! * 1;
    });
  }

  void returnPosition() {
    setState(() {
      searchPosition = SizeConfig.heightMultiplier! * 70;
    });
  }

  @override
  void initState() {
    searchPosition = SizeConfig.heightMultiplier! * 70;
    dy = 0;
    scrollController.addListener(_onVerticalDragStartHandler);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Clubs',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: FutureBuilder(
            future: getData(),
            builder: (BuildContext context, AsyncSnapshot snapshot) {
              if (clubs.isNotEmpty ||
                  snapshot.connectionState == ConnectionState.done) {
                return Stack(
                  alignment: AlignmentDirectional.topCenter,
                  children: [
                    Positioned(
                      top: SizeConfig.heightMultiplier! * 1,
                      child: GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        dragStartBehavior: DragStartBehavior.start,
                        onVerticalDragDown: _start,
                        onTap: () {
                          returnPosition();
                        },
                        child: SizedBox(
                          height: SizeConfig.heightMultiplier! * 73,
                          width: SizeConfig.widthMultiplier! * 100,
                          child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            controller: scrollController,
                            physics: const ScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: clubs.length,
                            itemBuilder: (BuildContext context, int index) {
                              return ClubCard(
                                club: clubs[index],
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                    AnimatedPositioned(
                      top: searchPosition,
                      duration: const Duration(milliseconds: 100),
                      child: GestureDetector(
                        onTap: () {
                          changePosition();
                        },
                        child: _animation(),
                      ),
                    ),
                  ],
                );
              }
              if (clubs.isEmpty &&
                  snapshot.connectionState != ConnectionState.done) {
                return Stack(
                  alignment: AlignmentDirectional.topCenter,
                  children: [
                    Positioned(
                      top: SizeConfig.heightMultiplier! * 1,
                      child: GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        dragStartBehavior: DragStartBehavior.start,
                        onVerticalDragDown: _start,
                        onTap: () {
                          returnPosition();
                        },
                        child: CustomScrollViewList(
                          widget: const ClubCardSkeleton(),
                          scrollController: scrollController,
                        ),
                      ),
                    ),
                  ],
                );
              }
              return Container();
            }),
      ),
    );
  }

  //search method for searching inside clubs page
  void filterSearchResults(String searchWord) async {
    if (searchWord.isNotEmpty) {
      List<ClubModel> searchList = [];
      for (var club in clubs) {
        if (club.name.toUpperCase().contains(searchWord.toUpperCase())) {
          searchList.add(club);
        }
      }
      setState(() {
        if (searchList.isNotEmpty) {
          clubs.clear();
          clubs.addAll(searchList);
        } else {
          clubs.clear();
          clubs.addAll(spareClubs);
        }
      });
    } else {
      setState(() {
        clubs.clear();
        clubs.addAll(spareClubs);
      });
    }
  }
}
