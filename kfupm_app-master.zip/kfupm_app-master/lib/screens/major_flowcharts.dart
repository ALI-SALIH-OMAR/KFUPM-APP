import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/entities/college.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/cards/college_card.dart';

import '../services/firebase/college_services.dart';

class MajorFlowcharts extends StatefulWidget {
  const MajorFlowcharts({Key? key}) : super(key: key);

  @override
  State<MajorFlowcharts> createState() => _MajorFlowchartsState();
}

class _MajorFlowchartsState extends State<MajorFlowcharts> {
  late List<College> colleges;

  getData() async {
    colleges = await CollegeServices.getColleges();
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF7F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Flowcharts',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 29.4,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: FutureBuilder(
        future: getData(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Stack(
              children: [
                Positioned(
                  top: Constant.topContent,
                  left: SizeConfig.widthMultiplier! * 6,
                  right: SizeConfig.widthMultiplier! * 6,
                  bottom: 50,
                  child: SingleChildScrollView(
                    child: Column(
                      children: List.generate(
                        colleges.length,
                        (index) {
                          return CollegeCard(
                            college: colleges[index],
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ],
            );
          } else {
            return Container();
          }
        },
      ),
    );
  }
}
