/*
Author: Saud Elabdullah.
Work: This class work as screen that represents a group of widget,
It works as a login page.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/buttons/long_button.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  late final TextEditingController textEditingControllerOne;
  late final TextEditingController textEditingControllerTwo;
  bool checkBoxValue = false;

  @override
  void initState() {
    textEditingControllerOne = TextEditingController();
    textEditingControllerTwo = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    textEditingControllerOne.dispose();
    textEditingControllerTwo.dispose();
    super.dispose();
  }

  final List<GlobalKey<NavigatorState>> _navigatorKeys = [
    GlobalKey<NavigatorState>(),
  ];

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final isFirstRouteInCurrentTab = await _navigatorKeys[0].currentState!.maybePop();
        return isFirstRouteInCurrentTab;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Stack(
            alignment: AlignmentDirectional.center,
            children: [
              Positioned(
                top: SizeConfig.heightMultiplier! * 2,
                left: SizeConfig.widthMultiplier! * 6,
                child: Image.asset(
                  'assets/launcher/icon.png',
                  scale: SizeConfig.imageSizeMultiplier! * 0.5,
                ),
              ),
              Positioned(
                top: SizeConfig.heightMultiplier! * 20,
                left: SizeConfig.widthMultiplier! * 6,
                child: Text(
                  'Sign in to KFUPM App',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 3,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Positioned(
                top: SizeConfig.heightMultiplier! * 30,
                left: SizeConfig.widthMultiplier! * 6,
                right: SizeConfig.widthMultiplier! * 6,
                child: Container(
                  padding: const EdgeInsets.only(left: 5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      width: 1.0,
                      color: Colors.grey.shade300,
                    ),
                  ),
                  child: TextField(
                    controller: textEditingControllerOne,
                    obscureText: false,
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2,
                    ),
                    decoration: const InputDecoration(
                      hintText: 'Email address',
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.only(top: 1.5, bottom: 1.5, right: 5, left: 5),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: SizeConfig.heightMultiplier! * 37,
                left: SizeConfig.widthMultiplier! * 6,
                right: SizeConfig.widthMultiplier! * 6,
                child: Container(
                  padding: const EdgeInsets.only(left: 5),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      width: 1.0,
                      color: Colors.grey.shade300,
                    ),
                  ),
                  child: TextField(
                    controller: textEditingControllerTwo,
                    obscureText: true,
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2,
                    ),
                    decoration: const InputDecoration(
                      hintText: 'Password',
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: EdgeInsets.only(top: 1.5, bottom: 1.5, right: 5, left: 5),
                    ),
                  ),
                ),
              ),
              Positioned(
                top: SizeConfig.heightMultiplier! * 47,
                child: LongButton(
                  textEditingControllerOne: textEditingControllerOne,
                  textEditingControllerTwo: textEditingControllerTwo,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
