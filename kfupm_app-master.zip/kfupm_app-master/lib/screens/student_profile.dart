/*
Author: Saud Elabdullah.
Work: This class work as a widget to show the student profile.
Note: Nothing.
 */
import 'dart:io';

import 'package:add_to_wallet/widgets/add_to_wallet_button.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/services/get_pkpass.dart';
import 'package:kfupm_app/utils/size_config.dart';

class StudentProfile extends StatefulWidget {
  const StudentProfile({Key? key}) : super(key: key);

  @override
  State<StudentProfile> createState() => _StudentProfileState();
}

class _StudentProfileState extends State<StudentProfile> {
  late File file;

  @override
  void initState() {
    file = ApplePass.file;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Profile',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: SizedBox(
            height: SizeConfig.heightMultiplier! * 85,
            child: Stack(
              children: [
                Positioned(
                  top: SizeConfig.heightMultiplier! * 2,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                GlobalController.student!.firstName + GlobalController.student!.lastName,
                                style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier! * 3.3,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(
                                width: SizeConfig.widthMultiplier! * 3,
                              ),
                              Container(
                                height: SizeConfig.heightMultiplier! * 2.5,
                                width: SizeConfig.widthMultiplier! * 10,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFBF1B),
                                  borderRadius: BorderRadius.circular(5),
                                ),
                                child: Center(
                                  child: Text(
                                    GlobalController.student!.major,
                                    style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier! * 1.5,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1,
                          ),
                          Text(
                            GlobalController.student!.status,
                            style: TextStyle(
                              fontSize: SizeConfig.widthMultiplier! * 4,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 5,
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: SizeConfig.heightMultiplier! * 12,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Container(
                    color: Colors.black,
                    height: SizeConfig.heightMultiplier! * 0.02,
                    width: SizeConfig.widthMultiplier! * 88,
                  ),
                ),
                Positioned(
                  top: SizeConfig.heightMultiplier! * 15,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Email address',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                          color: Colors.black54,
                        ),
                      ),
                      Text(
                        GlobalController.student!.email,
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: SizeConfig.heightMultiplier! * 24,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Concentration (CX)',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                          color: Colors.black54,
                        ),
                      ),
                      Text(
                        GlobalController.student!.concentration,
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: SizeConfig.heightMultiplier! * 33,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Advisor',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                          color: Colors.black54,
                        ),
                      ),
                      Text(
                        GlobalController.student!.advisorFirstName + ' ' + GlobalController.student!.advisorLastName,
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: SizeConfig.heightMultiplier! * 42,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Housing',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                          color: Colors.black54,
                        ),
                      ),
                      Text(
                        GlobalController.student!.housing,
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: SizeConfig.heightMultiplier! * 51,
                  left: SizeConfig.widthMultiplier! * 6,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Club(s)',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2,
                          fontWeight: FontWeight.w400,
                          color: Colors.black54,
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: List.generate(
                          GlobalController.student!.followedClubs.length,
                          (index) {
                            return Text(
                              GlobalController.student!.followedClubs[index],
                              style: TextStyle(
                                fontSize: SizeConfig.textMultiplier! * 2,
                                fontWeight: FontWeight.w400,
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                if (Platform.isIOS) ...[
                  Positioned(
                    left: SizeConfig.widthMultiplier! * 6,
                    right: SizeConfig.widthMultiplier! * 6,
                    bottom: SizeConfig.heightMultiplier! * 10,
                    child: AddToWalletButton(
                      pkPass: file.readAsBytesSync(),
                      width: SizeConfig.widthMultiplier! * 88,
                      height: SizeConfig.heightMultiplier! * 5,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
