import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/location_sheet.dart';
import 'package:label_marker/label_marker.dart';

import '../constants/locations.dart';

class KMap extends StatefulWidget {
  const KMap({Key? key}) : super(key: key);

  @override
  State<KMap> createState() => _KMapState();
}

class _KMapState extends State<KMap> {
  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(GlobalController.position.latitude, GlobalController.position.longitude),
    zoom: 17,
  );

  openSheet(BuildContext context, String label) async {
    await bottomSheet(
      context: context,
      child:  LocationSheet(label: label),
      bottomPadding: 0,
      bottomButton: const SizedBox(),
      showBottomButton: false,
      height: 65,
    );
  }
  Set<Marker> markers = {};
  GoogleMapController? controller;

  @override
  void initState() {
    super.initState();
    var marker = SavedLocation().markers;
    for (var element in marker) {
    markers.addLabelMarker(
      LabelMarker(
          label: element.label,
          markerId:  MarkerId(element.label),
          position:  LatLng(element.lat, element.lon),
          backgroundColor: Colors.green,
          onTap: () async {
            await openSheet(context, element.label);
          }),
    );}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GoogleMap(
        myLocationEnabled: true,
        myLocationButtonEnabled: true,
        mapType: MapType.normal,
        initialCameraPosition: _kGooglePlex,
        markers: markers,
        onMapCreated: ((mapController) {
          setState(() {
            controller = mapController;
          });
        }),
      ),
    );
  }
}
