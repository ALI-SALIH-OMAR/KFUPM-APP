/*
Author: Saud Elabdullah.
Work: This class work as a widget class to show a section information.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/screens/course.dart';
import 'package:kfupm_app/screens/heat_map.dart';
import 'package:kfupm_app/screens/instructor_profile.dart';
import 'package:kfupm_app/services/firebase/instructor_services.dart';
import 'package:kfupm_app/services/firebase/section_services.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/theme/app_theme.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/open_url.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/edit_personal_event_sheet.dart';

class SectionScreen extends StatefulWidget {
  const SectionScreen({
    Key? key,
    required this.returnPage,
    required this.crn,
  }) : super(key: key);
  final String returnPage;
  final String crn;

  @override
  State<SectionScreen> createState() => _SectionScreenState();
}

class _SectionScreenState extends State<SectionScreen> {
  late Section section;

  openSheet(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: EditPersonalEventSheet(
        title: 'Add Task',
        isSection: true,
        section: section,
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  Future<Section> getData() async {
    return await SectionServices.getSection(widget.crn);
  }

  bool isTeaching(){
    for(var course in GlobalController.instructor!.teachingCourses){
      if(course['crn'] == section.crn){
        return true;
      }
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Section',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                widget.returnPage,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: FutureBuilder<Section>(
          future: getData(),
          builder: (BuildContext context, AsyncSnapshot<Section> snapshot) {
            if (snapshot.hasData && snapshot.connectionState == ConnectionState.done) {
              section = snapshot.data!;
              GlobalController.section = section;
              InstructorServices.getInstructorByName(section.courseName, section.crn, section.code);
              return Stack(
                alignment: AlignmentDirectional.topCenter,
                children: [
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 2,
                    left: SizeConfig.widthMultiplier! * 6,
                    right: SizeConfig.widthMultiplier! * 6,
                    child: Container(
                      padding: symmetricInsets(
                        horizontal: SizeConfig.widthMultiplier! * 0.6,
                        vertical: SizeConfig.heightMultiplier! * 0.3,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.secondaryColor,
                        borderRadius: Constant.borderRadiusMedium,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            section.code,
                            style: AppTheme.textStyleEleven,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 1,
                          ),
                          Text(
                            'CRN ${section.crn}',
                            style: AppTheme.textStyleTen,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          Row(
                            children: [
                              Text(
                                'Course Name: ',
                                style: AppTheme.textStyleTen,
                              ),
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      GlobalController.passedContext,
                                      MaterialPageRoute(
                                        builder: (context) => CourseScreen(
                                          code: section.code,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Text(
                                    '${section.courseName} ↗',
                                    style: AppTheme.textStyleTen.copyWith(
                                      decoration: TextDecoration.underline,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Text(
                            'Section No.: ${section.sectionNumber}',
                            style: AppTheme.textStyleTen,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Row(
                            children: [
                              Text(
                                'Instructor: ',
                                style: AppTheme.textStyleTen,
                              ),
                              Expanded(
                                child: GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      GlobalController.passedContext,
                                      MaterialPageRoute(
                                        builder: (context) => const InstructorProfile(
                                          prevPage: 'Section',
                                          showOtherInstructor: true,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Text(
                                    '${section.instructor} ↗',
                                    style: AppTheme.textStyleTen.copyWith(
                                      decoration: TextDecoration.underline,
                                      overflow: TextOverflow.ellipsis
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Text(
                            'Days: ${section.time}',
                            style: AppTheme.textStyleTen,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Row(
                            children: [
                              Text(
                                'Location: ',
                                style: AppTheme.textStyleTen,
                              ),
                              Text(
                                section.location,
                                style: AppTheme.textStyleTen.copyWith(),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                          Text(
                            'Time: ${section.time}',
                            style: AppTheme.textStyleTen,
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 3,
                          ),
                          Container(
                            padding: EdgeInsets.all(
                              SizeConfig.widthMultiplier! * 2,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFCDF2C0),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  PhosphorIcons.whatsapp_logo,
                                  size: SizeConfig.imageSizeMultiplier! * 5,
                                ),
                                SizedBox(
                                  width: SizeConfig.widthMultiplier! * 2,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    launchURL(section.groupChat);
                                  },
                                  child: Text(
                                    'Sections WhatsApp Group Chat ↗',
                                    style: AppTheme.textStyleTen.copyWith(
                                      decoration: TextDecoration.underline,
                                      fontSize: SizeConfig.textMultiplier! * 1.9,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (GlobalController.ins) ...[
                            SizedBox(
                              height: SizeConfig.heightMultiplier! * 5,
                            ),
                            Center(
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => HeatMap(
                                        section: section,
                                      ),
                                    ),
                                  );
                                },
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                    vertical: SizeConfig.heightMultiplier! * 1,
                                    horizontal: SizeConfig.widthMultiplier! * 5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFCDF2C0),
                                    borderRadius: BorderRadius.circular(
                                      10,
                                    ),
                                  ),
                                  child: Text(
                                    'View HeatMap',
                                    style: TextStyle(
                                      fontSize: SizeConfig.textMultiplier! * 2.1,
                                      fontWeight: FontWeight.w400,
                                      color: Colors.black87,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: SizeConfig.heightMultiplier! * 1,
                            ),
                            if(isTeaching())...[
                              Center(
                                child: GestureDetector(
                                  onTap: () async {
                                    await openSheet(context);
                                  },
                                  child: Container(
                                    padding: EdgeInsets.symmetric(
                                      vertical: SizeConfig.heightMultiplier! * 1,
                                      horizontal: SizeConfig.widthMultiplier! * 5,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFCDF2C0),
                                      borderRadius: BorderRadius.circular(
                                        10,
                                      ),
                                    ),
                                    child: Text(
                                      'Add Task',
                                      style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier! * 2.1,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black87,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ]
                          ]
                        ],
                      ),
                    ),
                  ),
                ],
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
