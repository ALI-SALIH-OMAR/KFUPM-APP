/*
Author: Saud Elabdullah.
Work: This class work as a widget to show the courses.
Note: Nothing.
 */
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/courses_controller.dart';
import 'package:kfupm_app/entities/major.dart';
import 'package:kfupm_app/services/firebase/majors_services.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/cards/course_card.dart';
import 'package:kfupm_app/widgets/custom_scroll_view_list.dart';
import 'package:kfupm_app/widgets/dropdown_department_menu.dart';
import 'package:kfupm_app/widgets/search_text_field.dart';
import 'package:kfupm_app/widgets/skeletons/course_card_skeleton.dart';
import 'package:kfupm_app/widgets/skeletons/dropdown_skeleton.dart';

import '../entities/short_course.dart';

class Courses extends StatefulWidget {
  const Courses({Key? key}) : super(key: key);

  @override
  State<Courses> createState() => _CoursesState();
}

class _CoursesState extends State<Courses> {
  ScrollController scrollController = ScrollController();
  late double dy;
  late double searchPosition;
  CoursesController? coursesController;
  late Future<List<Major>> snapshot;
  bool once = true;
  List<ShortCourse> searchedCourse = [];
  Widget searchBar = Container(
    color: Colors.transparent,
    height: 10,
    width: 10,
  );

  void _start(DragDownDetails details) {
    setState(() {
      dy = details.globalPosition.dy.floorToDouble();
    });
  }

  void _onVerticalDragStartHandler() {
    setState(() {
      if (dy - scrollController.offset > 0) {
        searchBar = SearchTextField(
          textEditingController: TextEditingController(),
          passedFunction: () {
            changePosition();
          },
          searchFunction: (String value) {
            filterSearchResults(value);
          },
        );
      } else if (dy - scrollController.offset < 0) {
        searchBar = Container();
      }
    });
  }

  Widget _animation() => AnimatedSwitcher(
        duration: const Duration(milliseconds: 100),
        transitionBuilder: (Widget child, Animation<double> animation) =>
            SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.0, 1.0),
            end: const Offset(0, 0),
          ).animate(animation),
          child: child,
        ),
        child: searchBar,
      );

  void changePosition() {
    setState(() {
      searchPosition = SizeConfig.heightMultiplier! * 1;
    });
  }

  void returnPosition() {
    setState(() {
      searchPosition = SizeConfig.heightMultiplier! * 70;
    });
  }

  @override
  void initState() {
    searchPosition = SizeConfig.heightMultiplier! * 70;
    dy = 0;
    scrollController.addListener(_onVerticalDragStartHandler);
    coursesController = CoursesController();
    snapshot = MajorsServices.getCourses();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Courses',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: FutureBuilder<List<Major>>(
          future: snapshot,
          builder: (BuildContext context, AsyncSnapshot<List<Major>> snapshot) {
            if (snapshot.connectionState != ConnectionState.done &&
                snapshot.data == null) {
              return Stack(
                alignment: AlignmentDirectional.topCenter,
                children: [
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 2,
                    child: const DropdownSkeleton(),
                  ),
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 8,
                    bottom: 0,
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      dragStartBehavior: DragStartBehavior.start,
                      onVerticalDragDown: _start,
                      onTap: () {
                        returnPosition();
                      },
                      child: CustomScrollViewList(
                        widget: const CourseCardSkeleton(),
                        scrollController: scrollController,
                      ),
                    ),
                  ),
                ],
              );
            }
            if (snapshot.data != null) {
              List<String> majors = coursesController!.getMajors(snapshot.data);
              majors.insert(0, 'All Majors');
              if (searchedCourse.isNotEmpty) {
                return Stack(
                  alignment: AlignmentDirectional.topCenter,
                  children: [
                    Positioned(
                      top: SizeConfig.heightMultiplier! * 2,
                      child: DropdownMenu(
                        departments: majors,
                        coursesController: coursesController,
                        state: this,
                      ),
                    ),
                    Positioned(
                      top: SizeConfig.heightMultiplier! * 8,
                      bottom: 0,
                      child: GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        dragStartBehavior: DragStartBehavior.start,
                        onVerticalDragDown: _start,
                        onTap: () {
                          returnPosition();
                        },
                        child: SizedBox(
                          height: SizeConfig.heightMultiplier! * 73,
                          width: SizeConfig.widthMultiplier! * 100,
                          child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            controller: scrollController,
                            physics: const ScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: searchedCourse.length,
                            itemBuilder: (BuildContext context, int index) {
                              return CourseCard(
                                shortCourse: searchedCourse[index],
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                    AnimatedPositioned(
                      top: searchPosition,
                      duration: const Duration(milliseconds: 100),
                      child: GestureDetector(
                        onTap: () {
                          changePosition();
                        },
                        child: _animation(),
                      ),
                    ),
                  ],
                );
              } else {
                coursesController!.getShortCourses();
                return Stack(
                  alignment: AlignmentDirectional.topCenter,
                  children: [
                    Positioned(
                      top: SizeConfig.heightMultiplier! * 2,
                      child: DropdownMenu(
                        departments: majors,
                        coursesController: coursesController,
                        state: this,
                      ),
                    ),
                    Positioned(
                      top: SizeConfig.heightMultiplier! * 8,
                      bottom: 0,
                      child: GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        dragStartBehavior: DragStartBehavior.start,
                        onVerticalDragDown: _start,
                        onTap: () {
                          returnPosition();
                        },
                        child: SizedBox(
                          height: SizeConfig.heightMultiplier! * 73,
                          width: SizeConfig.widthMultiplier! * 100,
                          child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            controller: scrollController,
                            physics: const ScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: coursesController?.courses?.length,
                            itemBuilder: (BuildContext context, int index) {
                              return CourseCard(
                                shortCourse: coursesController!.courses![index],
                              );
                            },
                          ),
                        ),
                      ),
                    ),
                    AnimatedPositioned(
                      top: searchPosition,
                      duration: const Duration(milliseconds: 100),
                      child: GestureDetector(
                        onTap: () {
                          changePosition();
                        },
                        child: _animation(),
                      ),
                    ),
                  ],
                );
              }
            }
            return Container();
          },
        ),
      ),
    );
  }

  //search method for searching inside courses page
  void filterSearchResults(String searchWord) async {
    if (searchWord.isNotEmpty) {
      searchedCourse.clear();
      coursesController!.getShortCourses();
      List<ShortCourse> searchList = [];
      coursesController!.courses?.forEach((course) {
        if (course.code.toUpperCase().contains(searchWord.toUpperCase())) {
          searchList.add(course);
        }
      });
      setState(() {
        if (searchList.isNotEmpty) {
          searchedCourse.addAll(searchList);
        }
      });
    }
  }
}
