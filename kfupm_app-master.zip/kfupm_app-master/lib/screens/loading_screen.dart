import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/controllers/section_controller.dart';
import 'package:kfupm_app/screens/principale.dart';
import 'package:kfupm_app/utils/location.dart';

import '../services/firebase/auth_services.dart';
import '../utils/size_config.dart';

class LoadingScreen extends StatefulWidget {
  const LoadingScreen({Key? key}) : super(key: key);

  @override
  _LoadingScreenState createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {

  Future<void> setLocation() async {
    GlobalController.position = await Location.determinePosition();
  }

  Future<void> setSchedule() async {
    GlobalController.sections = await SectionController.getStudentSections();
  }

  void appInit() async {
    Future.wait([AuthServices.getUser(), setLocation()])
        .then((value) {
      if (GlobalController.isMounted) {
        ///TODO: fix this!
        if(GlobalController.stu){
          setSchedule();
        }
        Timer(
          const Duration(milliseconds: 500),
              () {
            if (mounted) {
              Navigator.of(context).push(
                PageRouteBuilder(
                    pageBuilder: (context, animation, secondaryAnimation) {
                      return const Principale();
                    },
                    transitionDuration: const Duration(milliseconds: 500),
                    transitionsBuilder: (context, animation, secondaryAnimation, child) {
                      return FadeTransition(
                        opacity: animation,
                        child: child,
                      );
                    }),
              );
            }
          },
        );
      }
    });
    // await AuthServices.getUser();
    // GlobalController.position = await Location.determinePosition();
    // if (GlobalController.isMounted) {
    //   Timer(
    //     const Duration(seconds: 1),
    //     () {
    //       if (mounted) {
    //         Navigator.of(context).push(
    //           PageRouteBuilder(
    //               pageBuilder: (context, animation, secondaryAnimation) {
    //                 return const Principale();
    //               },
    //               transitionDuration: const Duration(milliseconds: 700),
    //               transitionsBuilder: (context, animation, secondaryAnimation, child) {
    //                 return FadeTransition(
    //                   opacity: animation,
    //                   child: child,
    //                 );
    //               }),
    //         );
    //       }
    //     },
    //   );
    // }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  void didChangeDependencies() {
    appInit();
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF163C25),
      body: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Positioned(
            bottom: 0,
            child: Image.asset(
              'assets/launcher/icon.png',
              scale: SizeConfig.imageSizeMultiplier! * 0.9,
            ),
          ),
        ],
      ),
    );
  }
}
