/*
Author: Saud Elabdullah.
Work: This class work as a widget and it is the starting point (The main screen)
of the program.
Note: Principale means in italian 'main'.
 */

import 'package:flutter/material.dart';
import 'package:flutter_phosphor_icons/flutter_phosphor_icons.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/screens/calendar.dart';
import 'package:kfupm_app/screens/k_map.dart';
import 'package:kfupm_app/screens/events.dart';
import 'package:kfupm_app/screens/services.dart';
import 'package:kfupm_app/services/notification.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';
import '../deep_links/dynamic_link_services.dart';

class Principale extends StatefulWidget {
  const Principale({Key? key}) : super(key: key);

  @override
  State<Principale> createState() => _PrincipaleState();
}

class _PrincipaleState extends State<Principale> {

  @override
  void initState() {
    GlobalController.passedContext = context;
    FireBaseDynamicLink.initDynamicLink(GlobalController.passedContext);
    setUpNotification();
    super.initState();
  }

  final List<GlobalKey<NavigatorState>> _navigatorKeys = [
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
    GlobalKey<NavigatorState>(),
  ];

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        final isFirstRouteInCurrentTab = await _navigatorKeys[GlobalController.selectedIndex].currentState!.maybePop();
        return isFirstRouteInCurrentTab;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFFAF7F5),
        body: SafeArea(
          child: Stack(
            children: [
              _buildOffstageNavigator(0),
              _buildOffstageNavigator(1),
              _buildOffstageNavigator(2),
              _buildOffstageNavigator(3),
            ],
          ),
        ),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          elevation: 10.0,
          backgroundColor: AppColors.primaryColor,
          showSelectedLabels: false,
          showUnselectedLabels: false,
          iconSize: SizeConfig.imageSizeMultiplier! * 8,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(
                PhosphorIcons.calendar,
                color: Colors.white,
              ),
              activeIcon: Icon(
                PhosphorIcons.calendar_fill,
                color: Colors.white,
              ),
              label: 'Calendar',
            ),
            BottomNavigationBarItem(
              icon: Icon(PhosphorIcons.map_trifold, color: Colors.white),
              activeIcon: Icon(
                PhosphorIcons.map_trifold_fill,
                color: Colors.white,
              ),
              label: 'Map',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                PhosphorIcons.ticket,
                color: Colors.white,
              ),
              activeIcon: Icon(
                PhosphorIcons.ticket_fill,
                color: Colors.white,
              ),
              label: 'Events',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                PhosphorIcons.smiley,
                color: Colors.white,
              ),
              activeIcon: Icon(
                PhosphorIcons.smiley_wink_fill,
                color: Colors.white,
              ),
              label: 'Services',
            ),
          ],
          currentIndex: GlobalController.selectedIndex,
          onTap: (int index) {
            setState(() {
              GlobalController.selectedIndex = index;
            });
          },
        ),
      ),
    );
  }

  Map<String, WidgetBuilder> _routeBuilders(BuildContext context, int index) {
    return {
      '/': (context) {
        GlobalController.passedContext = context;
        return const [
          Calendar(),
          KMap(),
          Events(),
          Services(),
        ].elementAt(index);
      },
    };
  }

  Widget _buildOffstageNavigator(int index) {
    Map<String?, WidgetBuilder?>? routeBuilders = _routeBuilders(context, index);

    return Offstage(
      offstage: GlobalController.selectedIndex != index,
      child: Navigator(
        key: _navigatorKeys[index],
        onGenerateRoute: (routeSettings) {
          return MaterialPageRoute(
            builder: (context) => routeBuilders[routeSettings.name]!(context),
          );
        },
      ),
    );
  }
}
