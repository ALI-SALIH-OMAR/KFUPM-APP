/*
Author: Saud Elabdullah.
Work: This class work as a widget to show course's information.
Note: Nothing.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/course.dart';
import 'package:kfupm_app/screens/evaluation.dart';
import 'package:kfupm_app/screens/section.dart';
import 'package:kfupm_app/services/firebase/course_services.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/theme/app_theme.dart';
import 'package:kfupm_app/utils/edge_insets.dart';
import 'package:kfupm_app/utils/open_url.dart';
import 'package:kfupm_app/utils/size_config.dart';

class CourseScreen extends StatefulWidget {
  const CourseScreen({
    Key? key,
    required this.code,
  }) : super(key: key);
  final String code;

  @override
  State<CourseScreen> createState() => _CourseScreenState();
}

class _CourseScreenState extends State<CourseScreen> {
  late Course course;

  getData() async {
    course = await CourseServices.getCourse(widget.code);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Courses',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Courses',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: FutureBuilder(
          future: getData(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return Stack(
                alignment: AlignmentDirectional.topCenter,
                children: [
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 4,
                    left: SizeConfig.widthMultiplier! * 6,
                    right: SizeConfig.widthMultiplier! * 6,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              course.code,
                              style: TextStyle(
                                fontSize: SizeConfig.widthMultiplier! * 8,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            if (GlobalController.stu)
                              Container(
                                padding: symmetricInsets(
                                  horizontal: 2,
                                  vertical: 1,
                                ),
                                decoration: BoxDecoration(
                                  color: AppColors.secondaryColor,
                                  borderRadius: Constant.borderRadiusSmall,
                                ),
                                child: Center(
                                  child: Text(
                                    GlobalController.student!.courses.contains(widget.code)
                                        ? 'Registered'
                                        : 'Not Registered',
                                    style: AppTheme.textStyleFive,
                                  ),
                                ),
                              ),
                          ],
                        ),
                        SizedBox(
                          height: SizeConfig.heightMultiplier! * 1,
                        ),
                        Text(
                          course.name,
                          style: TextStyle(
                            fontSize: SizeConfig.widthMultiplier! * 5,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: SizeConfig.heightMultiplier! * 14,
                    left: SizeConfig.widthMultiplier! * 6,
                    right: SizeConfig.widthMultiplier! * 6,
                    bottom: 0,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: symmetricInsets(
                                  horizontal: 2,
                                ),
                                height: SizeConfig.heightMultiplier! * 7,
                                width: SizeConfig.widthMultiplier! * 43,
                                decoration: BoxDecoration(
                                  color: AppColors.secondaryColor,
                                  borderRadius: Constant.borderRadiusLarge,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Credit Hours',
                                      style: AppTheme.textStyleSix.copyWith(fontSize: SizeConfig.textMultiplier! * 1.8),
                                    ),
                                    Container(
                                      height: SizeConfig.heightMultiplier! * 8,
                                      width: SizeConfig.widthMultiplier! * 8,
                                      decoration: const BoxDecoration(
                                        color: Colors.white,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Center(
                                        child: Text(
                                          course.credit,
                                          style: AppTheme.textStyleSix,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              // if(course.haveLab)
                              SizedBox(
                                width: SizeConfig.widthMultiplier! * 2,
                              ),
                              Container(
                                padding: symmetricInsets(
                                  horizontal: 2,
                                ),
                                height: SizeConfig.heightMultiplier! * 7,
                                width: SizeConfig.widthMultiplier! * 43,
                                decoration: BoxDecoration(
                                  color: AppColors.secondaryColor,
                                  borderRadius: Constant.borderRadiusLarge,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      course.haveLab ? 'Lab' : 'No Lab',
                                      style: AppTheme.textStyleSix,
                                    ),
                                    SizedBox(
                                      width: SizeConfig.widthMultiplier! * 6,
                                    ),
                                    Container(
                                      height: SizeConfig.heightMultiplier! * 8,
                                      width: SizeConfig.widthMultiplier! * 8,
                                      decoration: BoxDecoration(
                                        color: AppColors.white,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Center(
                                        child: Icon(
                                          Icons.computer,
                                          size: SizeConfig.widthMultiplier! * 6,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: SizeConfig.widthMultiplier! * 2,
                          ),
                          Container(
                            padding: symmetricInsets(
                              horizontal: 2,
                              vertical: 3,
                            ),
                            width: SizeConfig.widthMultiplier! * 88,
                            decoration: BoxDecoration(
                              color: AppColors.secondaryColor,
                              borderRadius: Constant.borderRadiusLarge,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      height: SizeConfig.heightMultiplier! * 3,
                                      width: SizeConfig.heightMultiplier! * 3,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(5),
                                      ),
                                    ),
                                    SizedBox(
                                      width: SizeConfig.widthMultiplier! * 2,
                                    ),
                                    Text(
                                      'Prerequisites: ',
                                      style: AppTheme.textStyleSeven,
                                    ),
                                    Expanded(
                                      child: Text(
                                        course.prerequisites,
                                        style: AppTheme.textStyleEight,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: SizeConfig.heightMultiplier! * 2,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      height: SizeConfig.heightMultiplier! * 3,
                                      width: SizeConfig.heightMultiplier! * 3,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: Constant.borderRadiusSmall,
                                      ),
                                    ),
                                    SizedBox(
                                      width: SizeConfig.widthMultiplier! * 2,
                                    ),
                                    Text(
                                      'Corequisites: ',
                                      style: AppTheme.textStyleSeven,
                                    ),
                                    Expanded(
                                      child: Text(
                                        course.corequisites,
                                        style: AppTheme.textStyleEight,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: SizeConfig.heightMultiplier! * 2,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      height: SizeConfig.heightMultiplier! * 3,
                                      width: SizeConfig.heightMultiplier! * 3,
                                      decoration: BoxDecoration(
                                        color: AppColors.white,
                                        borderRadius: Constant.borderRadiusSmall,
                                      ),
                                    ),
                                    SizedBox(
                                      width: SizeConfig.widthMultiplier! * 2,
                                    ),
                                    Text(
                                      'Equivalent Courses: ',
                                      style: AppTheme.textStyleSeven,
                                    ),
                                    Expanded(
                                      child: Text(
                                        course.equivalent,
                                        style: AppTheme.textStyleEight,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.widthMultiplier! * 2,
                          ),
                          GestureDetector(
                            onTap: () {
                              launchURL(course.courseWebsite);
                            },
                            child: Container(
                              padding: symmetricInsets(
                                horizontal: 2,
                              ),
                              height: SizeConfig.heightMultiplier! * 8,
                              width: SizeConfig.widthMultiplier! * 88,
                              decoration: BoxDecoration(
                                color: AppColors.secondaryColor,
                                borderRadius: Constant.borderRadiusMedium,
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'More info about this course ',
                                    style: AppTheme.textStyleSeven,
                                  ),
                                  Container(
                                    height: SizeConfig.heightMultiplier! * 8,
                                    width: SizeConfig.widthMultiplier! * 8,
                                    decoration: BoxDecoration(
                                      color: AppColors.white,
                                      shape: BoxShape.circle,
                                    ),
                                    child: const Center(
                                      child: Icon(Icons.link),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.widthMultiplier! * 2,
                          ),
                          Container(
                            padding: symmetricInsets(
                              horizontal: 2,
                              vertical: 2,
                            ),
                            width: SizeConfig.widthMultiplier! * 88,
                            decoration: BoxDecoration(
                              color: AppColors.secondaryColor,
                              borderRadius: Constant.borderRadiusMedium,
                            ),
                            child: Column(
                              children: [
                                Text(
                                  'Course Sections',
                                  style: AppTheme.textStyleNine,
                                ),
                                SizedBox(
                                  height: SizeConfig.widthMultiplier! * 4,
                                ),
                                Column(
                                  children: List.generate(course.shortCourses.length, (index) {
                                    return Column(
                                      children: [
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                              GlobalController.passedContext,
                                              MaterialPageRoute(
                                                builder: (context) => SectionScreen(
                                                  returnPage: 'Course',
                                                  crn: course.shortCourses[index].crn,
                                                ),
                                              ),
                                            );
                                          },
                                          child: Container(
                                            padding: symmetricInsets(
                                              horizontal: 2,
                                              vertical: 2,
                                            ),
                                            width: SizeConfig.widthMultiplier! * 75,
                                            decoration: BoxDecoration(
                                              color: AppColors.white,
                                              borderRadius: Constant.borderRadiusMedium,
                                            ),
                                            child: Center(
                                              child: Text(
                                                course.shortCourses[index].info,
                                                style: AppTheme.textStyleSeven,
                                              ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(
                                          height: SizeConfig.widthMultiplier! * 2,
                                        ),
                                      ],
                                    );
                                  }),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.widthMultiplier! * 2,
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                GlobalController.passedContext,
                                MaterialPageRoute(
                                  builder: (context) => Evaluation(
                                    courseCode: widget.code,
                                  ),
                                ),
                              );
                            },
                            child: Container(
                              height: SizeConfig.heightMultiplier! * 6,
                              width: SizeConfig.widthMultiplier! * 88,
                              decoration: BoxDecoration(
                                color: AppColors.secondaryColor,
                                borderRadius: BorderRadius.circular(
                                  10,
                                ),
                              ),
                              child: Center(
                                child: Text(
                                  'EVALUATE THE COURSE',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: SizeConfig.textMultiplier! * 2.3,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: SizeConfig.heightMultiplier! * 2,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            } else {
              return Container();
            }
          },
        ),
      ),
    );
  }
}
