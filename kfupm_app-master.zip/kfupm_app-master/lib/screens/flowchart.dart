import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/course_flowchart.dart';
import 'package:kfupm_app/widgets/line.dart';

class Flowchart extends StatefulWidget {
  const Flowchart({Key? key}) : super(key: key);

  @override
  State<Flowchart> createState() => _FlowchartState();
}

class _FlowchartState extends State<Flowchart> {
  List<String> years = ['Freshman', 'Sophomore', 'Junior', 'Senior'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAF7F5),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'SWE',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 25.3,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              Text(
                'Majors',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: Row(
                    children: List.generate(
                      years.length,
                      (index) {
                        return Row(
                          children: [
                            Column(
                              children: [
                                Text(
                                  years[index],
                                  style: TextStyle(
                                    fontSize: SizeConfig.textMultiplier! * 2.3,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(
                                        SizeConfig.widthMultiplier! * 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: AppColors.secondaryColor,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Text(
                                        '1',
                                        style: TextStyle(
                                          fontSize: SizeConfig.textMultiplier! * 2.3,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      width: SizeConfig.widthMultiplier! * 30,
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(
                                        SizeConfig.widthMultiplier! * 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: AppColors.secondaryColor,
                                        shape: BoxShape.circle,
                                      ),
                                      child: Text(
                                        '2',
                                        style: TextStyle(
                                          fontSize: SizeConfig.textMultiplier! * 2.3,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: SizeConfig.heightMultiplier! * 1,
                                ),
                                Container(
                                  height: SizeConfig.heightMultiplier! * 0.1,
                                  width: SizeConfig.widthMultiplier! * 85.5,
                                  color: Colors.grey.shade500,
                                ),
                              ],
                            ),
                            Container(
                              height: SizeConfig.heightMultiplier! * 100,
                              width: SizeConfig.widthMultiplier! * 0.1,
                              color: Colors.grey.shade500,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),

            ///1
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 7,
              child: const CourseFlowchart(
                courseName: 'MATH 101',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 7,
              child: const CourseFlowchart(
                courseName: 'CHEM 101',
                isLab: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 7,
              child: const CourseFlowchart(
                courseName: 'PE 101',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 7,
              child: const CourseFlowchart(
                courseName: 'PHYS 101',
                isLab: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 7,
              child: const CourseFlowchart(
                courseName: 'ENGL 101',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 73,
              left: SizeConfig.widthMultiplier! * 7,
              child: const CourseFlowchart(
                courseName: 'IAS 101',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 18.5,
              left: SizeConfig.widthMultiplier! * 36,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 36,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48.5,
              left: SizeConfig.widthMultiplier! * 36,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.5,
              left: SizeConfig.widthMultiplier! * 36,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 76.5,
              left: SizeConfig.widthMultiplier! * 36,
              child: const Line(
                width: 100,
              ),
            ),

            ///2
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 49,
              child: const CourseFlowchart(
                courseName: 'MATH 101',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 49,
              child: const CourseFlowchart(
                courseName: 'ICS 102',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 49,
              child: const CourseFlowchart(
                courseName: 'PE 102',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 49,
              child: const CourseFlowchart(
                courseName: 'PHYS 102',
                isLab: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 49,
              child: const CourseFlowchart(
                courseName: 'ENGL 102',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 65,
              left: SizeConfig.widthMultiplier! * 49,
              child: const CourseFlowchart(
                courseName: 'IAS 111',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 18.5,
              left: SizeConfig.widthMultiplier! * 78,
              child: const Line(
                width: 16,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 12,
              left: SizeConfig.widthMultiplier! * 82,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 14,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 12,
              left: SizeConfig.widthMultiplier! * 82,
              child: const Line(
                width: 90,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 12,
              left: SizeConfig.widthMultiplier! * 172,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 14,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 18.5,
              left: SizeConfig.widthMultiplier! * 172,
              child: const Line(
                width: 10,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 28.5,
              left: SizeConfig.widthMultiplier! * 78,
              child: const Line(
                width: 16,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 28.5,
              left: SizeConfig.widthMultiplier! * 88,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 44,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 88,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48.5,
              left: SizeConfig.widthMultiplier! * 88,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.5,
              left: SizeConfig.widthMultiplier! * 82,
              child: const Line(
                width: 11,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48.2,
              left: SizeConfig.widthMultiplier! * 82,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 23,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48.2,
              left: SizeConfig.widthMultiplier! * 78,
              child: const Line(
                width: 4,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.2,
              left: SizeConfig.widthMultiplier! * 80,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 20,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 67.2,
              left: SizeConfig.widthMultiplier! * 80,
              child: const Line(
                width: 130.8,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.2,
              left: SizeConfig.widthMultiplier! * 210,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 20,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 67.2,
              left: SizeConfig.widthMultiplier! * 80,
              child: const Line(
                width: 130.8,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.2,
              left: SizeConfig.widthMultiplier! * 210,
              child: const Line(
                width: 10,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.2,
              left: SizeConfig.widthMultiplier! * 78,
              child: const Line(
                width: 2,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 70,
              left: SizeConfig.widthMultiplier! * 78,
              child: const Line(
                width: 106,
              ),
            ),

            ///3
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 93,
              child: const CourseFlowchart(
                courseName: 'MATH 201',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 93,
              child: const CourseFlowchart(
                courseName: 'ICS 253',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 93,
              child: const CourseFlowchart(
                courseName: 'SWE 205',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 93,
              child: const CourseFlowchart(
                courseName: 'ICS 201',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 93,
              child: const CourseFlowchart(
                courseName: 'COE 202',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 28.5,
              left: SizeConfig.widthMultiplier! * 122,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 23.3,
              left: SizeConfig.widthMultiplier! * 127,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 12,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 23.3,
              left: SizeConfig.widthMultiplier! * 127,
              child: const Line(
                width: 132,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 23.3,
              left: SizeConfig.widthMultiplier! * 259,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 33,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 259,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 122,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 33.3,
              left: SizeConfig.widthMultiplier! * 127,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 12,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 33.3,
              left: SizeConfig.widthMultiplier! * 127,
              child: const Line(
                width: 45,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 33.3,
              left: SizeConfig.widthMultiplier! * 172,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 12,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 172,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48.5,
              left: SizeConfig.widthMultiplier! * 122,
              child: const Line(
                width: 13,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 129,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 40,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 54,
              left: SizeConfig.widthMultiplier! * 129,
              child: const Line(
                width: 86.5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48,
              left: SizeConfig.widthMultiplier! * 215,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 13.8,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 57,
              left: SizeConfig.widthMultiplier! * 129,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48,
              left: SizeConfig.widthMultiplier! * 215,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58.5,
              left: SizeConfig.widthMultiplier! * 122,
              child: const Line(
                width: 13,
              ),
            ),

            ///4
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 134,
              child: const CourseFlowchart(
                courseName: 'ICS 254',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 134,
              child: const CourseFlowchart(
                courseName: 'SWE 215',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 134,
              child: const CourseFlowchart(
                courseName: 'ICS 202',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 134,
              child: const CourseFlowchart(
                courseName: 'ICS 233',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 73,
              left: SizeConfig.widthMultiplier! * 134,
              child: const CourseFlowchart(
                courseName: 'IAS 201',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38.5,
              left: SizeConfig.widthMultiplier! * 163,
              child: const Line(
                width: 10,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 34,
              left: SizeConfig.widthMultiplier! * 169,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 10,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 34,
              left: SizeConfig.widthMultiplier! * 170,
              child: const Line(
                width: 45,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 28,
              left: SizeConfig.widthMultiplier! * 215,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 14,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 28,
              left: SizeConfig.widthMultiplier! * 215,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 48,
              left: SizeConfig.widthMultiplier! * 163,
              child: const Line(
                width: 16,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 40,
              left: SizeConfig.widthMultiplier! * 175,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 17.5,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 40,
              left: SizeConfig.widthMultiplier! * 175,
              child: const Line(
                width: 16,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 44,
              left: SizeConfig.widthMultiplier! * 175,
              child: const Line(
                width: 84,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 38,
              left: SizeConfig.widthMultiplier! * 259,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 13.9,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58,
              left: SizeConfig.widthMultiplier! * 163,
              child: const Line(
                width: 10,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58,
              left: SizeConfig.widthMultiplier! * 173,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 14,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 64.5,
              left: SizeConfig.widthMultiplier! * 173,
              child: const Line(
                width: 125,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58,
              left: SizeConfig.widthMultiplier! * 298,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 15,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 58,
              left: SizeConfig.widthMultiplier! * 298,
              child: const Line(
                width: 7,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 78,
              left: SizeConfig.widthMultiplier! * 163,
              child: const Line(
                width: 135,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 70,
              left: SizeConfig.widthMultiplier! * 298,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 18.2,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 70,
              left: SizeConfig.widthMultiplier! * 298,
              child: const Line(
                width: 10,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 72,
              left: SizeConfig.widthMultiplier! * 207,
              child: const Line(
                width: 13,
              ),
            ),

            ///5
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 179,
              child: const CourseFlowchart(
                courseName: 'STAT 319',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 179,
              child: const CourseFlowchart(
                courseName: 'SWE 312',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 179,
              child: const CourseFlowchart(
                courseName: 'SWE 316',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 179,
              child: const CourseFlowchart(
                courseName: 'ICS 324',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 69,
              left: SizeConfig.widthMultiplier! * 179,
              child: const CourseFlowchart(
                courseName: 'IAS 212',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 27,
              left: SizeConfig.widthMultiplier! * 249,
              child: const Line(
                width: 5,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 27,
              left: SizeConfig.widthMultiplier! * 254,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 16,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 34,
              left: SizeConfig.widthMultiplier! * 254,
              child: const Line(
                width: 45,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 34,
              left: SizeConfig.widthMultiplier! * 299,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 30,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 47.7,
              left: SizeConfig.widthMultiplier! * 299,
              child: const Line(
                width: 6,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 40,
              left: SizeConfig.widthMultiplier! * 249,
              child: const Line(
                width: 6,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 40,
              left: SizeConfig.widthMultiplier! * 255,
              child: const RotatedBox(
                quarterTurns: 1,
                child: Line(
                  width: 20,
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 49,
              left: SizeConfig.widthMultiplier! * 255,
              child: const Line(
                width: 10,
              ),
            ),

            ///6
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 220,
              child: const CourseFlowchart(
                courseName: 'SWE 363',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 220,
              child: const CourseFlowchart(
                courseName: 'SWE 326',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 220,
              child: const CourseFlowchart(
                courseName: 'SWE 387',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 220,
              child: const CourseFlowchart(
                courseName: 'ICS 343',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 220,
              child: const CourseFlowchart(
                courseName: 'ENGL 214',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 69,
              left: SizeConfig.widthMultiplier! * 220,
              child: const CourseFlowchart(
                courseName: 'IAS 322',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 49,
              left: SizeConfig.widthMultiplier! * 293,
              child: const Line(
                width: 13,
              ),
            ),

            ///7
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 264,
              child: const CourseFlowchart(
                courseName: 'XE xxx',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 264,
              child: const CourseFlowchart(
                courseName: 'SWE xxx',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 264,
              child: const CourseFlowchart(
                courseName: 'ICS 353',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 264,
              child: const CourseFlowchart(
                courseName: 'SWE 417',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 264,
              child: const CourseFlowchart(
                courseName: 'IAS 307',
              ),
            ),

            ///8
            Positioned(
              top: SizeConfig.heightMultiplier! * 15,
              left: SizeConfig.widthMultiplier! * 305,
              child: const CourseFlowchart(
                courseName: 'XE xxx',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 25,
              left: SizeConfig.widthMultiplier! * 305,
              child: const CourseFlowchart(
                courseName: 'SWE xxx',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 35,
              left: SizeConfig.widthMultiplier! * 305,
              child: const CourseFlowchart(
                courseName: 'SWE xxx',
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 45,
              left: SizeConfig.widthMultiplier! * 305,
              child: const CourseFlowchart(
                courseName: 'SWE 418',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 55,
              left: SizeConfig.widthMultiplier! * 305,
              child: const CourseFlowchart(
                courseName: 'ICS 431',
                isCom: true,
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 65,
              left: SizeConfig.widthMultiplier! * 305,
              child: const CourseFlowchart(
                courseName: 'IAS 301',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
