import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/entities/enums/evaluation_enum.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';

class Evaluation extends StatefulWidget {
  const Evaluation({
    Key? key,
    required this.courseCode,
  }) : super(key: key);
  final String courseCode;

  @override
  State<Evaluation> createState() => _EvaluationState();
}

class _EvaluationState extends State<Evaluation> {
  List<List<dynamic>> questions = [
    ['Was this course heavily dependant on yourself?', EvaluationEnum.zero],
    ['Was this course heavily dependant on yourself?', EvaluationEnum.zero],
    ['Was this course heavily dependant on yourself?', EvaluationEnum.zero],
    ['Was this course heavily dependant on yourself?', EvaluationEnum.zero],
    ['Was this course heavily dependant on yourself?', EvaluationEnum.zero],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Evaluation',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 3,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Course',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Stack(
          alignment: AlignmentDirectional.topCenter,
          children: [
            Positioned(
              top: SizeConfig.heightMultiplier! * 2,
              right: SizeConfig.widthMultiplier! * 6,
              left: SizeConfig.widthMultiplier! * 6,
              child: Container(
                padding: EdgeInsets.symmetric(
                  vertical: SizeConfig.heightMultiplier! * 2,
                  horizontal: SizeConfig.widthMultiplier! * 4,
                ),
                decoration: BoxDecoration(
                  color: AppColors.secondaryColor,
                  borderRadius: BorderRadius.circular(
                    10,
                  ),
                ),
                child: Text(
                  'Please evaluate your experience and answer the questions from a scale of 1 to 5, 1 being strongly disagree and 5 being strongly agree',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 18,
              right: SizeConfig.widthMultiplier! * 6,
              left: SizeConfig.widthMultiplier! * 6,
              bottom: SizeConfig.heightMultiplier! * 6,
              child: SingleChildScrollView(
                child: Column(
                  children: List.generate(
                    questions.length,
                    (index) {
                      return Container(
                        margin: EdgeInsets.symmetric(
                          vertical: SizeConfig.widthMultiplier! * 2,
                        ),
                        padding: EdgeInsets.symmetric(
                          vertical: SizeConfig.heightMultiplier! * 2,
                          horizontal: SizeConfig.widthMultiplier! * 4,
                        ),
                        decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.1),
                              spreadRadius: 2,
                              blurRadius: 2,
                              offset: const Offset(1, 1), // changes position of shadow
                            ),
                          ],
                          color: AppColors.secondaryColor,
                          borderRadius: BorderRadius.circular(
                            10,
                          ),
                        ),
                        child: Column(
                          children: [
                            Text(
                              questions[index][0],
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: SizeConfig.textMultiplier! * 2,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: List.generate(
                                5,
                                (indexRadio) {
                                  return Radio<EvaluationEnum>(
                                    value: EvaluationEnum.values[indexRadio + 1],
                                    groupValue: questions[index][1],
                                    activeColor: Colors.black,
                                    onChanged: (EvaluationEnum? value) {
                                      setState(() {
                                        questions[index][1] = value;
                                      });
                                    },
                                  );
                                },
                              ),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: List.generate(
                                5,
                                (indexText) {
                                  return Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: SizeConfig.widthMultiplier! * 4.7,
                                    ),
                                    child: Text(
                                      (indexText + 1).toString(),
                                      style: TextStyle(
                                        fontSize: SizeConfig.textMultiplier! * 2,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0,
              child: GestureDetector(
                onTap: () {
                  FirebaseCollections.evaluation.add({
                    "codeCourse" : widget.courseCode,
                    "answers": {
                      "Q1": questions[0][1].toString(),
                      "Q2": questions[1][1].toString(),
                      "Q3": questions[2][1].toString(),
                      "Q4": questions[3][1].toString(),
                      "Q5": questions[4][1].toString(),
                    }
                  });
                  Navigator.pop(context);
                },
                child: Container(
                  height: SizeConfig.heightMultiplier! * 6,
                  width: SizeConfig.widthMultiplier! * 88,
                  decoration: BoxDecoration(
                      color: AppColors.secondaryColor,
                      borderRadius: BorderRadius.circular(
                        10,
                      ),
                      border: Border.all(
                        color: Colors.grey.shade300,
                        width: SizeConfig.widthMultiplier! * 0.2,
                      )),
                  child: Center(
                    child: Text(
                      'SUBMIT',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: SizeConfig.textMultiplier! * 2.3,
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
