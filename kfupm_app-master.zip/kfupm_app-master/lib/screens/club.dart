import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/club.dart';
import 'package:kfupm_app/services/firebase/club_services.dart';
import 'package:kfupm_app/theme/app_colors.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/cards/event_card.dart';
import 'package:kfupm_app/widgets/sheets/add_event_sheet.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/edit_club_sheet.dart';

class Club extends StatefulWidget {
  Club({
    Key? key,
    required this.club,
    required this.isFollowed,
  }) : super(key: key);
  final ClubModel club;
  bool isFollowed;

  @override
  State<Club> createState() => _ClubState();
}

class _ClubState extends State<Club> {
  openSheet(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: EditClubSheet(
        club: widget.club,
        state: this,
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  openSheetAddEvent(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: AddEventSheet(
        clubName: widget.club.name,
        state: this,
        clubModel: widget.club,
      ),
      bottomPadding: 50,
      bottomButton: const SizedBox(),
      showBottomButton: false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Club',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 31,
        actions: <Widget>[
          if (GlobalController.stu) ...[
            Padding(
              padding: EdgeInsets.only(
                right: SizeConfig.widthMultiplier! * 6,
              ),
              child: GestureDetector(
                onTap: () async {
                  setState(() {
                    widget.isFollowed = !widget.isFollowed;
                    if (widget.isFollowed) {
                      GlobalController.student!.followedClubs.remove(widget.club.name);
                      ClubServices.followClub(widget.club.name, GlobalController.student!.email);
                    } else {
                      GlobalController.student!.followedClubs.add(widget.club.name);
                      ClubServices.unfollowClub(widget.club.name, GlobalController.student!.email);
                    }
                  });
                  if (GlobalController.student!.representative == widget.club.name) {
                    await openSheet(context);
                  }
                },
                child: Container(
                  margin: EdgeInsets.symmetric(
                    vertical: SizeConfig.heightMultiplier! * 1.5,
                  ),
                  padding: EdgeInsets.symmetric(
                    horizontal: SizeConfig.widthMultiplier! * 2,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.secondaryColor,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Center(
                    child: Text(
                      GlobalController.student!.representative == widget.club.name
                          ? 'Edit'
                          : (widget.isFollowed ? 'Followed' : 'Follow'),
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2.1,
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ]
        ],
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned(
            top: SizeConfig.heightMultiplier! * 1,
            left: SizeConfig.widthMultiplier! * 6,
            right: SizeConfig.widthMultiplier! * 6,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.widthMultiplier! * 4,
                vertical: SizeConfig.heightMultiplier! * 2,
              ),
              height: SizeConfig.heightMultiplier! * 40,
              decoration: BoxDecoration(
                color: const Color(0xFFFAF7F5),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Image.network(
                        widget.club.icon,
                        width: SizeConfig.widthMultiplier! * 15,
                        height: SizeConfig.widthMultiplier! * 15,
                      ),
                      SizedBox(
                        width: SizeConfig.widthMultiplier! * 2,
                      ),
                      Expanded(
                        child: Text(
                          widget.club.name,
                          overflow: TextOverflow.clip,
                          maxLines: 2,
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 2.4,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 1,
                  ),
                  TextButton(
                    onPressed: () {},
                    child: Text(
                      'Location: ${widget.club.location}',
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 1.8,
                        fontWeight: FontWeight.w600,
                        color: Colors.black,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 2,
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'About the Club',
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2.2,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 1,
                  ),
                  Expanded(
                    child: Text(
                      widget.club.about,
                      maxLines: 7,
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2,
                        fontWeight: FontWeight.w400,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 41,
            left: SizeConfig.widthMultiplier! * 6,
            right: SizeConfig.widthMultiplier! * 6,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Club Events',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (GlobalController.stu && GlobalController.student!.representative == widget.club.name) ...[
                  Padding(
                    padding: EdgeInsets.only(
                      right: SizeConfig.widthMultiplier! * 6,
                    ),
                    child: GestureDetector(
                      onTap: () async {
                        await openSheetAddEvent(context);
                        setState(() {});
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(
                          vertical: SizeConfig.heightMultiplier! * 1.5,
                        ),
                        padding: EdgeInsets.symmetric(
                          horizontal: SizeConfig.widthMultiplier! * 4,
                          vertical: SizeConfig.heightMultiplier! * 0.5,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.secondaryColor,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Center(
                          child: Text(
                            'Add Event',
                            style: TextStyle(
                              fontSize: SizeConfig.textMultiplier! * 2.1,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 47,
            bottom: 0,
            child: SizedBox(
              height: SizeConfig.heightMultiplier! * 73,
              width: SizeConfig.widthMultiplier! * 100,
              child: ListView.builder(
                scrollDirection: Axis.vertical,
                physics: const ScrollPhysics(),
                shrinkWrap: true,
                itemCount: widget.club.events.length,
                itemBuilder: (BuildContext context, int index) {
                  return EventCard(
                    event: widget.club.events[index],
                    club: widget.club,
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
