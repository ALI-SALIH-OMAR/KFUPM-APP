/*
Author: Saud Elabdullah.
Work: This class work as a widget,
This widget is a textfield with a tag as it is the type of the field.
Note: Noting.
 */
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/controllers/clubs_controller.dart';
import 'package:kfupm_app/entities/event.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/cards/event_card.dart';
import 'package:kfupm_app/widgets/custom_scroll_view_list.dart';
import 'package:kfupm_app/widgets/search_text_field.dart';
import 'package:kfupm_app/widgets/skeletons/event_card_skeleton.dart';

import '../controllers/global_controller.dart';

class Events extends StatefulWidget {
  const Events({Key? key}) : super(key: key);

  @override
  State<Events> createState() => _EventsState();
}

class _EventsState extends State<Events> {
  FontWeight fontWeightFollowed = FontWeight.bold;
  FontWeight fontWeightAllEvents = FontWeight.normal;
  ScrollController scrollController = ScrollController();
  late double dy;
  late double searchPosition;
  List<Event> events = [];
  List<Event> spareEvents = [];
  bool once = true;

  bool followedEvent = true;
  List<Event> followedEvents = [];
  List<Event> spareFollowedEvents = [];

  getData() async {
    if (once) {
      events = await ClubsController.getEvents();
      once = false;
    }
    spareEvents = await ClubsController.getEvents();
    if (GlobalController.stu) {
      followedEvents = GlobalController.student!.events;
    }
    else{
      followedEvents = GlobalController.instructor!.event;
    }
  }

  Widget searchBar = Container(
    color: Colors.transparent,
    height: 10,
    width: 10,
  );

  void _start(DragDownDetails details) {
    setState(() {
      dy = details.globalPosition.dy.floorToDouble();
    });
  }

  void _onVerticalDragStartHandler() {
    setState(() {
      if (dy - scrollController.offset > 0) {
        searchBar = SearchTextField(
          textEditingController: TextEditingController(),
          passedFunction: () {
            changePosition();
          },
          searchFunction: (String value) {
            if (GlobalController.ins) {
              filterSearchResults(value);
            } else {
              if (followedEvent) {
                filterSearchFollowed(value);
              } else {
                filterSearchResults(value);
              }
            }
          },
        );
      } else if (dy - scrollController.offset < 0) {
        searchBar = Container();
      }
    });
  }

  Widget _animation() => AnimatedSwitcher(
        duration: const Duration(milliseconds: 100),
        transitionBuilder: (Widget child, Animation<double> animation) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.0, 1.0),
            end: const Offset(0, 0),
          ).animate(animation),
          child: child,
        ),
        child: searchBar,
      );

  void changePosition() {
    setState(() {
      searchPosition = SizeConfig.heightMultiplier! * 1;
    });
  }

  void returnPosition() {
    setState(() {
      searchPosition = SizeConfig.heightMultiplier! * 70;
    });
  }

  @override
  void initState() {
    searchPosition = SizeConfig.heightMultiplier! * 70;
    dy = 0;
    scrollController.addListener(_onVerticalDragStartHandler);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        automaticallyImplyLeading: false,
        title: Row(
          children: [
            SizedBox(
              width: SizeConfig.widthMultiplier! * 2,
            ),
            Text(
              'Event',
              style: TextStyle(
                fontSize: SizeConfig.textMultiplier! * 3,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Stack(
          alignment: AlignmentDirectional.topCenter,
          children: [
            Positioned(top: SizeConfig.heightMultiplier! * 1, child: topNavigator(context)),
            Positioned(
              top: SizeConfig.heightMultiplier! * 4,
              bottom: 0,
              child: FutureBuilder(
                future: getData(),
                builder: (BuildContext context, AsyncSnapshot snapshot) {
                  if (!(followedEvent) &&
                      (events.isNotEmpty || snapshot.connectionState == ConnectionState.done)) {
                    return GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      dragStartBehavior: DragStartBehavior.start,
                      onVerticalDragDown: _start,
                      onTap: () {
                        returnPosition();
                      },
                      child: SizedBox(
                        height: SizeConfig.heightMultiplier! * 73,
                        width: SizeConfig.widthMultiplier! * 100,
                        child: ListView.builder(
                          scrollDirection: Axis.vertical,
                          controller: scrollController,
                          physics: const ScrollPhysics(),
                          shrinkWrap: true,
                          itemCount: events.length,
                          itemBuilder: (BuildContext context, int index) {
                            return EventCard(
                              club: ClubsController.getEventClub(events[index].organizer),
                              event: events[index],
                            );
                          },
                        ),
                      ),
                    );
                  } else if (followedEvent && (followedEvents.isNotEmpty)) {
                    if (spareFollowedEvents.isNotEmpty) {
                      return GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        dragStartBehavior: DragStartBehavior.start,
                        onVerticalDragDown: _start,
                        onTap: () {
                          returnPosition();
                        },
                        child: SizedBox(
                          height: SizeConfig.heightMultiplier! * 73,
                          width: SizeConfig.widthMultiplier! * 100,
                          child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            controller: scrollController,
                            physics: const ScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: spareFollowedEvents.length,
                            itemBuilder: (BuildContext context, int index) {
                              return EventCard(
                                club: ClubsController.getEventClub(spareFollowedEvents[index].organizer),
                                event: spareFollowedEvents[index],
                              );
                            },
                          ),
                        ),
                      );
                    } else {
                      return GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        dragStartBehavior: DragStartBehavior.start,
                        onVerticalDragDown: _start,
                        onTap: () {
                          returnPosition();
                        },
                        child: SizedBox(
                          height: SizeConfig.heightMultiplier! * 73,
                          width: SizeConfig.widthMultiplier! * 100,
                          child: ListView.builder(
                            scrollDirection: Axis.vertical,
                            controller: scrollController,
                            physics: const ScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: followedEvents.length,
                            itemBuilder: (BuildContext context, int index) {
                              return EventCard(
                                club: ClubsController.getEventClub(followedEvents[index].organizer),
                                event: followedEvents[index],
                              );
                            },
                          ),
                        ),
                      );
                    }
                  }
                  if (events.isEmpty && snapshot.connectionState != ConnectionState.done) {
                    return CustomScrollViewList(
                      widget: const EventCardSkeleton(),
                      scrollController: scrollController,
                    );
                  }
                  return const Center(child: Text('NO AVAILABLE EVENTS'));
                },
              ),
            ),
            AnimatedPositioned(
              top: searchPosition,
              duration: const Duration(milliseconds: 100),
              child: GestureDetector(
                onTap: () {
                  changePosition();
                },
                child: _animation(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //search method for searching inside events page
  void filterSearchResults(String searchWord) async {
    if (searchWord.isNotEmpty) {
      List<Event> searchList = [];
      for (var event in events) {
        if (event.title.toUpperCase().contains(searchWord.toUpperCase())) {
          searchList.add(event);
        }
      }
      setState(() {
        if (searchList.isNotEmpty) {
          events.clear();
          events.addAll(searchList);
        } else {
          events.clear();
          events.addAll(spareEvents);
        }
      });
    } else {
      setState(() {
        events.clear();
        events.addAll(spareEvents);
      });
    }
  }

  void filterSearchFollowed(String searchWord) {
    if (searchWord.isNotEmpty) {
      List<Event> searchFollowedList = [];
      for (var event in followedEvents) {
        if (event.title.toUpperCase().contains(searchWord.toUpperCase())) {
          searchFollowedList.add(event);
        }
      }
      setState(() {
        if (searchFollowedList.isNotEmpty) {
          spareFollowedEvents.clear();
          spareFollowedEvents.addAll(searchFollowedList);
        } else {
          spareFollowedEvents.clear();
        }
      });
    } else {
      setState(() {
        spareFollowedEvents.clear();
      });
    }
  }

  Widget topNavigator(BuildContext context) {
      return Row(
        children: [
          GestureDetector(
            onTap: () {
              setState(
                () {
                  fontWeightFollowed = FontWeight.bold;
                  fontWeightAllEvents = FontWeight.normal;
                  followedEvent = true;
                },
              );
            },
            child: Text(
              'Followed',
              style: TextStyle(
                fontWeight: fontWeightFollowed,
                fontSize: 20,
              ),
            ),
          ),
          const SizedBox(
            width: 15,
          ),
          GestureDetector(
            onTap: () {
              setState(() {
                fontWeightAllEvents = FontWeight.bold;
                fontWeightFollowed = FontWeight.normal;
                followedEvent = false;
              });
            },
            child: Text(
              'All Events',
              style: TextStyle(
                fontWeight: fontWeightAllEvents,
                fontSize: 20,
              ),
            ),
          ),
        ],
      );

  }
}
