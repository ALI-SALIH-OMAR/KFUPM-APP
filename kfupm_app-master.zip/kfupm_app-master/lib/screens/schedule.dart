import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/controllers/section_controller.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/utils/time.dart';
import 'package:kfupm_app/widgets/section_schedule.dart';

import '../utils/size_config.dart';

class Schedule extends StatefulWidget {
  const Schedule({Key? key}) : super(key: key);

  @override
  State<Schedule> createState() => _ScheduleState();
}

class _ScheduleState extends State<Schedule> {
  List<Section> sections = GlobalController.sections;
  bool once = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'My Schedule',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 30.4,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Services',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            top: SizeConfig.heightMultiplier! * 2,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Term 212',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2.3,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                Text(
                  '(16 CREDIT HOURS)',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 6,
            left: SizeConfig.widthMultiplier! * 21.8,
            right: SizeConfig.widthMultiplier! * 6,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: List.generate(
                5,
                (index) {
                  return Text(
                    Time.days[index],
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 2,
                      fontWeight: FontWeight.w400,
                      color: Colors.black54,
                    ),
                  );
                },
              ),
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 9,
            left: 0,
            right: 0,
            bottom: 0,
            child: SingleChildScrollView(
              child: Stack(
                children: [
                  Column(
                    children: List.generate(
                      16,
                      (index) {
                        return Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(right: SizeConfig.widthMultiplier! * 2),
                              child: Text(
                                SectionController.timeString(index),
                                style: TextStyle(
                                  fontSize: SizeConfig.textMultiplier! * 2,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.black54,
                                ),
                              ),
                            ),
                            for (int loop = 0; loop < 5; loop++) ...[
                              Container(
                                height: SizeConfig.heightMultiplier! * 7,
                                width: SizeConfig.widthMultiplier! * 17,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    width: SizeConfig.widthMultiplier! * 0.2,
                                    color: Colors.black26,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.heightMultiplier! * 100,
                    width: SizeConfig.widthMultiplier! * 100,
                    child: Stack(
                      children: List.generate(
                        sections.length,
                            (out) {
                          return SizedBox(
                            height: SizeConfig.heightMultiplier! * 100,
                            width: SizeConfig.widthMultiplier! * 100,
                            child: Stack(
                              children: List.generate(
                                sections[out].days.length,
                                    (inner) {
                                  List<List<int>> positions =
                                  SectionController.sectionPosition(sections[out].days, sections[out].time);
                                  int height = SectionController.sectionHeight(sections[out].time);
                                  return SectionSchedule(
                                    positionX: positions[inner][0],
                                    positionY: positions[inner][1],
                                    name: sections[out].code,
                                    number: int.parse(sections[out].sectionNumber),
                                    crn: sections[out].crn,
                                    height: height,
                                  );
                                },
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
// for (int outerLoop = 0; outerLoop < sections.length; outerLoop++) ...[

// for (int innerLoop = 0; innerLoop < sections[outerLoop].days.length; innerLoop++) ...[
// return SectionSchedule(
// positionX: positions[innerLoop][1],
// positionY: positions[innerLoop][0],
// name: sections[outerLoop].code,
// number: 1,
// crn: sections[outerLoop].crn,
// height: height,
// );
// ]
// ]
