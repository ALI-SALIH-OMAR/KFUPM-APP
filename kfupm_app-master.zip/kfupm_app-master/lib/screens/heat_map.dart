import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/calendar_controller.dart';
import 'package:kfupm_app/controllers/heat_map_controller.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/utils/time.dart';
import 'package:kfupm_app/widgets/calendar/week.dart';

class HeatMap extends StatefulWidget {
  const HeatMap({
    Key? key,
    required this.section,
  }) : super(key: key);
  final Section section;

  @override
  _HeatMapState createState() => _HeatMapState();
}

class _HeatMapState extends State<HeatMap> {
  late HeatMapController heatMapController;

  @override
  void initState() {
    heatMapController = HeatMapController();
    heatMapController.section = widget.section;
    heatMapController.setUp();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'HeatMap',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 32,
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                'Section',
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: SizeConfig.heightMultiplier! * 1,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 2,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    heatMapController.currentMonth + ' ' + DateTime.now().year.toString(),
                    style: TextStyle(
                      fontSize: SizeConfig.textMultiplier! * 3,
                      fontWeight: FontWeight.w700,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 6,
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: List.generate(
                  Time.days.length,
                  (index) {
                    return Text(
                      Time.days[index],
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 2,
                        fontWeight: FontWeight.w400,
                        color: Colors.black54,
                      ),
                    );
                  },
                ),
              ),
            ),
            Positioned(
              top: SizeConfig.heightMultiplier! * 8.5,
              left: SizeConfig.widthMultiplier! * 0,
              right: SizeConfig.widthMultiplier! * 0,
              child: SizedBox(
                height: SizeConfig.heightMultiplier! * 70,
                child: NotificationListener<ScrollNotification>(
                  onNotification: (notification) {
                    heatMapController.changeMonth(notification.metrics.pixels.toInt() + 100);
                    setState(() {});
                    return true;
                  },
                  child: ListView.builder(
                    controller: ScrollController(
                      initialScrollOffset: (heatMapController.currentWeek + 3) * SizeConfig.heightMultiplier! * 11.7,
                    ),
                    itemCount: heatMapController.daysList.length,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return Week(
                          week: heatMapController.daysList[index],
                          skipDays: heatMapController.skipDays,
                          isHeatMap: true,
                          calendarController: CalendarController(),
                          heatMapController: heatMapController,
                          weekNumber: index,
                        );
                      } else {
                        return Week(
                          week: heatMapController.daysList[index],
                          skipDays: 0,
                          isHeatMap: true,
                          calendarController: CalendarController(),
                          heatMapController: heatMapController,
                          weekNumber: index,
                        );
                      }
                    },
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
