/*
Author: Saud Elabdullah.
Work: This class work as a widget to show the instructor profile.
Note: Nothing.
 */
import 'dart:io';

import 'package:add_to_wallet/widgets/add_to_wallet_button.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/constants/constants.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/instructor.dart';
import 'package:kfupm_app/screens/section.dart';
import 'package:kfupm_app/services/get_pkpass.dart';
import 'package:kfupm_app/utils/size_config.dart';
import 'package:kfupm_app/widgets/sheets/bottom_sheet.dart';
import 'package:kfupm_app/widgets/sheets/edit_instructor_profile_sheet.dart';

class InstructorProfile extends StatefulWidget {
  const InstructorProfile({
    Key? key,
    this.prevPage = '',
    this.showOtherInstructor = false,
  }) : super(key: key);
  final String prevPage;
  final bool showOtherInstructor;

  @override
  State<InstructorProfile> createState() => _InstructorProfileState();
}

class _InstructorProfileState extends State<InstructorProfile> {
  late Instructor? instructor;
  late File file;

  openSheet(BuildContext context) async {
    await bottomSheet(
      context: context,
      child: const EditInstructorProfileSheet(),
      bottomPadding: 50,
      showBottomButton: false,
      bottomButton: const SizedBox(),
    );
  }

  @override
  void initState() {
    file = ApplePass.file;
    if (widget.showOtherInstructor) {
      instructor = GlobalController.passedInstructor;
    } else if (GlobalController.ins) {
      instructor = GlobalController.instructor;
    } else {
      instructor = GlobalController.passedInstructor;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    GlobalController.instructorProfileState = this;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFFAF7F5),
        elevation: 0,
        title: Text(
          'Profile',
          style: TextStyle(
            fontSize: SizeConfig.textMultiplier! * 2.5,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
        automaticallyImplyLeading: false,
        leadingWidth: SizeConfig.widthMultiplier! * 31,
        actions: <Widget>[
          if (GlobalController.ins)
            Padding(
              padding: EdgeInsets.only(
                right: SizeConfig.widthMultiplier! * 6,
              ),
              child: GestureDetector(
                onTap: () async {
                  await openSheet(context);
                },
                child: Container(
                  margin: EdgeInsets.symmetric(
                    vertical: SizeConfig.heightMultiplier! * 1.5,
                  ),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: SizeConfig.widthMultiplier! * 2,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Center(
                      child: Text(
                        'Edit Profile',
                        style: TextStyle(
                          fontSize: SizeConfig.textMultiplier! * 2.1,
                          color: Colors.black,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
        leading: GestureDetector(
          onTap: () {
            GlobalController.passedInstructor = null;
            Navigator.pop(context);
          },
          child: Flex(
            direction: Axis.horizontal,
            children: [
              SizedBox(
                width: SizeConfig.widthMultiplier! * 6,
              ),
              Constant.backArrow,
              SizedBox(
                width: SizeConfig.widthMultiplier! * 1,
              ),
              Text(
                widget.prevPage == '' ? 'Services' : widget.prevPage,
                style: TextStyle(
                  fontSize: SizeConfig.textMultiplier! * 2,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          Positioned(
            top: SizeConfig.heightMultiplier! * 2,
            left: SizeConfig.widthMultiplier! * 6,
            child: Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      instructor!.firstName + ' ' + instructor!.lastName,
                      style: TextStyle(
                        fontSize: SizeConfig.textMultiplier! * 3.3,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      height: SizeConfig.heightMultiplier! * 1,
                    ),
                    Text(
                      instructor!.status,
                      style: TextStyle(
                        fontSize: SizeConfig.widthMultiplier! * 4,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 12,
            left: SizeConfig.widthMultiplier! * 6,
            child: Container(
              color: Colors.black,
              height: SizeConfig.heightMultiplier! * 0.02,
              width: SizeConfig.widthMultiplier! * 88,
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 15,
            left: SizeConfig.widthMultiplier! * 6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Email address',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                  ),
                ),
                Text(
                  instructor!.email,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 24,
            left: SizeConfig.widthMultiplier! * 6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Office',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                  ),
                ),
                Text(
                  instructor!.office,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 33,
            left: SizeConfig.widthMultiplier! * 6,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Office Hours',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                  ),
                ),
                Text(
                  instructor!.officeHours,
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            top: SizeConfig.heightMultiplier! * 42,
            left: SizeConfig.widthMultiplier! * 6,
            right: 0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Courses Teaching',
                  style: TextStyle(
                    fontSize: SizeConfig.textMultiplier! * 2,
                    fontWeight: FontWeight.w400,
                    color: Colors.black54,
                  ),
                ),
                Column(
                  children: List.generate(
                    instructor!.teachingCourses.length,
                    (index) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.push(
                            GlobalController.passedContext,
                            MaterialPageRoute(
                              builder: (context) => SectionScreen(
                                returnPage: 'Profile',
                                crn: instructor!.teachingCourses[index]['crn'],
                              ),
                            ),
                          );
                        },
                        child: Text(
                          instructor!.teachingCourses[index]['name'],
                          style: TextStyle(
                            fontSize: SizeConfig.textMultiplier! * 2,
                            fontWeight: FontWeight.w400,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          if (GlobalController.ins && !widget.showOtherInstructor && Platform.isIOS) ...[
            Positioned(
              left: SizeConfig.widthMultiplier! * 6,
              right: SizeConfig.widthMultiplier! * 6,
              bottom: SizeConfig.heightMultiplier! * 10,
              child: AddToWalletButton(
                pkPass: file.readAsBytesSync(),
                width: SizeConfig.widthMultiplier! * 88,
                height: SizeConfig.heightMultiplier! * 5,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
