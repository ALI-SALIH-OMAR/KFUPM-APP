/*
Author: Saud Elabdullah.
Work: This class work as a them class to facilitate
getting and changing all app styling and theme.
Note: Noting.
 */
import 'package:flutter/material.dart';
import 'package:kfupm_app/utils/size_config.dart';

class AppTheme {
  AppTheme._();

  //Test styles

  static TextStyle textStyleOne = const TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 30,
  );
  static TextStyle textStyleTwo =
      const TextStyle(fontSize: 18, overflow: TextOverflow.ellipsis, fontWeight: FontWeight.bold);
  static TextStyle textStyleThree = const TextStyle(fontSize: 17, fontWeight: FontWeight.bold);
  static final TextStyle textStyleFour = TextStyle(
    fontSize: SizeConfig.heightMultiplier! * 10,
    fontWeight: FontWeight.bold,
  );
  static final TextStyle textStyleFive = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 4,
    fontWeight: FontWeight.bold,
  );
  static final TextStyle textStyleSix = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 4.5,
    fontWeight: FontWeight.bold,
  );
  static final TextStyle textStyleSeven = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 5,
    fontWeight: FontWeight.bold,
  );
  static final TextStyle textStyleEight = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 4,
  );
  static final TextStyle textStyleNine = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 7,
    fontWeight: FontWeight.bold,
  );
  static final TextStyle textStyleTen = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 5,
    overflow: TextOverflow.ellipsis,
  );
  static final TextStyle textStyleEleven = TextStyle(
    fontSize: SizeConfig.widthMultiplier! * 8,
    fontWeight: FontWeight.bold,
  );
}
