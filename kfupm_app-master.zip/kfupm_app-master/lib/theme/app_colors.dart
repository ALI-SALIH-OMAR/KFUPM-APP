/*
Author: Saud Elabdullah.
Work: This class work as a them class to facilitate
getting and changing all app colors.
Note: Noting.
 */
import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  //Colors
  static Color primaryColor = const Color(0xFF163C25);
  static Color secondaryColor = const Color(0xFFEAF4EB);
  static Color thirdColor = const Color(0xFFA0C0AB);
  static Color white = const Color(0xFFFFFFFF);
  static Color grey = const Color(0xFF9E9E9E);
}
