import 'package:intl/intl.dart';

class Time {
  Time._();

  static List<String> days = ['U', 'M', 'T', 'W', 'R', 'F', 'S'];

  static List<String> getMonths() {
    List<String> months = [];
    var date = DateTime.now();
    for (int loop = -4; loop < 3; loop++) {
      months.add(DateFormat('MMMM').format(DateTime(date.year, date.month + loop, date.day)));
    }
    return months;
  }

  static int daysPerMonth(List<int> date) {
    switch (date[1]) {
      case 1:
        return 31;
      case 2:
        return _isLeapYear(date[0]) ? 29 : 28;
      case 3:
        return 31;
      case 4:
        return 30;
      case 5:
        return 31;
      case 6:
        return 30;
      case 7:
        return 31;
      case 8:
        return 31;
      case 9:
        return 30;
      case 10:
        return 31;
      case 11:
        return 30;
      case 12:
        return 31;
      default:
        return 00;
    }
  }

  static List<int> getYearAndMonth(int shift) {
    int month = DateTime.now().month;
    int newMonth = month + shift;
    if (newMonth > 0) {
      return [DateTime.now().year, newMonth];
    } else {
      return [DateTime.now().year - 1, newMonth + 12];
    }
  }

  static bool _isLeapYear(int year) {
    return (year & 3) == 0 && ((year % 25) != 0 || (year & 15) == 0);
  }

  static int firstDayInMonth(int year, int month) {
    return DateTime(DateTime.now().year, DateTime.now().month, 1).weekday;
  }

  static int skipDays() {
    List<int> firstMonth = getYearAndMonth(-3);
    return firstDayInMonth(firstMonth[0], firstMonth[1]) + 1;
  }

  static List<int> getMonthsWeeks() {
    List<int> weeks = [];
    int numOfWeeks = 0;
    for (int loop = -2; loop < 4; loop++) {
      numOfWeeks = numOfWeeks + (daysPerMonth(getYearAndMonth(loop)) / 7).ceil();
      weeks.add(numOfWeeks);
    }
    return weeks;
  }

  static List<int> getMonthWeeks() {
    List<int> weeks = [];
    int numOfWeeks = 0;
    for (int loop = -2; loop < 4; loop++) {
      numOfWeeks = numOfWeeks + (daysPerMonth(getYearAndMonth(loop)) / 7).floor();
      weeks.add(numOfWeeks);
    }
    return weeks;
  }

  static int currentWeek() {
    int days = 0;
    int month = DateTime.now().month;
    for (int loop = 3; loop > 0; loop--) {
      days = days + (daysPerMonth(getYearAndMonth(month)) / 7).ceil();
      month--;
    }
    return days;
  }

  static List<List<int>> daysList() {
    List<int> s = List.generate(skipDays() - 1, (index) => 0);
    List<int> m1 = List.generate(daysPerMonth(getYearAndMonth(-3)), (index) => index + 1);
    List<int> m2 = List.generate(daysPerMonth(getYearAndMonth(-2)), (index) => index + 1);
    List<int> m3 = List.generate(daysPerMonth(getYearAndMonth(-1)), (index) => index + 1);
    List<int> m4 = List.generate(daysPerMonth(getYearAndMonth(1)), (index) => index + 1);
    List<int> m5 = List.generate(
        daysPerMonth(getYearAndMonth(0)), (index) => index + 1 == DateTime.now().day ? index + 101 : index + 1);
    List<int> m6 = List.generate(daysPerMonth(getYearAndMonth(2)), (index) => index + 1);
    List<int> m7 = List.generate(daysPerMonth(getYearAndMonth(3)), (index) => index + 1);
    List<List<int>> days = [];
    for (int outerLoop = 0; outerLoop < 31; outerLoop++) {
      List<int> week = [];
      for (int innerLoop = 0; innerLoop < 7; innerLoop++) {
        if (s.isNotEmpty) {
          week.add(s.removeAt(0));
        } else if (m1.isNotEmpty) {
          week.add(m1.removeAt(0));
        } else if (m2.isNotEmpty) {
          week.add(m2.removeAt(0));
        } else if (m3.isNotEmpty) {
          week.add(m3.removeAt(0));
        } else if (m4.isNotEmpty) {
          week.add(m4.removeAt(0));
        } else if (m5.isNotEmpty) {
          week.add(m5.removeAt(0));
        } else if (m6.isNotEmpty) {
          week.add(m6.removeAt(0));
        } else if (m7.isNotEmpty) {
          week.add(m7.removeAt(0));
        }
      }
      if (week.isNotEmpty) {
        days.add(week);
      }
    }
    return days;
  }

  static int numOfWeeks(int year) {
    DateTime dec28 = DateTime(year, 12, 28);
    int dayOfDec28 = int.parse(DateFormat("D").format(dec28));
    int weekDay = 0;
    if(dec28.weekday == 6){
      weekDay = 7;
    } else {
      weekDay = (dec28.weekday + 1) % 7;
    }
    return ((dayOfDec28 - weekDay + 10) / 7).ceil();
  }

  static int weekNumber(DateTime date) {
    int weekDay = 0;
    if(date.weekday == 6){
      weekDay = 7;
    } else {
      weekDay = (date.weekday + 1) % 7;
    }
    int dayOfYear = int.parse(DateFormat("D").format(date));
    int woy =  ((dayOfYear - weekDay + 10) / 7).floor();
    if (woy < 1) {
      woy = numOfWeeks(date.year - 1);
    } else if (woy > numOfWeeks(date.year)) {
      woy = 1;
    }
    return woy;
  }
}
