import 'dart:math';

import 'package:geolocator/geolocator.dart';

class Location{
  static Future<Position> determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  // longitude and latitude are the coordinating point (center)
  // pointX and pointY are the point need to check
  bool checkPoint(double radius, double longitude, double latitude,
      double pointX, double pointY) {
    // represent this mathematics form --> (x - centerX)^2 + (y - centerY)^2
    double totalPoints = ((pointX - longitude) * (pointX - longitude)) +
        ((pointY - latitude) * (pointY - latitude));
    // radius ^2
    double diameter = radius * radius;
    // check for -->  (x - centerX)^2 + (y - centerY)^2 <= radius ^2
    // if it is true then the point inside the circle
    if (totalPoints <= diameter) {
      return true;
    } else {
      return false;
    }
  }

  // this method to convert the line format to decimal for example 39°25'30"W --> -39.425
  // NOTE: the format of a should be like 39°25'30"W
  double convertToDecimal(String stringOfLine) {
    // cuttings points
    int degreeSymbolPosition = stringOfLine.indexOf('°');
    int quotePosition = stringOfLine.indexOf('\'');
    int doubleQuotePosition = stringOfLine.indexOf('"');

    // split the format
    var degreeCut =
    double.parse(stringOfLine.substring(0, degreeSymbolPosition));
    var minuteCut = double.parse(
        stringOfLine.substring(degreeSymbolPosition + 1, quotePosition));
    var secondCut = double.parse(
        stringOfLine.substring(quotePosition + 1, doubleQuotePosition));
    var letterCut = stringOfLine.substring(doubleQuotePosition + 1);

    //changing to degree
    minuteCut = minuteCut / 60;
    secondCut = secondCut / 3600;

    //if it is West or south the decimal will be negative
    if (letterCut == 'W' || letterCut == "S") {
      return (-1 * (degreeCut + minuteCut + secondCut));
    } else {
      return degreeCut + minuteCut + secondCut;
    }
  }

  // this method to convert the degree to radian (it will be use in distance method)
  //from degree to radian
  double convertToRadian(double decimal) {
    return (decimal * pi) / 180;
  }

  //this method to find the distance between to point on the earth
  // Note you should transfer the Xs and Ys to decimal you can use convertToDecimal(String stringOfLine);
  double distance(double x1, double y1, double x2, double y2) {
    //coordinate1
    double longitude1InRad = convertToRadian(x1);
    double latitude1InRad = convertToRadian(y1);

    //coordinate2
    double longitude2InRad = convertToRadian(x2);
    double latitude2InRad = convertToRadian(y2);

    //calculate between the same points
    double finalLongitude = longitude2InRad - longitude1InRad;
    double finalLatitude = latitude2InRad - latitude1InRad;

    // haversine formula
    num des = pow(sin(finalLatitude / 2), 2) +
        cos(latitude1InRad) *
            cos(latitude2InRad) *
            pow(sin(finalLongitude / 2), 2);
    num des2 = 2 * asin(sqrt(des));

    //the radius of earth KM
    double radiusOfEarth = 6371;

    //the distance between two points on the earth
    return (des2.toDouble() * radiusOfEarth);
  }
}