import 'package:image_picker/image_picker.dart';

//This method will return an image from the gallery.

Future<String> imagePicking() async {
  final picker = ImagePicker();
  final pickedFile = await picker.pickImage(source: ImageSource.gallery);
  return pickedFile!.path;
}
