import 'package:flutter/material.dart';

import 'size_config.dart';

EdgeInsets symmetricInsets({double horizontal = 0, double vertical = 0}) {
  return EdgeInsets.symmetric(
      horizontal: SizeConfig.heightMultiplier! * horizontal, vertical: SizeConfig.heightMultiplier! * vertical);
}
