/*
Please do not commit or push this file
 */
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/screens/loading_screen.dart';
import 'package:kfupm_app/screens/login.dart';
import 'package:kfupm_app/utils/size_config.dart';

import 'deep_links/dynamic_link_services.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FlutterNativeSplash.remove();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    FireBaseDynamicLink.initDynamicLink(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return OrientationBuilder(
          builder: (context, orientation) {
            SizeConfig().init(constraints, orientation);
            return MaterialApp(
              debugShowCheckedModeBanner: false,
              title: 'KFUPM app',
              home: StreamBuilder(
                stream: FirebaseAuth.instance.authStateChanges(),
                initialData: false,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    GlobalController.isMounted = true;
                    return const LoadingScreen();
                  } else {
                    return const Login();
                  }
                },
              ),
            );
          },
        );
      },
    );
  }
}
