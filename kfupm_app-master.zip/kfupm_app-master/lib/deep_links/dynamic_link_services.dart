import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:kfupm_app/widgets/sheets/event_sheet.dart';

import '../entities/event.dart';
import '../services/firebase/club_services.dart';
import '../widgets/sheets/bottom_sheet.dart';

class FireBaseDynamicLink {
  //<Summary>this method for creating a deep link programmatically
  // NOTE: we should change the parameter depends on the data,
  // that will be passed with the dynamic link </Summary>
  static Future<String> creatingDynamicLink(bool short,String club, String title) async {
    //this for creating a new deep link
    String _linkMessage;
    FirebaseDynamicLinks dynamicLinks = FirebaseDynamicLinks.instance;
    final DynamicLinkParameters parameters = DynamicLinkParameters(
      // The Dynamic Link URI domain. You can view created URIs on your Firebase console
      uriPrefix: 'https://kfupmapp.page.link',
      // The deep Link passed to your application which you can use to affect change
      link: Uri.parse('https://www.google.com?club=$club/title=$title'),
      // Android application details needed for opening correct app on device/Play Store
      androidParameters: const AndroidParameters(
        packageName: 'com.example.kfupm_app',
        minimumVersion: 1,
      ),
      // iOS application details needed for opening correct app on device/App Store
      iosParameters: const IOSParameters(
        bundleId: 'com.example.kfupmApp',
        minimumVersion: '2',
      ),
    );

    //this part will check which type of URL chosen long
    // or short by passing boolean called short
    Uri url;
    if (short) {
      final ShortDynamicLink shortDynamicLink = await dynamicLinks.buildShortLink(parameters);
      url = shortDynamicLink.shortUrl;
    } else {
      url = await dynamicLinks.buildLink(parameters);
    }

    _linkMessage = url.toString();
    return _linkMessage;
  }

  //<Summary> this method for handling the accessing to the APP by using deep link
  // there are two handles the first (onlink.listen) for handling the deep link when the app is open
  // the second (PendingDynamicLinkData) for handling the deep link when the app is closed </Summary>
  static Future<void> initDynamicLink(BuildContext context) async {
    //this int helps to make sure that the link open once
    int check = 0;
    //first handle
    FirebaseDynamicLinks.instance.onLink.listen((dynamicLinkData) async {
      final Uri deepLink = dynamicLinkData.link;
      if (deepLink.toString().contains('club')) {
        //retrieve data from dynamic link
        int indexOfClub = deepLink.toString().indexOf('club');
        int indexOfTitle = deepLink.toString().indexOf('title');
        String plus = '+';
        String space = " ";
        String clubName = deepLink.toString().substring(indexOfClub + 5, indexOfTitle-1).replaceAll(plus, space);
        String titleName = deepLink.toString().substring(indexOfTitle + 8).replaceAll(plus, space);
        //a demo of how to handle deep link
        Event event = await ClubServices.getEvent(titleName, clubName) as Event;
        eventSheet(event, context);
        check = 1;
      } else {
        print('does not contains screen');
      }
    }).onError((error) {
      print('error on creation');
    });

    //the second handle
    //when the app is closed

    final PendingDynamicLinkData? initialLink = await FirebaseDynamicLinks.instance.getInitialLink();

    final Uri? deepLink = initialLink?.link;
    if (deepLink.toString().contains('club')) {
      //retrieve data from dynamic link
      int indexOfClub = deepLink.toString().indexOf('club');
      int indexOfTitle = deepLink.toString().indexOf('title');
      String plus = '+';
      String space = " ";
      String clubName = deepLink.toString().substring(indexOfClub + 5, indexOfTitle-1).replaceAll(plus, space);
      String titleName = deepLink.toString().substring(indexOfTitle + 8).replaceAll(plus, space);
      //a demo of how to handle deep link

      Event event = await ClubServices.getEvent(titleName, clubName) as Event;

      //a demo of how to handle deep link
      if (check == 0) {
        // show event card
        eventSheet(event, context);
      }
    } else {
      print('does not contains screen');
    }
  }
}

void eventSheet(Event event, BuildContext context) async {
  await bottomSheet(
    context: context,
    child: EventSheet(
      event: event,
    ),
    bottomPadding: 50,
    bottomButton: const SizedBox(),
    showBottomButton: false,
  );
}
