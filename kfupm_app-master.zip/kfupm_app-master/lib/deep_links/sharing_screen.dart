import 'package:flutter_share/flutter_share.dart';

class SharingScreenServices {
  static Future<void> share(String clubNameString, eventTitle, String sharedLink) async {
    await FlutterShare.share(
        title: 'share event link', text: '$eventTitle by $clubNameString', linkUrl: sharedLink, chooserTitle: 'Example Chooser Title');
  }
}
