/*
Author: Saud Elabdullah.
Work: This class work as a service,
To pass the .pkpass file to the widget.
Note: It is used to pass a file to [widgets/add_to_wallet_button.dart].
 */
import 'dart:async';

import 'package:flutter/services.dart' show MethodCall, MethodChannel;

class AddToWallet {
  static const MethodChannel _channel = MethodChannel('add_to_wallet');

  static final AddToWallet _instance = AddToWallet._internal();

  static final Map<String, FutureOr<dynamic> Function(MethodCall)> _handlers = {};

  factory AddToWallet() {
    return _instance;
  }

  AddToWallet._internal() {
    _initMethodCallHandler();
  }

  void _initMethodCallHandler() => _channel.setMethodCallHandler(_handleCalls);

  Future<dynamic> _handleCalls(MethodCall call) async {
    var handler = _handlers[call.arguments['key']];
    return handler != null ? await handler(call) : null;
  }

  Future<void> addHandler<T>(String key, FutureOr<T> Function(MethodCall) handler) async {
    _handlers[key] = handler;
  }

  void removeHandler(String key) {
    _handlers.remove(key);
  }
}
