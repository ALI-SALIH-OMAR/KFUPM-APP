import 'dart:io';

import 'package:flutter/services.dart' show rootBundle;
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:path_provider/path_provider.dart';

class ApplePass {
  ApplePass._() {
    getImageFileFromAssets();
  }

  static final ApplePass _instance = ApplePass._();

  static ApplePass get instance => _instance;

  static File file = File('file.txt');

  static Future<void> getImageFileFromAssets() async {
    String fileName = '';
    if (GlobalController.student != null && GlobalController.student!.firstName == 'Saud') {
      fileName = '201774530';
    } else if (GlobalController.student != null && GlobalController.student!.firstName == 'Mohammed') {
      fileName = '201759150';
    } else {
      fileName = 'wasfi';
    }
    try {
      final byteData = await rootBundle.load('assets/passes/$fileName.pkpass');

      file = File('${(await getTemporaryDirectory()).path}/$fileName.pkpass');
      await file.writeAsBytes(byteData.buffer.asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));
    } catch (e){
      print(e);
    }
  }
}
