import 'dart:async';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_native_timezone/flutter_native_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

scheduledNotification(
  int id,
  String title,
  String body,
  int hours,
  int min,
  bool isSunday,
  bool isMonday,
  bool isTuesday,
  bool isWednesday,
  bool isThursday,
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin,
) async {
  tz.initializeTimeZones();
  final String? timeZoneName = await FlutterNativeTimezone.getLocalTimezone();
  tz.setLocalLocation(tz.getLocation(timeZoneName!));
  tz.TZDateTime _time(
    int hours,
    int min,
  ) {
    final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduledDate = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      hours,
      min,
      0,
      0,
      0,
    );
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }
    return scheduledDate;
  }

  tz.TZDateTime _scheduleTime(
    int hours,
    int min,
    int day,
  ) {
    tz.TZDateTime scheduledDate = _time(
      hours,
      min,
    );
    while (scheduledDate.weekday != day) {
      scheduledDate = scheduledDate.add(const Duration(days: 1));
    }
    return scheduledDate;
  }

  setScheduledNotification(
    int id,
    String title,
    String body,
    int day,
    int hours,
    int min,
  ) async {
    await flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      _scheduleTime(
        hours,
        min,
        day,
      ),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'daily notification channel id',
          'daily notification channel name',
          channelDescription: 'daily notification description',
          priority: Priority.high,
          importance: Importance.high,
          fullScreenIntent: true,
        ),
      ),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> scheduleDailyNotification(
    int id,
    String title,
    String body,
    int hours,
    int min,
    bool isSunday,
    bool isMonday,
    bool isTuesday,
    bool isWednesday,
    bool isThursday,
  ) async {
    if (isSunday) {
      print('first');
      setScheduledNotification(
        id + 1,
        title,
        body,
        DateTime.sunday,
        hours,
        min,
      );
    }
    if (isMonday) {
      setScheduledNotification(
        id + 2,
        title,
        body,
        DateTime.monday,
        hours,
        min,
      );
    }
    if (isTuesday) {
      setScheduledNotification(
        id + 3,
        title,
        body,
        DateTime.tuesday,
        hours,
        min,
      );
    }
    if (isWednesday) {
      setScheduledNotification(
        id + 4,
        title,
        body,
        DateTime.wednesday,
        hours,
        min,
      );
    }
    if (isThursday) {
      setScheduledNotification(
        id + 5,
        title,
        body,
        DateTime.thursday,
        hours,
        min,
      );
    }
  }

  scheduleDailyNotification(
    id,
    title,
    body,
    hours,
    min,
    isSunday,
    isMonday,
    isTuesday,
    isWednesday,
    isThursday,
  );
}
