import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/entities/course.dart';

class CourseServices {
  static Future<Course> getCourse(String code) async {
    return ((await FirebaseCollections.courses.where('code', isEqualTo: code).get())
            .docs
            .map((course) => Course.fromMap(course.data() as Map<String, dynamic>))
            .toList())
        .first;
  }
}
