import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/entities/college.dart';

class CollegeServices {
  static Future<List<College>> getColleges() async {
    return ((await FirebaseCollections.colleges.get())
        .docs
        .map((college) => College.fromMap(college.data() as Map<String, dynamic>))
        .toList());
  }
}
