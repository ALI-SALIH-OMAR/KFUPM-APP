import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/entities/major.dart';

class MajorsServices{
  static Future<List<Major>> getCourses() async {
    return ((await FirebaseCollections.majors
        .get())
        .docs
        .map((major) => Major.fromMap(major.data() as Map<String, dynamic>))
        .toList());
  }
}