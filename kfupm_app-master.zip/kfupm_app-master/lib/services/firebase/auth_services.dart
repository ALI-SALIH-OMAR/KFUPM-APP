import 'package:firebase_auth/firebase_auth.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/services/firebase/instructor_services.dart';
import 'package:kfupm_app/services/firebase/student_services.dart';

import '../../entities/student.dart';

class AuthServices {
  static late Student? student;
  static bool once = true;
  static Future<void> userAuth(String userName, String password) async {
    await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: userName,
      password: password,
    );
  }

  static Future<void> getUser() async {
    String uid = FirebaseAuth.instance.currentUser?.uid ?? 'nope';
    if(once && uid != 'nope'){
      once = false;
      student = await StudentServices.getStudent(uid);
      if (student == null) {
        GlobalController.instructor = await InstructorServices.getInstructor(uid);
        GlobalController.ins = true;
        GlobalController.stu = false;
      } else {
        GlobalController.student = student;
        GlobalController.ins = false;
        GlobalController.stu = true;
      }
    }
  }
}
