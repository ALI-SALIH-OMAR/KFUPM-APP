import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/entities/section.dart';
import 'package:kfupm_app/entities/student.dart';

class SectionServices {
  static Future<Section> getSection(String crn) async {
    return ((await FirebaseCollections.sections.where('crn', isEqualTo: crn).get())
        .docs
        .map((section) => Section.fromMap(section.data() as Map<String, dynamic>))
        .toList())
        .first;
  }

  static Future<List<String>> getStudentSections(String email) async {
    Student student = ((await FirebaseCollections.student.where('kfupm_email', isEqualTo: email).get())
        .docs
        .map((student) => Student.fromMap(student.data() as Map<String, dynamic>))
        .toList())
        .first;
    return student.sections;
  }
}
