import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/student.dart';

class StudentServices {
  static Future<Student?> getStudent(String uid) async {
    var data = (await FirebaseCollections.student.doc(uid).get()).data();
    if (data != null) {
      return Student.fromMap(data as Map<String, dynamic>);
    } else {
      return null;
    }
  }

  static void addEventToCalendar(List<Map<String,dynamic>> event) async {
    String studentDocId =
        (await FirebaseCollections.student.where('kfupm_email', isEqualTo: GlobalController.student!.email).get())
            .docs
            .first
            .id;
    await FirebaseCollections.student.doc(studentDocId).update({'followed_events': event});
  }

  static void deleteEventToCalendar(Map<String,dynamic> event) async {
    String studentDocId =
        (await FirebaseCollections.student.where('kfupm_email', isEqualTo: GlobalController.student!.email).get())
            .docs
            .first
            .id;
    await FirebaseCollections.student.doc(studentDocId).update({
      'followed_events': FieldValue.arrayRemove([event])
    });
  }
}
