import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kfupm_app/constants/firebase_collections.dart';

import '../../entities/event.dart';
import '../../entities/club.dart';

class ClubServices {
  static Future<List<ClubModel>> getClubsWithEvents() async {
    return (await FirebaseCollections.club.get())
        .docs
        .map((club) => ClubModel.fromMap(club.data() as Map<String, dynamic>))
        .toList();
  }

  static Future<List<ClubModel>> getClubs() async {
    return (await FirebaseCollections.clubs.get())
        .docs
        .map((club) => ClubModel.fromMap(club.data() as Map<String, dynamic>))
        .toList();

  }

  //get one event for the deeplink
  static Future<Event?> getEvent(String title, String clubName) async {
    ClubModel clubs = (await FirebaseCollections.club.where('name',isEqualTo: clubName).get())
          .docs
          .map((club) => ClubModel.fromMap(club.data() as Map<String, dynamic>))
          .toList().first;

          for(int j=0; clubs.events.length>j ; j++){
            if(clubs.events[j].title == title){
              return clubs.events[j];
            }
          }
        return null;
  }

  static Future<void> editClub(ClubModel club) async {
    (await FirebaseCollections.club.doc(club.id).update(club.toMap()).then((value) => log('Done.')));
  }

  static Future<String> changeClubIcon(String clubName, String image) async {
    String link = '';
    await FirebaseCollections.imagesStorage
        .child('$clubName.jpg')
        .putFile(
          File(image),
        )
        .whenComplete(() async {
      link = await FirebaseCollections.imagesStorage.child(clubName).getDownloadURL();
    });
    return link;
  }

  static Future<void> followClub(String club, String email) async {
    String studentDocId =
        (await FirebaseCollections.student.where('kfupm_email', isEqualTo: email).get()).docs.first.id;

    await FirebaseCollections.student.doc(studentDocId).update({
      'followed_clubs': FieldValue.arrayUnion([club])
    });
  }

  static Future<void> unfollowClub(String club, String email) async {
    String studentDocId =
        (await FirebaseCollections.student.where('kfupm_email', isEqualTo: email).get()).docs.first.id;

    await FirebaseCollections.student.doc(studentDocId).update({
      'followed_clubs': FieldValue.arrayRemove([club])
    });
  }
}
