import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/services/firebase/section_services.dart';

class PersonalEventServices {
  static Future<void> addPersonalEventToStudent(Map<String, dynamic> personalEvents, String email) async {
    String studentDocId =
        (await FirebaseCollections.student.where('kfupm_email', isEqualTo: email).get()).docs.first.id;
    await FirebaseCollections.student.doc(studentDocId).update({
      'personal_event': FieldValue.arrayUnion([personalEvents])
    });
  }

  static Future<void> addPersonalEventToSection(Map<String, dynamic> personalEvents, String crn, List<String> students,
      String email, DateTime date) async {
    String sectionDocId = (await FirebaseCollections.sections.where('crn', isEqualTo: crn).get()).docs.first.id;
    FirebaseCollections.sections.doc(sectionDocId).update({
      'personal_event': FieldValue.arrayUnion([personalEvents])
    });
    addPersonalEventToInstructor(personalEvents, email);
    for (String id in students) {
      addPersonalEventToStudent(personalEvents, 's$id@kfupm.edu.sa');
      List<String> crn = await SectionServices.getStudentSections('s$id@kfupm.edu.sa');
      for (String c in crn) {
        if (date.month < 10 && date.day < 10) {
          updateHeatMap(c, '${date.year}/0${date.month}/0${date.day}', 1);
        } else if (date.month < 10) {
          updateHeatMap(c, '${date.year}/0${date.month}/${date.day}', 1);
        } else if (date.day < 10) {
          updateHeatMap(c, '${date.year}/${date.month}/0${date.day}', 1);
        } else {
          updateHeatMap(c, '${date.year}/${date.month}/${date.day}', 1);
        }
      }
    }
  }

  static Future<void> addPersonalEventToInstructor(Map<String, dynamic> personalEvents, String email) async {
    String studentDocId =
        (await FirebaseCollections.instructor.where('kfupm_email', isEqualTo: email).get()).docs.first.id;
    await FirebaseCollections.instructor.doc(studentDocId).update({
      'personal_event': FieldValue.arrayUnion([personalEvents])
    });
  }

  static Future<void> deletePersonalEventForInstructor(Map<String, dynamic> personalEvents, String email) async {
    String studentDocId =
        (await FirebaseCollections.instructor.where('kfupm_email', isEqualTo: email).get()).docs.first.id;
    await FirebaseCollections.instructor.doc(studentDocId).update({
      'personal_event': FieldValue.arrayRemove([personalEvents])
    });
  }

  static Future<void> deletePersonalEventForStudent(Map<String, dynamic> personalEvents, String email) async {
    String studentDocId =
        (await FirebaseCollections.student.where('kfupm_email', isEqualTo: email).get()).docs.first.id;
    await FirebaseCollections.student.doc(studentDocId).update({
      'personal_event': FieldValue.arrayRemove([personalEvents])
    });
  }

  static Future<void> deletePersonalEventForSection(Map<String, dynamic> personalEvents, String crn,
      List<String> students, String email, DateTime date) async {
    String sectionDocId = (await FirebaseCollections.sections.where('crn', isEqualTo: crn).get()).docs.first.id;
    FirebaseCollections.sections.doc(sectionDocId).update({
      'personal_event': FieldValue.arrayUnion([personalEvents])
    });
    deletePersonalEventForInstructor(personalEvents, email);
    for (String id in students) {
      deletePersonalEventForStudent(personalEvents, 's$id@kfupm.edu.sa');
      List<String> crn = await SectionServices.getStudentSections('s$id@kfupm.edu.sa');
      for (String c in crn) {
        if (date.month < 10 && date.day < 10) {
          updateHeatMap(c, '${date.year}/0${date.month}/0${date.day}', -1);
        } else if (date.month < 10) {
          updateHeatMap(c, '${date.year}/0${date.month}/${date.day}', -1);
        } else if (date.day < 10) {
          updateHeatMap(c, '${date.year}/${date.month}/0${date.day}', -1);
        } else {
          updateHeatMap(c, '${date.year}/${date.month}/${date.day}', -1);
        }
      }
    }
  }

  static Future<void> updateHeatMap(String id, String date, int increment) async {
    String docId = (await FirebaseCollections.sections.where('crn', isEqualTo: id).get()).docs.first.id;
    FirebaseCollections.sections.doc(docId).set(
        {'heat_map': {date: FieldValue.increment(increment)}}, SetOptions(merge: true));
  }
}
