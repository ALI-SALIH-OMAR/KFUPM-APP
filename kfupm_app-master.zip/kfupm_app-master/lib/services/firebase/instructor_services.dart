import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kfupm_app/constants/firebase_collections.dart';
import 'package:kfupm_app/controllers/global_controller.dart';
import 'package:kfupm_app/entities/instructor.dart';

class InstructorServices {
  static Future<Instructor?> getInstructor(String uid) async {
    var data = (await FirebaseCollections.instructor.doc(uid).get()).data();
    if (data != null) {
      return Instructor.fromMap(data as Map<String, dynamic>);
    } else {
      return null;
    }
  }

  static Future<void> updateProfile(String oldEmail, String email, String office, String officeHours) async {
    String docId = (await FirebaseCollections.instructor.where('kfupm_email', isEqualTo: oldEmail).get()).docs.first.id;
    await FirebaseCollections.instructor.doc(docId).update({'kfupm_email': email});
    await FirebaseCollections.instructor.doc(docId).update({'office': office});
    await FirebaseCollections.instructor.doc(docId).update({'office_hours': officeHours});
  }

  static Future<void> getInstructorByName(String name, String crn, String code) async {
    GlobalController.passedInstructor = ((await FirebaseCollections.instructor.where('courses_teaching', arrayContainsAny: [
      {'code': code, 'crn': crn, 'name': name}
    ]).get())
        .docs
        .map((instructor) => Instructor.fromMap(instructor.data() as Map<String, dynamic>))
        .toList())
        .first;
  }

  static void addEventToCalendar(List<Map<String,dynamic>> event) async {
    String studentDocId =
        (await FirebaseCollections.instructor.where('kfupm_email', isEqualTo: GlobalController.instructor!.email).get())
            .docs
            .first
            .id;
    await FirebaseCollections.instructor.doc(studentDocId).update({'followed_events': event});
  }

  static void deleteEventToCalendar(Map<String,dynamic> event) async {
    String instructorDocId =
        (await FirebaseCollections.instructor.where('kfupm_email', isEqualTo: GlobalController.instructor!.email).get())
            .docs
            .first
            .id;
    await FirebaseCollections.instructor.doc(instructorDocId).update({
      'followed_events': FieldValue.arrayRemove([event])
    });
}
}
